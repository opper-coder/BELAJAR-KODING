    <hr>
    <p><small>&copy; 2026 Reusable System Auth - Minimalis & Aman</small></p>
</body>
</html>
<?php
/**
 * Membersihkan data input lama agar tidak muncul di form lain
 * yang tidak relevan di request berikutnya.
 */
clear_flash_old();
?>

