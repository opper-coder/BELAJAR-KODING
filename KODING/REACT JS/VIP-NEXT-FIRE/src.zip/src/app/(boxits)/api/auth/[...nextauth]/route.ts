/*
ini adalah option untuk login
disini ada option, nextAuth(), export, dasarnya seperti di bawah ini:
------------------
- import apa yang di perlukan untuk membangun NextAuth(),
- skema dasar nya ada 3 komponen  di bawah ini
    const authOption = {} // option nya atur disini
    const handler = NextAuth(authOptions);
    export { handler as GET, handler as POST };
------------------

- pada path url dan file route ini berisi konfig di atas, anda sudah bisa mengakses login(), logout() register() secara global
  - halaman ini akan di konsumsi oleh sistem NextAuth di atas
  - karena di halaman /login dan juga di tombol login pada navbar mereka meng akses login() milik NextAuth tersebut
  - tidak ada satu halaman pun yang mengakses halaman ini (/api/auth/[...nextauth]/route)
  - sehingga path url ini baku dari nextAuth (jangan di ubah)

parameter option berisi:
  - session strategy: jwt
  - secret: ini password untuk jwt silahkan akse di /.env.local
  - providers: 
      - credential
        - bikin UI form disini juga bisa
        - jalankan autorize()
          - di dalamnya ada:
            - login dengan email
            - check: parameter email, pass sesuai atau tidak 
              jalankan compare() import form bcrypt
            - 
      - google 
        - 
  - callbacks: menangkap parameter dari session, dan di olah jadi hash token, untuk param loginWithGoogle()
  - pages: mengarahkan path halaman login kita untuk ambil data dari input form. tadinya pakai UI dari NextJs

*/

import { login, loginWithGoogle } from "@/app/(boxits)/lib/firebase/service";
import { compare } from "bcrypt";
import { NextAuthOptions } from "next-auth";
import NextAuth from "next-auth/next";
import CredentialsProvider from "next-auth/providers/credentials";
import GoogleProvider from "next-auth/providers/google";

const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
  },
  secret: process.env.NEXTAUTH_SECRET,
  providers: [
    // ini pakai login credential label dan name capitalize UI form, nanti di gantikan UI kita
    CredentialsProvider({
      type: "credentials",
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      // lakukan login dan pengecekan credetial disini: credentials berisi form coba console.log
      // authorize akan di konsumsi oleh NextAuth(), yang berisi ambil credential dan lakukan cek perbandingan "user form" dan "data kita"
      // return nya data credential silahkan dibuat berapa parameter termasuk role silahkan saja
      // (nanti isi credential ini di atur dalam register, dan di simpan dimana itu ada di register)
      // setelah authorize di periksa, maka selanjutnya dilanjutkan dalam callbacks di bawah

      // autorize dengan data hardcode:
      // ------------------------------
      //   async authorize(credentials) {
      //     // ambil nilai dari input user (oleh NextAuth)
      //     const { email, password } = credentials as {
      //       email: string;
      //       password: string;
      //     };

      //  ini adalah data credential yang di "return" kan ke session nantinya, terserah buat properti yang banyak tidak apa2
      //     const user: any = {
      //       id: 1,
      //       name: "aqil",
      //       email: "ada@gmail.com",
      //       role: "admin",
      //     };
      //  lakukan cek data input dan data yang kita tentukan sendiri sebelum masuk ke db
      //  misalnya cek email dan password, kalau dari firebase sih cukup emailnya saja yang di cek jika password sudah lolos authorize()
      //     if (email === "ada@gmail.com" && password === "123") {
      //       return user;
      //     } else {
      //       return null;
      //     }
      //   },
      // }),

      // authorize dengan data dari firebase:
      // ------------------------------

      async authorize(credentials) {
        // ambil nilai dari input user (oleh NextAuth)
        const { email, password } = credentials as {
          email: string;
          password: string;
        };

        // ambil document(object) berdasar "email" dari firebase berisi data credentials yang di simpan di firestore (dari service firebase)
        const user: any = await login({ email });

        // data object.pass yang di dapat berupa encryption urai di compare bcrypt, karena password di register(kirim) oleh bcrypt juga
        // bandingkan dengan forminput user, jika ada ddan sesuai maka return kan object credential itu
        // nantinya object tersebut dibuat untuk mengisi data session
        if (user) {
          const passwordConfirm = await compare(password, user.password);
          if (passwordConfirm) {
            return user;
          }
          return null; // coba cek dulu kebenaran nya ada nggak
        } else {
          return null;
        }
      },
    }),

    // ----------------------------
    // ini jika pakai google login
    GoogleProvider({
      clientId: process.env.GOOGLE_OAUTH_CLIENT_ID || "",
      clientSecret: process.env.GOOGLE_OAUTH_CLIENT_SECRET || "",
    }),
  ],

  // dalam callback akan membuat token bermodalkan data dari authorize di atas
  callbacks: {
    async jwt({ token, account, profile, user }: any) {
      // parameter token, auth dll ini bawaan nextAuth, ikuti saja
      // jika provider credential
      if (account?.provider === "credentials") {
        // bikin token saja
        token.email = user.email;
        token.fullname = user.fullname;
        token.role = user.role;
      }

      // jika profider google
      if (account?.provider === "google") {
        // bikin object
        const data = {
          fullname: user.name,
          email: user.email,
          type: "google",
        };

        // panggil service di firebase, kirim data,
        await loginWithGoogle(
          data,
          (result: { status: boolean; data: any }) => {
            // jika status true maka bikin token
            if (result) {
              token.email = result.data.email;
              token.fullname = result.data.fullname;
              token.role = result.data.role;
            }
          }
        );
      }

      return token;
    },

    // generate (set session) session dari callback.token
    async session({ session, token }: any) {
      // jika ada email di token set session email dst
      if ("email" in token) {
        session.user.email = token.email;
      }
      if ("fullname" in token) {
        session.user.fullname = token.fullname;
      }
      if ("role" in token) {
        session.user.role = token.role;
      }
      return session;
    },
  },

  // tambahkan properti pages: path halaman login UI buatan kita, jika tidak ada ini maka UI disediakan oleh nextAuth
  // jika di aktifkan maka tugas kita harus mengubah isi login page kita silahkan cek disana
  pages: {
    signIn: "/login",
  },
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
