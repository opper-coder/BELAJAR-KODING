/*
KONSUMSI API
- async getData( await fetch() )
- ada contoh cache
- contoh revalidasi waktu
- contoh revalidate tag() ditangani oleh revalidate handler > revalidate di trigger di postman 
- getData() 
- error handling getdata()
- penggunaan data di ui
*/

import Image from "next/image";

type ProductPageProps = { params: { slug: string[] } };

async function getData() {
  const res = await fetch("http://localhost:3000/api/product", {
    // cache: "no-store", // no-store, tidak ada cache berarti data di ambil langsung dari db
    cache: "force-cache", // (default tdk di tulis), data disave di cache, kalau ada perubahan data di db, di cache tidak ikut berubah
    // maka wajib dilakukan sinkronisasi, contoh revalidate berdasar waktu:
    // next:{
    //   revalidate: 3600 * 24 // praktek isi 20 detik sj
    // },
    // revalidate berdasarkan trigger API
    next: {
      tags: ["markProduct"],
    },
  });

  if (!res.ok) {
    throw new Error("failed to fetch");
  }
  return res.json();
}

export default async function ProductPage(props: ProductPageProps) {
  const { params } = props;
  const products = await getData();
  return (
    <div className="grid grid-cols-4 mt-5">
      {/* <h1>{params.slug ? "Detail Product Page" : `Product Page`}</h1> */}
      {products.data.length > 0 &&
        products.data.map((product: any) => (
          <div
            key={products.id}
            className="w-full max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700 mt-5"
          >
            <a href="#">
              <Image
                className="p-8 rounded-t-lg object-cover h-96 w-full"
                src={product.image}
                alt="product image"
                width={500}
                height={500}
              />
            </a>
            <div className="px-5 pb-5">
              <a href="#">
                <h5 className="text-xl font-semibold tracking-tight text-gray-900 dark:text-white">
                  {product.title}
                </h5>
              </a>
              <div className="flex items-center justify-between">
                <span className="text-3xl font-bold text-gray-900 dark:text-white">
                  $ {product.price}
                </span>
                <a
                  href="#"
                  className="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                >
                  Add to cart
                </a>
              </div>
            </div>
          </div>
        ))}
      {params.slug && <>lihat detail url {params.slug[0]}</>}
    </div>
  );
}
