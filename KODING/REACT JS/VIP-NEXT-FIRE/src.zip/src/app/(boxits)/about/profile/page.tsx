/*disini hanya menunjukan routing page saja jika di akses tidak perlu menulis file page.ts*/
export default function Properties() {
  return <div>properties</div>;
}
