export default function Halo() {
  return (
    <div>Halo About</div>
  )
}
