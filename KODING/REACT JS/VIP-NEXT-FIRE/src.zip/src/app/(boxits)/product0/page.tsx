
export default function Product() {
    return (
      <div>Product</div>
    )
  }
  