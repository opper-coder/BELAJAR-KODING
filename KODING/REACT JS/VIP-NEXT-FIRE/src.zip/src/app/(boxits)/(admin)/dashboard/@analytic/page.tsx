export default function Analytic() {
  return (
    <div className="w-3/6 h-60 bg-gray-300 rounded-[10px] flex justify-center items-center">
      Analytic
    </div>
  );
}
