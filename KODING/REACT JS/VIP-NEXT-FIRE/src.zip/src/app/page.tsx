/* ini halaman utama saat url:root di akses */
export default function Home() {
  return (
    <div className="flex flex-col items-center min-h-screen justify-center">
      Halo Main Page
    </div>
  );
}
