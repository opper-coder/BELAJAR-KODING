import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";

export default function JumbotronServer() {
  // menubar ------------------------
  const items = [
    {
      label: "Add Region",
      icon: "pi pi-fw pi-plus",
      command: () => alert("Tambah Lokasi, properties, oleh root, SA, Admin"),
    },
    {
      label: "View Region",
      icon: "pi pi-fw pi-user",
      command: () => region(),
    },
    {
      label: "Deleted Node",
      icon: "pi pi-fw pi-trash",
      url: "./deletedAccount",
    },
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Root"
        subTitle="Node Location Root, Admin Assign "
        className="mb-4 surface-300"
      >
        <div className="flex gap-4 text-blue-700 m-0">
          <div className="flex-1">
            <b>Fungsi pokok</b>

            <ol>
              <li>Generate Location.</li>
              <li>Add Server</li>
              <li>Add AP</li>
              <li>Assign payee</li>
            </ol>
          </div>
          <div className="flex-1">
            <b>Fungsi tambahan</b>
            <ol>
              <li>Acuan Penugasan Paket Project oleh semua admin</li>
              <li>Acuan pemrosesan Project Server, Akses Point</li>
              <li>Acuan bagi titik lokasi kerjasama</li>
              <li>
                Acaun Lokasi bagi Investor dimana mereka membelanjakan modalnya
              </li>
            </ol>
            <ol>
              <li>Add root, Add child</li>
              <li>Edit Properties</li>
              <li>Delete Node</li>
              <li>Verify request child</li>
            </ol>
          </div>
        </div>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
