// export default function Latihan() {
//   function App() {
//     const handleInput = (name) => {
//       console.log("fungsi ini di panggil", name);
//     };
//     return <Input title="name" handleInput={handleInput} />;
//   }

//   function Input(props) {
//     const handleChange = (e) => {
//       console.log(e.target.value);
//     };
//     console.log(props);
//     props.handleInput();
//     return (
//       <>
//         <label>props.title</label>
//         <input onChange={handleChange}></input>
//       </>
//     );
//   }

//   return <></>;
// }

import { useState } from "react";

export default function App() {
  const [isNotif, setIsNotif] = useState(false);
  // ubahstate tunggal valid
  const notif = () => {
    setIsNotif(!isNotif);
  };
  // ubahstate pertama valid, kedua tidak valid
  const notif2 = () => {
    setIsNotif(!isNotif);
    setTimeout(() => {
      setIsNotif(!isNotif);
    }, 2000);
  };
  // ubahstate pertama valid, kedua valid (dalam callback)
  const notif3 = () => {
    setIsNotif(!isNotif);
    setTimeout(() => {
      setIsNotif((state) => !isNotif);
    }, 2000);
  };

  return <>gunakan datanya dengan even onclick disini!</>;
}
