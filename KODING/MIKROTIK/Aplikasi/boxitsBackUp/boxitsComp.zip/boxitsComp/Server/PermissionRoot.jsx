import { useState } from "react";
import { Checkbox } from "primereact/checkbox";
import { Button } from "primereact/button";

export default function PermissionRoot() {
  const [checked, setChecked] = useState(false);
  const [checked2, setChecked2] = useState(false);
  const [checked3, setChecked3] = useState(false);
  const [checked4, setChecked4] = useState(false);

  return (
    <>
      <div className="flex align-items-center bg-white my-3 py-2 px-5 border-round">
        <Checkbox
          onChange={(e) => setChecked(e.checked)}
          checked={checked}
          inputId="satu"
        ></Checkbox>
        <label htmlFor="satu" className="ml-2 mr-4">
          Add Server
        </label>
        <Checkbox
          onChange={(e) => setChecked2(e.checked)}
          checked={checked2}
          inputId="dua"
        ></Checkbox>
        <label htmlFor="dua" className="ml-2 mr-4">
          Add AP
        </label>
        <Checkbox
          onChange={(e) => setChecked3(e.checked)}
          checked={checked3}
          inputId="tiga"
        ></Checkbox>
        <label htmlFor="tiga" className="ml-2 mr-4">
          Del AP
        </label>
        <Checkbox
          onChange={(e) => setChecked4(e.checked)}
          checked={checked4}
          inputId="empat"
        ></Checkbox>
        <label htmlFor="empat" className="ml-2 mr-4">
          Del Reseller
        </label>
        <Button
          label="Submit Permission"
          icon="pi pi-cog"
          size="small"
          outlined
        />
      </div>
    </>
  );
}
