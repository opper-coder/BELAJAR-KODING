import { TabView, TabPanel } from "primereact/tabview";
import ServerListMenu from "./serverListMenu";
import ServerAP from "./ServerAP";
import ServerApOffline from "./ServerApOffline";
import ServerApPending from "./ServerApPending";

// import APListMenu from "./APListMenu";

export default function ServerServer() {
  return (
    <div className="card w-full">
      <TabView className="mt-2">
        <TabPanel header="Server">
          <div className="flex gap-2">
            <ServerListMenu />
            <ServerAP />
          </div>
        </TabPanel>
        <TabPanel header="Pending">
          <div className="flex gap-2">
            <ServerApPending />
          </div>
        </TabPanel>
        <TabPanel header="Offline">
          <div className="flex gap-2">
            <ServerApOffline />
          </div>
        </TabPanel>
      </TabView>
    </div>
  );
}
