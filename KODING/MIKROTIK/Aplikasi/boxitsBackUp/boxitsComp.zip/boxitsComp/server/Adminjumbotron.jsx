import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";

export default function AdminJumbotron() {
  // menubar ------------------------
  const items = [
    {
      label: "Add Unit",
      icon: "pi pi-fw pi-plus",
      command: () => alert("Tambah Seller Lokasi"),
    },
    {
      label: "Add Seller",
      icon: "pi pi-fw pi-plus",
      command: () => alert("Tambah Seller Lokasi"),
    },
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Admin"
        subTitle="Admin Server Managerial"
        className="mb-4 surface-300"
      >
        <div className="flex gap-4 text-blue-700 m-0">
          <div className="flex-1">
            <b>Fungsi pokok</b>

            <ul className="">
              <li>Menambahkan Account Dari Admin Sampai ke hilir</li>
              <li>
                Account yang di tampilkan Hanya downline yang ada dibawah Admin
                ini
              </li>
              <li>Node List Root Properties</li>
              <li>
                Penambahan Lokasi, dan account bisa di lakukan oleh admin secara
                request
              </li>
              <li>
                Super Admin bisa memverifikasi request Lokasi dan admin, sebagai
                activation
              </li>
            </ul>
          </div>
          <div className="flex-1">
            <b>Fungsi tambahan</b>
            <ol>
              <li>
                Mirip dengan kemampuan root, hanya saja khusus untuk downline
                saja
              </li>
              <li>Action</li>
              <li>Properties</li>
              <li>Delete</li>
              <li>Edit</li>
            </ol>
            <b>
              Oya untuk kecepatan bandwidth bisa di beritahukan kepada penjual
              hanya bisa optimal antara 25 user aktif -- yng aktif saat ini 26
              -- aktifkan tunggu beberapa saat lagi
            </b>
          </div>
        </div>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
