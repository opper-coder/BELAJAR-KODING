import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
// import { InputText } from "primereact/inputtext";
import TanggalLive from "../tanggalLive";

export default function SuperAdminJumbotron() {
  // menubar ------------------------
  const items = [
    {
      label: "Add Branch",
      icon: "pi pi-fw pi-plus",
      command: () => alert("Tambah Lokasi"),
    },
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Super Admin"
        subTitle="Admin Assign"
        className="mb-4 surface-300"
      >
        <div className="flex gap-4 text-blue-700 m-0">
          <div className="flex-1">
            <b>Fungsi pokok</b>

            <ul className="">
              <li>Menambahkan Account Dari Super Admin Sampai ke hilir</li>
              <li>
                Account yang di tampilkan Hanya downline yang ada dibawah Super
                Admin ini
              </li>
              <li>Node List Root Properties</li>
              <li>
                Penambahan Lokasi, dan account bisa di lakukan oleh admin secara
                request
              </li>
              <li>
                Super Admin bisa memverifikasi request Lokasi dan admin, sebagai
                activation
              </li>
            </ul>
          </div>
          <div className="flex-1">
            <b>Fungsi tambahan</b>
            <ol>
              <li>
                Mirip dengan kemampuan root, hanya saja khusus untuk downline
                saja
              </li>
              <li>Action</li>
              <li>Properties</li>
              <li>Delete</li>
              <li>Edit</li>
            </ol>
          </div>
        </div>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
