import { useState, useEffect, useRef } from "react";
import { Tree } from "primereact/tree";
import { NodeService } from "./service/NodeService";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { ContextMenu } from "primereact/contextmenu";
import { Message } from "primereact/message";
import { TabView, TabPanel } from "primereact/tabview";
import AdminTree from "../users/adminTree";

export default function FilterDemo() {
  const [nodes, setNodes] = useState([]);
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [expandedKeys, setExpandedKeys] = useState({});
  const [selectedNodeKey, setSelectedNodeKey] = useState(null);
  const cm = useRef(null);
  const cm2 = useRef(null);
  const menuModel = [
    {
      label: "Action",
      icon: "pi pi-fw pi-check",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => propProduct(selectedProduct),
    },
  ];

  const menu = [
    {
      label: "Properties",
      icon: "pi pi-info-circle",
      command: () => {
        alert("halo properties tree " + selectedNodeKey);
      },
    },

    {
      label: "Add Child",
      icon: "pi pi-plus",
      command: () => {
        alert("action server");
      },
    },
    {
      label: "Add SuperAdmin",
      icon: "pi pi-user",
      command: () => {
        alert("action server");
      },
    },
    {
      label: "Edit",
      icon: "pi pi-pencil",
      command: () => {
        alert("action server");
      },
    },
    {
      label: "Delete",
      icon: "pi pi-trash",
      command: () => {
        alert("halo delet tree " + selectedNodeKey);
      },
    },
    {
      label: "Toggle",
      icon: "pi pi-sort",
      command: () => {
        let _expandedKeys = { ...expandedKeys };

        if (_expandedKeys[selectedNodeKey])
          delete _expandedKeys[selectedNodeKey];
        else _expandedKeys[selectedNodeKey] = true;

        setExpandedKeys(_expandedKeys);
      },
    },
  ];

  useEffect(() => {
    NodeService.getTreeNodes().then((data) => setNodes(data));
  }, []);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  const viewProduct = (product) => {
    alert("action " + product.name);
  };
  const propProduct = (product) => {
    alert("halooo prop " + product.name);
  };

  useEffect(() => {
    NodeService.getTreeNodes().then((data) => setNodes(data));
  }, []);
  return (
    <>
      {/* ------------------------------------------------------ */}
      <div className="card my-4 bg-yellow-50"></div>

      <div className="cardx flex gap-2">
        <div>
          <Message
            severity="success"
            className="w-full justify-content-start px-4 mb-2"
            content={<div className="ml-2">Tree Users Actived</div>}
          />
          <ContextMenu model={menu} ref={cm2} />
          <Tree
            value={nodes}
            filter
            filterMode="lenient"
            filterPlaceholder="Lenient Filter"
            className="w-full md:w-30rem"
            expandedKeys={expandedKeys}
            onToggle={(e) => setExpandedKeys(e.value)}
            contextMenuSelectionKey={selectedNodeKey}
            onContextMenuSelectionChange={(e) => setSelectedNodeKey(e.value)}
            onContextMenu={(e) => cm2.current.show(e.originalEvent)}
          />
        </div>
        <div className="w-full">
          <Message
            severity="warn"
            className="w-full justify-content-start px-4 mb-2"
            content={<div className="ml-2">Pending...</div>}
          />
          <div className="card">
            <TabView>
              <TabPanel header="Adding Server...">
                <ContextMenu
                  model={menuModel}
                  ref={cm}
                  onHide={() => setSelectedProduct(null)}
                />
                <DataTable
                  value={products}
                  className="w-full"
                  size="small"
                  paginator
                  rows={6}
                  onContextMenu={(e) => cm.current.show(e.originalEvent)}
                  contextMenuSelection={selectedProduct}
                  onContextMenuSelectionChange={(e) =>
                    setSelectedProduct(e.value)
                  }
                >
                  <Column field="code" header="Code"></Column>
                  <Column field="name" header="Name"></Column>
                  <Column field="category" header="Category"></Column>
                  <Column field="quantity" header="Quantity"></Column>
                </DataTable>
              </TabPanel>
              <TabPanel header="Deleting Unit...">
                <ContextMenu
                  model={menuModel}
                  ref={cm}
                  onHide={() => setSelectedProduct(null)}
                />
                <DataTable
                  value={products}
                  className="w-full"
                  size="small"
                  paginator
                  rows={6}
                  onContextMenu={(e) => cm.current.show(e.originalEvent)}
                  contextMenuSelection={selectedProduct}
                  onContextMenuSelectionChange={(e) =>
                    setSelectedProduct(e.value)
                  }
                >
                  <Column field="code" header="Code"></Column>
                  <Column field="name" header="Name"></Column>
                  <Column field="category" header="Category"></Column>
                  <Column field="quantity" header="Quantity"></Column>
                </DataTable>
              </TabPanel>
              <TabPanel header="Deleting Seller...">
                <ContextMenu
                  model={menuModel}
                  ref={cm}
                  onHide={() => setSelectedProduct(null)}
                />
                <DataTable
                  value={products}
                  className="w-full"
                  size="small"
                  paginator
                  rows={6}
                  onContextMenu={(e) => cm.current.show(e.originalEvent)}
                  contextMenuSelection={selectedProduct}
                  onContextMenuSelectionChange={(e) =>
                    setSelectedProduct(e.value)
                  }
                >
                  <Column field="code" header="Code"></Column>
                  <Column field="name" header="Name"></Column>
                  <Column field="category" header="Category"></Column>
                  <Column field="quantity" header="Quantity"></Column>
                </DataTable>
              </TabPanel>
            </TabView>
          </div>
        </div>
      </div>
    </>
  );
}

// =================

{
  /* <Message
severity={classwarna}
className="w-full justify-content-start px-4"
content={
  <div className="ml-2">
    {judul}: <b>Rp. {jumlah}</b>
  </div>
}
/> */
}
