import { useState } from "react";
import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";

export default function ServerJumbotron() {
  const [date, setDate] = useState("null");

  // menubar ------------------------
  const items = [
    // {
    //   label: "Add Server",
    //   icon: "pi pi-fw pi-plus",
    //   command: () => alert("Tambah Mikrotik"),
    // },
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Servers"
        subTitle="Node Location Root, Server List, Access Point List"
        className="mb-4 surface-300 "
      >
        <div className="flex gap-4 text-blue-700 m-0">
          <div className="flex-1">
            <b>Fungsi pokok</b>

            <ul className="">
              <li>
                Monitoring Node Root Locations, Servers, Access Point List
              </li>
              <li>Melihat secara keseluruhan dalam wilayah</li>
              <li>Properties</li>
            </ul>
          </div>
          <div className="flex-1">
            <ul>
              <li>TreeView Server Location</li>
              <li>All server</li>
              <li>Access Point</li>
            </ul>
          </div>
        </div>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
