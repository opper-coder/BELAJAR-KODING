import React, { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Message } from "primereact/message";

export default function MenuInventory() {
  const [selectedCity, setSelectedCity] = useState(null);
  const groupedCities = [
    {
      label: "Server",
      icon: "pi pi-fw pi-server",
      items: [
        { label: "Mikrotik", value: "Mikrotik" },
        { label: "OpenWRT", value: "OpenWRT" },
        { label: "Ubiquity", value: "Ubiquity" },
      ],
    },
    {
      label: "Network",
      icon: "pi pi-fw pi-globe",
      items: [
        { label: "OLT", value: "OLT" },
        { label: "SFP", value: "SFP" },
        { label: "HTB", value: "HTB" },
        { label: "Switch", value: "Switch" },
        { label: "S Manageable", value: "S Manageable" },
        { label: "Router", value: "Router" },
      ],
    },
    {
      label: "Wiring",
      icon: "pi pi-fw pi-dollar",
      items: [
        { label: "Wire FO", value: "Wire FO" },
        { label: "Wire UTP", value: "Wire UTP" },
        { label: "Wire Electric", value: "Wire Electric" },
        { label: "Stop Contact", value: "Stop Contact" },
        { label: "Plug Electric", value: "Plug Electric" },
      ],
    },
    {
      label: "Wireless",
      icon: "pi pi-fw pi-wifi",
      items: [
        { label: "ONT", value: "ONT" },
        { label: "Router", value: "Router" },
        { label: "ESP8266", value: "ESP8266" },
        { label: "ESP32", value: "ESP32" },
        { label: "PTP 2.4 Ghz", value: "PTP 2.4 Ghz" },
        { label: "PTP 5 Ghz", value: "PTP 5 Ghz" },
      ],
    },
    {
      label: "Annualy",
      icon: "pi pi-fw pi-history",
      items: [
        { label: "Fast Connector", value: "Fast Connector" },
        { label: "Alcohol", value: "Alcohol" },
        { label: "Protector", value: "Protector" },
        { label: "Pigtail", value: "Pigtail" },
        { label: "Cleaver", value: "Cleaver" },
      ],
    },
    {
      label: "Equipment",
      icon: "pi pi-fw pi-wrench",
      items: [
        { label: "Splicer", value: "Splicer" },
        { label: "OPM", value: "OPM" },
        { label: "OTDR", value: "OTDR" },
        { label: "OLS(OpticalLightsource)", value: "OLS(OpticalLightsource)" },
        { label: "VFL(VisualFaultLocator)", value: "VFL(VisualFaultLocator)" },
        { label: "Tool Kit", value: "Tool Kit" },
      ],
    },
    {
      label: "Tools",
      icon: "pi pi-fw pi-history",
      items: [
        { label: "Tangga", value: "Tangga" },
        { label: "HT", value: "HT" },
        { label: "Savety Belt", value: "Savety Belt" },
        { label: "HeadLamp", value: "HeadLamp" },
      ],
    },
  ];

  const groupTemplate = (option) => {
    return (
      <div className="flex align-items-center gap-3 text-blue-800 border-bottom-1 pb-2 mt-3">
        <i className={option.icon}></i>
        <div>{option.label}</div>
      </div>
    );
  };

  return (
    <>
      <div>
        <Message
          severity="info"
          className="w-full mb-2 justify-content-start px-4"
          content={
            <div className="ml-2 ">
              Eqipment: <b>Mikrotik</b>
            </div>
          }
        />
        <ListBox
          value={selectedCity}
          onChange={(e) => {
            setSelectedCity(e.value);
            alert("halo " + e.value);
          }}
          options={groupedCities}
          optionLabel="label"
          optionGroupLabel="label"
          optionGroupChildren="items"
          optionGroupTemplate={groupTemplate}
          className="w-full md:w-14rem"
          listStyle={{ maxHeight: "450px" }}
        />
      </div>
    </>
  );
}
