import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";

export default function InventoryJumbotron2() {
  // menubar ------------------------
  const items = [
    {
      label: "Add Equipment",
      icon: "pi pi-fw pi-plus",
      items: [
        {
          label: "Internal Owner",
          icon: "pi pi-fw pi-bookmark",
          command: () => {
            alert("halo tambah");
          },
        },
        {
          label: "External Owner",
          icon: "pi pi-fw pi-bookmark",
        },
      ],
    },
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Inventory Penyesuaian Product"
        subTitle="Price Product Adaptation Area"
        className="mb-4 surface-300 "
      >
        <div className="flex">
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>Use Category</li>
              <li>Equipment Category</li>
              <li>Owner</li>
              <li>Age</li>
            </ul>
          </div>
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>Value</li>
              <li>Location</li>
              <li>Stock</li>
            </ul>
          </div>
        </div>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
