import { Message } from "primereact/message";
import UseCategory from "./useCategory";

export default function SummaryInventory() {
  return (
    <>
      <div className="w-full">
        <Message
          className="w-full mb-2 justify-content-start px-4"
          content={
            <p>
              Summary equipment List in area <b>Banggai</b> owner <b>Rafa</b>{" "}
            </p>
          }
        />
        <UseCategory />
      </div>
    </>
  );
}
