import { useState, useEffect, useRef } from "react";
import { Tree } from "primereact/tree";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { NodeService } from "./service/NodeService";
import { Message } from "primereact/message";
import { Checkbox } from "primereact/checkbox";

export default function AdminTree() {
  const [nodes, setNodes] = useState([]);
  const [expandedKeys, setExpandedKeys] = useState({});
  const [selectedNodeKey, setSelectedNodeKey] = useState(null);
  const [checked, setChecked] = useState(false);
  const toast = useRef(null);
  const cm = useRef(null);
  const menu = [
    {
      label: "Properties",
      icon: "pi pi-info-circle",
      command: () => alert("properties " + selectedNodeKey),
    },
    {
      label: "User List",
      icon: "pi pi-users",
      command: () => alert("properties ") + selectedNodeKey,
    },
    {
      label: "Assign",
      icon: "pi pi-link",
      command: () => alert("properties " + selectedNodeKey),
    },
    {
      label: "Toggle",
      icon: "pi pi-sort",
      command: () => {
        let _expandedKeys = { ...expandedKeys };

        if (_expandedKeys[selectedNodeKey])
          delete _expandedKeys[selectedNodeKey];
        else _expandedKeys[selectedNodeKey] = true;

        setExpandedKeys(_expandedKeys);
      },
    },
  ];

  useEffect(() => {
    NodeService.getTreeNodes().then((data) => setNodes(data));
  }, []);

  return (
    <>
      <Toast ref={toast} />
      <ContextMenu model={menu} ref={cm} />
      <div>
        <Message
          severity="info"
          className="w-full mb-2 p-2"
          content={
            <div className="w-full flex align-items-center">
              <Checkbox
                onChange={(e) => setChecked(e.checked)}
                checked={checked}
              ></Checkbox>
              <span className="mx-2">All</span>
              <b> | Gonggong</b>
            </div>
          }
        />
        <Tree
          value={nodes}
          expandedKeys={expandedKeys}
          onToggle={(e) => setExpandedKeys(e.value)}
          contextMenuSelectionKey={selectedNodeKey}
          onContextMenuSelectionChange={(e) => setSelectedNodeKey(e.value)}
          onContextMenu={(e) => cm.current.show(e.originalEvent)}
          className="w-full md:w-18rem"
          filter
          filterMode="lenient"
          filterPlaceholder="Cari Node Root"
        />
      </div>
    </>
  );
}
