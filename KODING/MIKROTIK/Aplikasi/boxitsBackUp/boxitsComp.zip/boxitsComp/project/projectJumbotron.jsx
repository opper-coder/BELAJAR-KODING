import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";
// import { InputText } from "primereact/inputtext";

export default function ProjectJumbotron() {
  // menubar ------------------------
  const items = [
    {
      label: "Add Project",
      icon: "pi pi-fw pi-plus",
      // command: () => alert("Tambah Lokasi"),
      items: [
        {
          label: "Mapping",
          icon: "pi pi-fw pi-map-marker",
          command: () => alert("Tambah Lokasi"),
        },
        {
          label: "Server",
          icon: "pi pi-fw pi-server",
          command: () => alert("Tambah Lokasi"),
        },
        {
          label: "Maintenace",
          icon: "pi pi-fw pi-wrench",
          command: () => alert("Tambah Lokasi"),
        },
        {
          label: "lainya",
          icon: "pi pi-fw pi-home",
          command: () => alert("Tambah Lokasi"),
        },
        {
          label: "Custom",
          icon: "pi pi-fw pi-cog",
          command: () => alert("Tambah Lokasi"),
        },
      ],
    },
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Project"
        subTitle="Project, Packet, Workflow, Cost, Assignment, Status"
        className="mb-4 surface-300"
      >
        <div className="flex gap-4 text-blue-700 m-0">
          <div className="flex-1">
            <b>Fungsi pokok</b>
            {/* -------------------------- */}
            <ol>
              <li>
                Add project: Mapping, Server, Maintenace, Other and Release
              </li>
              <li>Project, Packet, Workflow and Cost list </li>
              <li>Create Project on aLocation</li>
            </ol>
            {/* -------------------------- */}
            <b>Assign</b>
            <ol>
              <li>Assign Project and Properties</li>
              <li>Release Product, Ready to Investor, Public And Monitoring</li>
            </ol>
          </div>
          <div className="flex-1">
            <b>Status</b>
            <ul>
              <li>Request, Active, Pending, Finish, Change</li>
              <li>
                Project Hanya bisa di StarUp dan finishkan oleh Super Admin
              </li>
              <li>
                Finish akan mengakibatkan honor langsung tersalurkan kepada
                petugas
              </li>
              <li>
                Project yang di buat tidak bisa di hapus kecuali oleh Super
                admin
              </li>
            </ul>
          </div>
        </div>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
