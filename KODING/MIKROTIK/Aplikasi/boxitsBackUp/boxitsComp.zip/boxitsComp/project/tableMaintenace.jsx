import React, { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Tag } from "primereact/tag";
import { CustomerService } from "./service/CustomerService.js";
import { Image } from "primereact/image";
import { ProgressBar } from "primereact/progressbar";

export default function TableMaintenance() {
  const [customers, setCustomers] = useState([]);
  const [expandedRows, setExpandedRows] = useState([]);

  useEffect(() => {
    CustomerService.getCustomersMedium().then((data) => setCustomers(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const headerTemplate = (data) => {
    return (
      <React.Fragment>
        <Image
          alt={data.representative.name}
          src={`https://primefaces.org/cdn/primereact/images/avatar/${data.representative.image}`}
          width="32"
          style={{ verticalAlign: "middle" }}
          className="ml-2"
        />
        <span className="vertical-align-middle ml-2 font-bold line-height-3">
          {data.representative.name}
        </span>
        <span className="ml-5">
          <ProgressBar
            value={data.activity}
            showValue={false}
            style={{ height: "3px" }}
            className="w-2x"
          ></ProgressBar>
        </span>
      </React.Fragment>
    );
  };

  const footerTemplate = (data) => {
    return (
      <React.Fragment>
        <td colSpan={5}>
          <div className="flex justify-content-end font-bold w-full">
            Total Harga Paket:{" "}
            {calculateCustomerTotal(data.representative.name)}
          </div>
        </td>
      </React.Fragment>
    );
  };

  const countryBodyTemplate = (rowData) => {
    return (
      <div className="flex align-items-center gap-2">
        <Image
          alt={rowData.country.name}
          src="https://primefaces.org/cdn/primereact/images/flag/flag_placeholder.png"
          className={`flag flag-${rowData.country.code}`}
          style={{ width: "24px" }}
        />
        <span>{rowData.country.name}</span>
      </div>
    );
  };

  const statusBodyTemplate = (rowData) => {
    return (
      <Tag value={rowData.status} severity={getSeverity(rowData.status)} />
    );
  };

  const calculateCustomerTotal = (name) => {
    let total = 0;

    if (customers) {
      for (let customer of customers) {
        if (customer.representative.name === name) {
          total++;
        }
      }
    }

    return total;
  };

  const getSeverity = (status) => {
    switch (status) {
      case "unqualified":
        return "danger";

      case "qualified":
        return "success";

      case "new":
        return "info";

      case "negotiation":
        return "warning";

      case "renewal":
        return null;
    }
  };
  // ini status yang pakai ----- <> ----- <> ----- <> -----
  const getSeverity2 = (status) => {
    switch (status) {
      case "Request":
        return "danger";

      case "Finish":
        return "success";

      case "Active":
        return "info";

      case "Pending":
        return "warning";

      case "Change":
        return null;
    }
  };
  // Row selection ----- <> ----- <> ----- <> ----- <> -----
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const onRowSelect = (event) => {
    alert("halo " + event.data.name);
  };
  // const onRowUnSelect = (event) => {
  //   alert("halo " + event.data.name);
  // };

  useEffect(() => {
    CustomerService.getCustomersMedium().then((data) => setProducts(data));
  }, []);

  return (
    <>
      <div className="card w-full">
        <DataTable
          value={customers}
          rowGroupMode="subheader"
          groupRowsBy="representative.name"
          sortMode="single"
          sortField="representative.name"
          sortOrder={1}
          expandableRowGroups
          expandedRows={expandedRows}
          onRowToggle={(e) => setExpandedRows(e.data)}
          rowGroupHeaderTemplate={headerTemplate}
          rowGroupFooterTemplate={footerTemplate}
          tableStyle={{ minWidth: "10rem" }}
          size="small"
          resizableColumns
          paginator
          rows={25}
          // Row selection ------
          selectionMode="single"
          selection={selectedProduct}
          onSelectionChange={(e) => setSelectedProduct(e.value)}
          dataKey="id"
          onRowSelect={onRowSelect}
          // onRowUnselect={onRowUnselect}
          metaKeySelection={false}
        >
          <Column field="name" header="Server/Paket"></Column>
          <Column
            field="country"
            header="Lokasi Desa"
            body={countryBodyTemplate}
          ></Column>
          <Column field="company" header="Assignment"></Column>
          <Column field="company" header="Cost"></Column>
          <Column field="company" header="Progress"></Column>
          <Column
            field="status"
            header="Status"
            body={statusBodyTemplate}
          ></Column>
          <Column field="date" header="Date"></Column>
          <Column field="date" header="DeatLine"></Column>
        </DataTable>
      </div>
    </>
  );
}
