import { TabView, TabPanel } from "primereact/tabview";
import { Message } from "primereact/message";
import TableServer from "./tableServer";
import TableMapping from "./tableMapping";
import TableLainya from "./tableLainya";
import TableRelease from "./tableRelease";
import TableMaintenance from "./tableMaintenace";
import TableMapping1 from "./tableMapping1";
import TableServer1 from "./tableServer1";
import TableMaintenance1 from "./tableMaintenace1";
import TableLainya1 from "./tableLainya1";
import TableReleaseInvestor from "./tableReleaseInvestor";

function Judul(props) {
  return (
    <>
      <Message
        className="border-primary justify-content-start w-full mb-2"
        severity={props.severity}
        content={
          <div className="ml-2">
            Daftar Packet <b>{props.nama}</b>
          </div>
        }
      />
    </>
  );
}

export default function TabProject() {
  return (
    <>
      <TabView>
        <TabPanel header="Mapping">
          <div className="flex gap-2">
            <div>
              <Judul nama="Mapping, Ready!" severity="warn" />
              <TableMapping1 />
            </div>
            <div className="flex-1">
              <Judul nama="Mapping, Running..." severity="info" />
              <TableMapping />
            </div>
          </div>
        </TabPanel>
        <TabPanel header="Server">
          <div className="flex gap-2">
            <div>
              <Judul nama="Server, Ready!" severity="warn" />
              <TableServer1 />
            </div>
            <div className="flex-1">
              <Judul nama="Server, Running..." severity="info" />
              <TableServer />
            </div>
          </div>
        </TabPanel>
        <TabPanel header="Maintenance">
          <div className="flex gap-2">
            <div>
              <Judul nama="Maintenance, Ready!" severity="warn" />
              <TableMaintenance1 />
            </div>
            <div className="flex-1">
              <Judul nama="Maintenance, Running..." severity="info" />
              <TableMaintenance />
            </div>
          </div>
        </TabPanel>
        <TabPanel header="Lainya">
          <div className="flex gap-2">
            <div>
              <Judul nama="lainya, Ready!" severity="warn" />
              <TableLainya1 />
            </div>
            <div className="flex-1">
              <Judul nama="lainya, Running..." severity="info" />
              <TableLainya />
            </div>
          </div>
        </TabPanel>
        <TabPanel header="Release">
          <div className="flex gap-2">
            <div className="flex-1">
              <Judul nama="Released" severity="success" />
              <TableRelease />
            </div>
            <div className="flex-1">
              <Judul nama="Investor" severity="info" />
              <TableReleaseInvestor />
            </div>
          </div>
        </TabPanel>
      </TabView>
    </>
  );
}
