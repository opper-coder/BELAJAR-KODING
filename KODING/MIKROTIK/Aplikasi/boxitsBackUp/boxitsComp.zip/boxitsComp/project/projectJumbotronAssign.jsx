import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";
export default function ProjectJumbotronAssign() {
  const items = [
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex">
      <TanggalLive />
    </div>
  );
  return (
    <>
      <Card
        title="Project"
        subTitle="Project, Packet, Workflow, Cost, Assignment, Status"
        className="mb-4 surface-300"
      >
        <div className="flex gap-4 text-blue-700 m-0">
          <div className="flex-1">
            <b>Fungsi pokok</b>
            <ul className="">
              <li>
                Project Assign, adalah penugasan daftar project yang telah di
                buat di new project
              </li>
              <li>Penugasan di buat oleh admin di verify oleh superadmin</li>
              <li>Finish di lakukan oleh super Admin Project </li>
              <li>
                Finish akan mengakibatkan honor langsung tersalurkan kepada
                petugas
              </li>
            </ul>
          </div>
          <div className="flex-1">
            <b>Fungsi tambahan</b>
            <ol>
              <li>Request</li>
              <li>Properties</li>
              <li>Edit</li>
              <li>Status: Request, Active, Pending, Finish, Change</li>
            </ol>
            <ul></ul>
          </div>
        </div>
      </Card>
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
