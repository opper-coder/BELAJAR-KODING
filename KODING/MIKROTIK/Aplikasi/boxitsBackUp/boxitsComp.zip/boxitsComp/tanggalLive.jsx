import { useEffect, useState } from "react";
export default function TanggalLive() {
  const [tahun, setTahun] = useState(0);
  const [bulan, setBulan] = useState(0);
  const [tanggal, setTanggal] = useState(0);
  const [hari, setHari] = useState(0);
  const [jam, setJam] = useState(0);
  const [menit, setMenit] = useState(0);
  const [detik, setDetik] = useState(0);
  const [h24, setH24] = useState(false);
  useEffect(() => {
    const update = () => {
      const date = new Date();
      let jam = date.getHours();
      !h24 ? (jam = jam % 12 || 12) : jam;
      setDetik(date.getSeconds());
      setMenit(date.getMinutes());
      setJam(jam);
      setHari(date.getDay());
      setTanggal(date.getDate());
      setBulan(date.getMonth());
      setTahun(date.getFullYear());
    };
    update();
    const interval = setInterval(() => {
      update();
    }, 1000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const arrayHari = [
    "Minggu",
    "Senin",
    "Selasa",
    "Rabu",
    "Kamis",
    "Jum'at",
    "Sabtu",
  ];
  const arrayBulan = [
    "Januari",
    "Pebruari",
    "Maret",
    "April",
    "Mei",
    "Juni",
    "Juli",
    "Agustus",
    "September",
    "Oktober",
    "Novemver",
    "Desember",
  ];
  return (
    <>
      <div className="mr-2">
        <b className="mr-2">
          {jam}:{menit}:{detik} |
        </b>
        {arrayHari[hari]}, {tanggal} {arrayBulan[bulan]} {tahun} |
      </div>
    </>
  );
}
