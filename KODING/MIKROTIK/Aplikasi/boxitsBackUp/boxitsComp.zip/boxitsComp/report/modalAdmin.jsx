import { Calendar } from "primereact/calendar";
import { useState } from "react";
import { Message } from "primereact/message";
import NavigasiRoot from "../NavigasiRoot";
import DebetAdmin from "./DebetAdmin";
import KreditAdmin from "./KreditAdmin";

export default function ModalAdmin() {
  const [date, setDate] = useState(null);
  return (
    <>
      <div className="flex justify-content-between align-items-center">
        <Calendar
          value={date}
          onChange={(e) => setDate(e.value)}
          view="month"
          showIcon
        />
        <span>
          Saldo: <b>10.000.000</b>
        </span>
      </div>
      <div className="flex mt-2">
        <div className="flex gap-2 w-full">
          <NavigasiRoot />
          <div>
            <Message
              className="w-full mb-2"
              severity="success"
              content={
                <div className="w-full flex justify-content-between">
                  <span>Debet Admin</span>
                  <b>Rp. 200.000.000</b>
                </div>
              }
            />
            <div className="card ">
              <DebetAdmin />
            </div>
          </div>
          <div className="flex-1">
            <Message
              className="w-full mb-2"
              severity="warn"
              content={
                <div className="w-full flex justify-content-between">
                  <span>Kredit Admin</span>
                  <b>Rp. 200.000.000</b>
                </div>
              }
            />
            <div className="card">
              <KreditAdmin />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
