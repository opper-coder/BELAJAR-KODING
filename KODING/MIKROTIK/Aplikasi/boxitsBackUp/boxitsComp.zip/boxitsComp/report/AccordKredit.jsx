import { Accordion, AccordionTab } from "primereact/accordion";
import { useState } from "react";
import SaldoReseller from "./SaldoReseller";

export default function AccordKredit() {
  const [reseller, setReseller] = useState(100000000);
  const [pasang, setPasang] = useState(10000000);
  const [iklan, setIklan] = useState(1000000);
  const [bonus, setBonus] = useState(1000000);
  const [product, setProduct] = useState(10000000);

  const tab1HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Packet</span>
          <span className="text-orange-500">{reseller}</span>
        </div>
      </>
    );
  };
  const tab2HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Insentif</span>
          <span className="text-orange-500">{pasang}</span>
        </div>
      </>
    );
  };
  const tab3HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Iklan</span>
          <span className="text-orange-500">{iklan}</span>
        </div>
      </>
    );
  };
  const tab4HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Bonus</span>
          <span className="text-orange-500">{bonus}</span>
        </div>
      </>
    );
  };
  const tab5HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Product</span>
          <span className="text-orange-500">{product}</span>
        </div>
      </>
    );
  };

  return (
    <Accordion activeIndex={0}>
      <AccordionTab header="Saldo Reseller" headerTemplate={tab5HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
      <AccordionTab header="Saldo Reseller" headerTemplate={tab1HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
      <AccordionTab header="Pasang Baru" headerTemplate={tab2HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
      <AccordionTab header="Iklan" headerTemplate={tab3HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
      <AccordionTab header="Iklan" headerTemplate={tab4HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
    </Accordion>
  );
}
