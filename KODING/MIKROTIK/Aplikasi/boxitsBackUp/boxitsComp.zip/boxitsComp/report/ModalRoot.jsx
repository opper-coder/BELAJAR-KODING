import { useState } from "react";
import { Calendar } from "primereact/calendar";
import { Message } from "primereact/message";
import DebetRoot from "./DebetRoot";
import KreditRoot from "./KreditRoot";

export default function ModalRoot() {
  const [date, setDate] = useState(null);
  return (
    <>
      <div className="flex justify-content-between align-items-center">
        <Calendar
          value={date}
          onChange={(e) => setDate(e.value)}
          view="month"
          showIcon
        />
        <span>
          Saldo: <b>10.000.000</b>
        </span>
      </div>
      {/* tab  */}
      <div className="flex gap-2 mt-2">
        <div className="flex-1">
          <Message
            className="w-full"
            content={
              <div className="w-full flex justify-content-between">
                <span>Generate Capital</span>
                <b>Rp. 200.000.000</b>
              </div>
            }
          />
          <DebetRoot />
        </div>
        <div className="flex-1">
          <Message
            className="w-full"
            severity="warn"
            content={
              <div className="w-full flex justify-content-between">
                <span>Transfer</span>
                <b>Rp. 190.000.000</b>
              </div>
            }
          />
          <KreditRoot />
        </div>
      </div>
    </>
  );
}
