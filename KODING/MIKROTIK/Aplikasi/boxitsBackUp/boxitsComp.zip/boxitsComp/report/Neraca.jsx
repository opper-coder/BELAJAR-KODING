import { Message } from "primereact/message";
import AccordDebet from "./AccordDebet";
import AccordKredit from "./AccordKredit";

export default function Neraca() {
  return (
    <>
      <div className="card flex gap-3">
        <Message
          className="w-full mb-2"
          severity="success"
          content={
            <span>
              <span className="mr-2">Pemasukan bersih:</span>
              <strong>1.000.000.000</strong>
            </span>
          }
        />
        <Message
          className="w-full mb-2"
          severity="warn"
          content={
            <span>
              <span className="mr-2">Pengeluaran bersih:</span>
              <strong>1.000.000</strong>
            </span>
          }
        />
      </div>
      <div className="border-1 border-round-xl border-300 p-2">
        {/* <div> */}
        <div className="flex gap-2">
          <div className="flex-1">
            <AccordDebet />
          </div>
          <div className="flex-1">
            <AccordKredit />
          </div>
        </div>
      </div>
    </>
  );
}
