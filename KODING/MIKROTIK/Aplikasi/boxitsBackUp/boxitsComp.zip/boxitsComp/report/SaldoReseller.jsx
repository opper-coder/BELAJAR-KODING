import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";

export default function SaldoReseller() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProductsMini().then((data) => setProducts(data));
  }, []);

  return (
    <DataTable
      value={products}
      tableStyle={{ minWidth: "50rem" }}
      size="small"
      paginator
      rows={5}
    >
      <Column field="code" header="Code"></Column>
      <Column field="name" header="Admin"></Column>
      <Column field="quantity" header="tanggal"></Column>
    </DataTable>
  );
}
