import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";

export default function ReportJumbotron() {
  // menubar ------------------------
  const items = [
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
      //   command: () => {
      //     alert("halo tambah");
      //   },
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Report"
        subTitle="Voucher, Inventory, Project, Cost, Margin, Revenue, "
        className="mb-4 surface-300 "
      >
        <div className="flex">
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>Multi User Sign In</li>
              <li>Multi Location Access Point</li>
              <li>Multi Bussines Metode</li>
            </ul>
          </div>
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>Accounting Product</li>
              <li>Accounting Packet</li>
              <li>Accounting Cost</li>
            </ul>
          </div>
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>Accounting balance</li>
              <li>Accounting Margin</li>
              <li>Accounting Revenue</li>
            </ul>
          </div>
        </div>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
