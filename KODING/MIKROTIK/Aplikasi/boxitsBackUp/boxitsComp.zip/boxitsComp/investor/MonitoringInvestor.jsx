export default function MonitoringInvestor() {
  return (
    <>
      <div className="card">
        <ul>
          <li>list active voucher realtime</li>
          <li>jumlah pendapatan realtime</li>
          <li>tanggal jatuh tempo</li>
          <li>status on/off</li>
          <li>operasional, listrik, langganan ISP, fup</li>
          <li></li>
        </ul>
      </div>
    </>
  );
}
