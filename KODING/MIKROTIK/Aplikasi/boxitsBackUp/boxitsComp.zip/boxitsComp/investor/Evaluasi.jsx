/* eslint-disable react/jsx-key */
import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService.js";
import { Message } from "primereact/message";
import { Divider } from "primereact/divider";
import NavigasiRoot from "../NavigasiRoot";

export default function Evaluasi() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);
  // ----------------------

  const arrayProp = [
    { field: "start", isi: 23, harga: 0, jumlah: 100000 },
    { field: "voucher2000", isi: 24, harga: 2000, jumlah: 100000 },
    { field: "voucher3000", isi: 25, harga: 2000, jumlah: 100000 },
    { field: "voucher5000", isi: 22, harga: 2000, jumlah: 100000 },
    { field: "voucher10000", isi: 26, harga: 2000, jumlah: 100000 },
    { field: "voucher25000", isi: 27, harga: 2000, jumlah: 100000 },
    { field: "Data1Gb", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "Data2Gb", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "Data4Gb", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "Data8Gb", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "Data10Gb", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "Data12Gb", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "Data16Gb", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "PPPoE", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "saldo", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "promo", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "insentif", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "Refund", isi: 3, harga: 2000, jumlah: 100000 },
    { field: "Printing", isi: 3, harga: 2000, jumlah: 100000 },
  ];

  const arrayBelanja = ["ada", "baba", "caca"];

  // ----------------------
  return (
    <>
      {/* --------------- */}
      <div className="card surface-100x bg-green-100 mt-4">
        <p>
          Tab Evaluasi ini Bisa melihat Per Unit Kerja: performa, pendapatan dan
          user aktif secara Realtime, Di Bawah ini terdapat gambaran umum
          kalkulasi estimasi Harga investasi dan pendapatan
        </p>
        <div className="flex">
          <ul className="list-none flex-1">
            <li>
              <b>Analisis</b>
            </li>
            <ul className="list-disc">
              <li>Nilai Investasi</li>
              <li>hari ke </li>
              <li>
                <b>Omzet</b>
              </li>
              <li>pendapatan kotor rata-rata perhari, hari ini</li>
              <li>pendapatan estimasi perbulan </li>
              <li>
                <b>Biaya</b>
              </li>
              <li>biaya wajib bulanan: telkom </li>
              <li>biaya FUP</li>
              <li>biaya perawatan: xxx</li>
              <li>biaya listrik</li>
              <li>biaya ke pihak petugas dan pemilik sewa</li>
              <li>
                <b>total biaya</b>
              </li>
              <li>share profit</li>
              <li>nilai share profit/bulan</li>
              <li>nilai share profit/tahun</li>
            </ul>
          </ul>
          <Divider layout="vertical" />
          <ul className="text-green-800 text-right list-none">
            <li>-</li>
            <li>Rp. 20.000.000</li>
            <li>-</li>
            <li>-</li>
            <li>-</li>
            <li>-</li>
            <li>------</li>
            <li>-</li>
            <li>-</li>
            <li>-</li>
            <li>-</li>
            <li>-</li>
            <li>-</li>
            <li>25%</li>
            <li>1.500.000</li>
            <li>15.000.000</li>
          </ul>
          <ul className="text-green-800 text-right list-none">
            <li>-</li>
            <li>-</li>
            <li>4 hari</li>
            <li>Rp. 800.000</li>
            <li>Rp. 200.000</li>
            <li>Rp. 4.500.000</li>
            <li>-----</li>
            <li>RP. 368.000</li>
            <li>RP. 400.000</li>
            <li>RP. 200.000</li>
            <li>RP. 200.000</li>
            <li>RP. 300.000</li>
            <li>RP. 1.500.000</li>
            <li>-</li>
            <li>-</li>
            <li>-</li>
          </ul>
          <Divider layout="vertical" />
          <ul className="list-none flex-1">
            <li>
              <b>Langkah selanjutnya</b>
            </li>
            <ol>
              <li>evaluasi pendapatan</li>
              <li>ambil paket</li>
              <li>tentukan lokasi pasar</li>
              <li>ambil buffering</li>
              <li>cek out</li>
              <li>monitoring pelaksanaan</li>
              <li>cairkan profit</li>
              <li>akhir kontrak</li>
              <li>perpanjang</li>
              <li>kontrak baru</li>
            </ol>
          </ul>
        </div>
      </div>

      {/* --------------- */}
      <div className="flex gap-2">
        <NavigasiRoot />
        <div className="card flex-1">
          <Message
            content={
              <span>
                Jumlah Product Terdistribusi (pemasukan dan pengeluaran)
              </span>
            }
            className="w-full border-1 border-blue-400"
          />
          <DataTable
            value={products}
            tableStyle={{ minWidth: "20rem" }}
            size="small"
            rows={10}
            paginator
          >
            <Column field="code" header="Code"></Column>
            <Column field="name" header="Name"></Column>
            <Column field="category" header="Category"></Column>
            <Column field="quantity" header="Quantity"></Column>
          </DataTable>
        </div>
        <div className="card surface-100">
          <Message
            content={<span>Jumlah Pemasukan</span>}
            className="w-full border-1 border-green-500"
            severity="success"
          />
          <DataTable
            value={arrayProp}
            tableStyle={{ minWidth: "20rem" }}
            size="small"
            rows={10}
            paginator
          >
            <Column
              field="field"
              header="Terjual"
              className="surface-100"
            ></Column>
            <Column
              field="isi"
              header="jumlah"
              className="surface-100"
            ></Column>
            <Column
              field="harga"
              header="Harga"
              className="surface-100"
            ></Column>
            <Column
              field="jumlah"
              header="Jumlah"
              className="surface-100"
              body={(product) => {
                return product.isi * product.harga;
              }}
            ></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
