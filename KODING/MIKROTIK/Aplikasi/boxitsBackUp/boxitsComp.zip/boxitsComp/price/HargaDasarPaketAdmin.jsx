import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { Message } from "primereact/message";

export default function HargaDasarPaketAdmin() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  return (
    <div>
      <Message
        className="w-full justify-content-start px-4"
        severity="info"
        content={<b>Harga Dasar</b>}
      />

      <div className="card mt-2">
        <DataTable
          value={products}
          tableStyle={{ minWidth: "20rem" }}
          size="small"
          resizableColumns
          paginator
          rows={10}
        >
          <Column field="code" header="Code"></Column>
          <Column field="name" header="Paket"></Column>
          <Column field="category" header="Quota"></Column>
          <Column field="quantity" header="Bandwidth"></Column>
          <Column field="quantity" header="MAC"></Column>
        </DataTable>
      </div>
    </div>
  );
}
