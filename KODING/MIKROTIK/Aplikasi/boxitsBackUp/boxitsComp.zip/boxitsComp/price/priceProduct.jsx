import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { Button } from "primereact/button";
export default function PriceProduct() {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);
  return (
    <>
      <div>
        <div className="flex gap-2 mb-2">
          <Button
            label="Add"
            icon="pi pi-plus"
            onClick={() => alert("halo tambah Packet")}
            outlined
            className="flex-1"
          />
          <Button
            icon="pi pi-pencil "
            aria-label="Filter"
            outlined
            onClick={() => alert("halo tambahkan data")}
          />
        </div>
        <div className="card">
          <DataTable
            value={products}
            tableStyle={{ minWidth: "30rem" }}
            size="small"
            resizableColumns
            paginator
            rows={10}
          >
            <Column field="code" header="Product"></Column>
            <Column field="code" header="Harga"></Column>
            <Column field="name" header="Quota"></Column>
            <Column field="category" header="Bandwidth"></Column>
            <Column field="quantity" header="Durasi"></Column>
            <Column field="quantity" header="MAC"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
