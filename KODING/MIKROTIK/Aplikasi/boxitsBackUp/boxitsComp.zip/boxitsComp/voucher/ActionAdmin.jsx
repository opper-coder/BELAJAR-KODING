import { TabView, TabPanel } from "primereact/tabview";
import SidebarAdminProduct from "./SidebarAdminProduct";
import SidebarAdminPacket from "./SidebarAdminPacket";
import SidebarAdminInsentif from "./SidebarAdminInsentif";
import SidebarAdminPromo from "./SidebarAdminPromo";
import SidebarAdminIklan from "./SidebarAdminIklan";
import AdminTree from "../users/adminTree";
import TableActionProductA from "./TableActionProductA";
import TableActionPacketA from "./TableActionPacketA";
import TableActionInsentifA from "./TableActionInsentifA";
import TableActionPromoA from "./TableActionPromoA";
import TableActionIklanA from "./TableActionIklanA";

export default function ActionAdmin() {
  return (
    <>
      <section>
        <article>
          <TabView>
            <TabPanel header="Product">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminProduct />
                <TableActionProductA />
              </div>
            </TabPanel>
            <TabPanel header="Packet">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminPacket />
                <TableActionPacketA />
              </div>
            </TabPanel>
            <TabPanel header="Insentif">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminInsentif />
                <TableActionInsentifA />
              </div>
            </TabPanel>
            <TabPanel header="Promo">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminPromo />
                <TableActionPromoA />
              </div>
            </TabPanel>
            <TabPanel header="Iklan">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminIklan />
                <TableActionIklanA />
              </div>
            </TabPanel>
          </TabView>
        </article>
      </section>
    </>
  );
}
