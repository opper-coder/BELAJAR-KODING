import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService.jsx";
// context
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
// -----
import { Message } from "primereact/message";
// -----
export default function PriceEquipmentP() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProductsMini().then((data) => setProducts(data));
  }, []);

  const statusBodyTemplate2 = (product) => {
    if (product.quantity < 40 && product.rating == 3) {
      // jika harga product > dari standard  dan verify OK
      return <i className="pi pi-caret-up text-blue-500"></i>;
    } else if (product.quantity < 40 && product.rating > 3) {
      // jika harga product < dari standard  dan verify OK
      return <i className="pi pi-caret-down text-green-500"></i>;
    } else {
      // jika verify false
      return <i className="pi pi-info-circle text-red-500"></i>;
    }
  };
  // context ----------------------------------
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Verify",
      icon: "pi pi-fw pi-thumbs-up",
      command: () => viewProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    alert(product.name);
  };

  // end context ----------------------------------
  return (
    <>
      <div className="flex-1">
        <Message
          severity="info"
          className="w-full mb-2 justify-content-start px-4"
          content={
            <div className="ml-2 ">
              Penyesuaian Root <b>Equipment</b>
            </div>
          }
        />
        <div className="card mr-2 w-full">
          <Toast ref={toast} />
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />
          <DataTable
            value={products}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
            tableStyle={{ minWidth: "30rem" }}
            size="small"
            resizableColumns
            paginator
            rows={8}
          >
            <Column field="name" header="Unit"></Column>
            <Column
              field="quantity"
              header="Status"
              body={statusBodyTemplate2}
            ></Column>
            <Column field="quantity" header="Selisih"></Column>
            <Column field="code" header="Paket"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
