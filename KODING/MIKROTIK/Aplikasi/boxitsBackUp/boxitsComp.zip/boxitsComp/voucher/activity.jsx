import { TabView, TabPanel } from "primereact/tabview";
import Transfer from "./transfer";
import Request from "./request";
import All from "./all";

export default function Activity() {
  const tab1 = (options) => {
    return (
      <div
        className={options.className}
        style={{ cursor: "pointer" }}
        onClick={options.onClick}
      >
        <i className="pi pi-file-import mr-2" />
        <span>Request</span>
        <p
          style={{
            marginLeft: "10px",
            padding: ".5px",
            borderRadius: "10px",
            textAlign: "center",
            backgroundColor: "#ff4343",
            color: "white",
            fontSize: "10px",
            display: "inline-block",
            minWidth: "20px",
          }}
        >
          45
        </p>
      </div>
    );
  };
  const tab2 = (options) => {
    return (
      <div
        className={options.className}
        style={{ cursor: "pointer" }}
        onClick={options.onClick}
      >
        <i className="pi pi-file-export mr-2" />
        <span>Transfer</span>
        <b className="text-blue-700 ml-3">12</b>
      </div>
    );
  };
  const tab3 = (options) => {
    return (
      <div
        className={options.className}
        style={{ cursor: "pointer" }}
        onClick={options.onClick}
      >
        <i className="pi pi-file mr-2" />
        <span>All</span>
        <b className="text-blue-700 ml-3">56</b>
      </div>
    );
  };
  return (
    <>
      <div>
        <TabView>
          <TabPanel headerTemplate={tab1}>
            <Request />
          </TabPanel>
          <TabPanel headerTemplate={tab2}>
            <Transfer />
          </TabPanel>
          <TabPanel headerTemplate={tab3}>
            <All />
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
