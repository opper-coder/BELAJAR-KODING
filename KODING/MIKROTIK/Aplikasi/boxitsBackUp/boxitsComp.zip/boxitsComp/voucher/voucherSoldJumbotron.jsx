import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import { InputText } from "primereact/inputtext";
import TanggalLive from "../tanggalLive";

export default function VoucherSoldJumbotron() {
  // menubar ------------------------
  const items = [
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Voucher Sold"
        subTitle="Voucher List Sold"
        className="mb-4 surface-300 "
      >
        <ul className="text-blue-700 m-0">
          <li>For Admin</li>
          <li>Monitoring status Voucher Activated</li>
          <li>Traffic Monitoring</li>
          <li>Search By Location</li>
        </ul>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
