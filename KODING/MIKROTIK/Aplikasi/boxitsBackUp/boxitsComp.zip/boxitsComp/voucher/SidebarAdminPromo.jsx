import React, { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Message } from "primereact/message";
import { Badge } from "primereact/badge";

export default function SidebarAdminPromo() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const countries = [
    { name: "Bulan", icon: "pi pi-star-fill mr-3", notif: "30" },
    { name: "Pekan", icon: "pi pi-star-fill mr-3", notif: "10" },
    { name: "Hari", icon: "pi pi-star-fill mr-3", notif: "12" },
  ];

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
        <Badge
          value={option.notif}
          className="ml-auto"
          severity="success"
        ></Badge>
      </div>
    );
  };

  return (
    <div>
      <Message
        className=" w-full mb-2 justify-content-start"
        severity="info"
        content={
          <span>
            Promo: <b>Pekan</b>
          </span>
        }
      />
      <ListBox
        value={selectedCountry}
        onChange={(e) => {
          setSelectedCountry(e.value);
          alert("halo " + e.value.name);
        }}
        options={countries}
        optionLabel="name"
        itemTemplate={countryTemplate}
        className="w-full md:w-14rem"
        listStyle={{ maxHeight: "400px" }}
      />
    </div>
  );
}
