import React, { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Message } from "primereact/message";
import { Badge } from "primereact/badge";

export default function SidebarAdminInsentif() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const countries = [
    { name: "Root", icon: "pi pi-star-fill mr-3", notif: "30" },
    { name: "Investor", icon: "pi pi-star-fill mr-3", notif: "10" },
    { name: "Biro", icon: "pi pi-star-fill mr-3", notif: "12" },
    { name: "Paket", icon: "pi pi-star-fill mr-3", notif: "1" },
    { name: "Teknisi", icon: "pi pi-star-fill mr-3", notif: "1" },
    { name: "SPPD", icon: "pi pi-star-fill mr-3", notif: "1" },
  ];

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
        <Badge
          value={option.notif}
          className="ml-auto"
          severity="success"
        ></Badge>
      </div>
    );
  };

  return (
    <div>
      <Message
        className=" w-full mb-2 justify-content-start"
        severity="info"
        content={
          <span>
            Insentif <b>SPPD</b>
          </span>
        }
      />
      <ListBox
        value={selectedCountry}
        onChange={(e) => {
          setSelectedCountry(e.value);
          alert("halo " + e.value.name);
        }}
        options={countries}
        optionLabel="name"
        itemTemplate={countryTemplate}
        className="w-full md:w-14rem"
        listStyle={{ maxHeight: "400px" }}
      />
    </div>
  );
}
