import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { Button } from "primereact/button";

// -----
export default function Transfer() {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);
  return (
    <>
      <div className="w-full">
        <Button
          label="Transfer"
          icon="pi pi-plus"
          onClick={() => alert("halo tambahkan data")}
          className="w-full mb-2"
          outlined
        />
        <DataTable
          value={products}
          tableStyle={{ minWidth: "30rem" }}
          size="small"
          resizableColumns
          paginator
          rows={5}
        >
          <Column field="id" header="#"></Column>
          <Column field="name" header="Name"></Column>
          <Column field="quantity" header="Jumlah"></Column>
          <Column field="code" header="Tanggal"></Column>
          <Column field="tujuan" header="Tujuan"></Column>
        </DataTable>
      </div>
    </>
  );
}
