import React, { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { ProductService } from "./service/ProductService";
import { Message } from "primereact/message";

export default function TableActivatedPPPoE() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Freeze",
      icon: "pi pi-fw pi-slack",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Activation",
      icon: "pi pi-fw pi-sun",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Banned",
      icon: "pi pi-fw pi-times",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Reset",
      icon: "pi pi-fw pi-undo",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "PLN Refund",
      icon: "pi pi-fw pi-bolt",
      command: () => deleteProduct(selectedProduct),
    },
    {
      label: "Refund",
      icon: "pi pi-fw pi-history",
      command: () => deleteProduct(selectedProduct),
    },
    {
      label: "Promo",
      icon: "pi pi-fw pi-star",
      command: () => deleteProduct(selectedProduct),
    },
    {
      label: "Iklan",
      icon: "pi pi-fw pi-star-fill",
      command: () => deleteProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => deleteProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };
  // statusBodyTemplate -----
  const statusBodyTemplate = (product) => {
    return <i className={getSeverity(product)}></i>;
  };

  const getSeverity = (product) => {
    switch (product.rating) {
      case 1:
        return "pi pi-bolt text-primary";
      case 2:
        return "pi pi-times text-primary";
      case 3:
        return "pi pi-slack text-primary";
      case 4:
        return "pi pi-star-fill text-primary";
      case 5:
        return "pi pi-star text-primary";
      case 6:
        return "pi pi-history text-primary";
      default:
        return "pi pi-sun text-green-500";
    }
  };

  // -----
  return (
    <>
      <div className="flex-1">
        {/* <Message
          className=" w-full mb-2 justify-content-start"
          severity="info"
          content={
            <span>
              Action <b>Semua Transaksi</b>
            </span>
          }
        /> */}
        <div className="w-full">
          <Toast ref={toast} />
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />
          <DataTable
            value={products}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
            tableStyle={{ minWidth: "30rem" }}
            size="small"
            resizableColumns
            paginator
            rows={12}
          >
            <Column field="code" header="Code"></Column>
            <Column
              field="rating"
              header="status"
              body={statusBodyTemplate}
            ></Column>
            <Column field="name" header="Name"></Column>
            <Column field="category" header="Category"></Column>
            {/* // ----- >>>>> ----- >>>>> ----- >>>>> ----- >>>>> ----- >>>>> ----- >>>>>  */}
          </DataTable>
        </div>
      </div>
    </>
  );
}
