import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService.jsx";
import { Message } from "primereact/message";

export default function PricePacketSA() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  return (
    <>
      <div>
        <div className="flex gap-2">
          <Message
            className="w-full mb-2 justify-content-start px-4"
            severity="success"
            content={
              <div className="ml-2 ">
                Harga dasar <b>Packet</b>
              </div>
            }
          />
        </div>
        <div className="card">
          <DataTable
            value={products}
            tableStyle={{ minWidth: "30rem" }}
            size="small"
            resizableColumns
            rows={10}
            paginator
          >
            <Column field="code" header="Paket"></Column>
            <Column field="name" header="Harga"></Column>
            <Column field="category" header="Tugas"></Column>
            <Column field="quantity" header="Durasi"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
