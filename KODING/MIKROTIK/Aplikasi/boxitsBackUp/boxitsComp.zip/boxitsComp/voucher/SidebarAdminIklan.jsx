import React, { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Badge } from "primereact/badge";
import { Message } from "primereact/message";

export default function SidebarAdminIklan() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const countries = [
    { name: "Umum", icon: "pi pi-star mr-3", notif: "30" },
    { name: "Region", icon: "pi pi-star mr-3", notif: "10" },
    { name: "Branch", icon: "pi pi-star mr-3", notif: "12" },
    { name: "Unit", icon: "pi pi-star mr-3", notif: "1" },
    { name: "Seller", icon: "pi pi-star mr-3", notif: "1" },
    { name: "User", icon: "pi pi-star mr-3", notif: "1" },
  ];

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
        <Badge
          value={option.notif}
          className="ml-auto"
          severity="success"
        ></Badge>
      </div>
    );
  };

  return (
    <div>
      <Message
        className=" w-full mb-2 justify-content-start"
        severity="info"
        content={
          <span>
            Iklan <b>Unit</b>
          </span>
        }
      />
      <ListBox
        value={selectedCountry}
        onChange={(e) => {
          setSelectedCountry(e.value);
          alert("halo " + e.value.name);
        }}
        options={countries}
        optionLabel="name"
        itemTemplate={countryTemplate}
        className="w-full md:w-14rem"
        listStyle={{ maxHeight: "400px" }}
      />
    </div>
  );
}
