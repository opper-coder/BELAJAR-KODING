import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService.jsx";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { Message } from "primereact/message";
import { Checkbox } from "primereact/checkbox";

export default function PricePacketPenyesuaian() {
  const [products, setProducts] = useState([]);
  const [checked, setChecked] = useState(false);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  const statusBodyTemplate2 = (product) => {
    if (product.quantity < 40 && product.rating == 3) {
      // jika harga product > dari standard  dan verify OK
      return <i className="pi pi-caret-up text-blue-500"></i>;
    } else if (product.quantity < 40 && product.rating > 3) {
      // jika harga product < dari standard  dan verify OK
      return <i className="pi pi-caret-down text-green-500"></i>;
    } else {
      // jika verify false
      return <i className="pi pi-info-circle text-red-500"></i>;
    }
  };
  // context ----------------------------------
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Verify",
      icon: "pi pi-fw pi-thumbs-up",
      command: () => viewProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    alert(product.name);
  };

  // end context ----------------------------------
  return (
    <div className="mr-2 flex-1">
      <Message
        className="w-full mb-2 justify-content-start px-4"
        severity="info"
        content={
          <div>
            Harga Penyesuaian root<b> Packet</b>
          </div>
        }
      />
      {/* context */}
      <div className="card mr-2 w-full">
        <Toast ref={toast} />
        <ContextMenu
          model={menuModel}
          ref={cm}
          onHide={() => setSelectedProduct(null)}
        />
        {/* end context */}
        <DataTable
          value={products}
          onContextMenu={(e) => cm.current.show(e.originalEvent)}
          contextMenuSelection={selectedProduct}
          onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
          tableStyle={{ minWidth: "30rem" }}
          size="small"
          resizableColumns
          paginator
          rows={7}
        >
          <Column field="name" header="Unit"></Column>
          <Column
            field="quantity"
            header="Status"
            body={statusBodyTemplate2}
          ></Column>
          <Column field="quantity" header="Selisih"></Column>
          <Column field="code" header="Paket"></Column>
        </DataTable>
      </div>
    </div>
  );
}
