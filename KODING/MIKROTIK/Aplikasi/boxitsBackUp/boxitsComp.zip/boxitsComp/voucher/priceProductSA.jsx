import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService.jsx";
import { Message } from "primereact/message";

export default function PriceProductSA() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  return (
    <>
      <div>
        <div className="flex gap-2">
          <Message
            className="w-full mb-2 justify-content-start px-4"
            severity="success"
            content={
              <div className="ml-2 ">
                Harga Dasar <b>Product</b>
              </div>
            }
          />
        </div>
        <div className="card flex-1">
          <DataTable
            value={products}
            tableStyle={{ minWidth: "30rem" }}
            size="small"
            resizableColumns
            rows={10}
            paginator
          >
            <Column field="code" header="Product"></Column>

            <Column field="code" header="Harga"></Column>
            <Column field="name" header="Quota"></Column>
            <Column field="category" header="Bandwidth"></Column>
            <Column field="quantity" header="Durasi"></Column>
            <Column field="quantity" header="MAC"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
