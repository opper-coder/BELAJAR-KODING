import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";

export default function All() {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    ProductService.getProductsMini().then((data) => setProducts(data));
  }, []);

  // contex -----
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);

  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Freeze",
      icon: "pi pi-fw pi-times-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Activation",
      icon: "pi pi-fw pi-sun",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Banned",
      icon: "pi pi-fw pi-times",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Reset",
      icon: "pi pi-fw pi-undo",
      command: () => viewProduct(selectedProduct),
    },

    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => deleteProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };

  // templat table -----
  const statusBodyTemplate = (product) => {
    return (
      // <Tag
      //   value={product.inventoryStatus}
      //   severity={getSeverity(product)}
      // ></Tag>
      <i className={getSeverity(product)}></i>
    );
  };

  const getSeverity = (product) => {
    switch (product.inventoryStatus) {
      case "INSTOCK":
        return "pi pi-check text-green-600";

      case "LOWSTOCK":
        return "pi pi-times-circle text-red-600";

      case "OUTOFSTOCK":
        return "pi pi-sun text-blue-600";

      default:
        return null;
    }
  };
  // &templat table -----
  return (
    <>
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={products}
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        tableStyle={{ minWidth: "30rem" }}
        size="small"
        resizableColumns
        paginator
        rows={7}
      >
        <Column field="id" header="#"></Column>
        <Column field="name" header="Name"></Column>
        <Column
          field="category"
          header="Status"
          body={statusBodyTemplate}
        ></Column>
        <Column field="quantity" header="Jumlah"></Column>
        <Column field="code" header="Tanggal"></Column>
        <Column field="description" header="Tujuan"></Column>
        <Column field="category" header="Type"></Column>
      </DataTable>
    </>
  );
}
