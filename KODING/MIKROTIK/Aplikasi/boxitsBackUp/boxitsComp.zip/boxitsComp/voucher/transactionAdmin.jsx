import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { Button } from "primereact/button";

export default function TransactionAdmin() {
  const [date, setDate] = useState(null);
  const [products, setProducts] = useState([]);
  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  const statusBodyTemplate2 = (product) => {
    if (product.quantity < 80 && product.quantity > 40) {
      // jika verifikasi TRUE
      return <i className="pi pi-check text-blue-500"></i>;
    } else if (product.quantity < 40 && product.quantity > 10) {
      // jika verify else (FALSE)
      return <i className="pi pi-stopwatch text-yellow-500"></i>;
    } else {
      // jika verify else (FALSE)
      return <i className="pi pi-info-circle text-red-500"></i>;
    }
  };

  return (
    <>
      <div>
        <div>
          <div className="">
            {/* table ------ */}
            <div className="flex gap-2 mb-2">
              <Button
                label="Request Capital"
                icon="pi pi-reply"
                onClick={() => alert("halo tambahkan data")}
                outlined
                className="flex-1"
              />
            </div>
            <DataTable
              value={products}
              tableStyle={{ minWidth: "12rem" }}
              size="small"
              resizableColumns
              paginator
              rows={7}
            >
              <Column field="id" header="#" sortable></Column>
              <Column field="name" header="Capital"></Column>
              <Column
                field="price"
                header="Status"
                body={statusBodyTemplate2}
              ></Column>
              <Column field="code" header="Tanggal" sortable></Column>
              <Column field="price" header="Nilai"></Column>
            </DataTable>
          </div>
        </div>
      </div>
    </>
  );
}
