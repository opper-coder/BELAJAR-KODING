import { useState } from "react";
import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import { Calendar } from "primereact/calendar";
import { Button } from "primereact/button";
import TanggalLive from "../tanggalLive";

export default function VoucherSAdminJumbotron() {
  const [date, setDate] = useState(null);
  const items = [
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center gap-2">
      <TanggalLive />
      <Calendar
        value={date}
        onChange={(e) => setDate(e.value)}
        view="month"
        dateFormat="mm/yy"
        showIcon
      />
      <Button label="Go" text />
    </div>
  );

  return (
    <>
      <Card
        title="Voucher Super Admin Verification"
        subTitle="Product, Packet, Action, Transaction, Adaptation "
        className="mb-4 surface-300 "
      >
        <ul className="text-blue-700 m-0">
          <li>For Super Admin</li>
          <li>Admin Verify adaptation</li>
          <li>Monitoring admin </li>
        </ul>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
