import { useState } from "react";
import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";
import { Calendar } from "primereact/calendar";
import { Button } from "primereact/button";

export default function VoucherAdminJumbotron() {
  const [date, setDate] = useState(null);
  const items = [
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
      <Calendar
        value={date}
        onChange={(e) => setDate(e.value)}
        view="month"
        dateFormat="mm/yy"
        showIcon
      />
      <Button label="Go" text />
    </div>
  );

  return (
    <>
      <Card
        title="Voucher Admin"
        subTitle="Product, Packet, Action, Transaction, Adaptation "
        className="mb-4 surface-300 "
      >
        <div className="flex">
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>For Admin</li>
              <li>Adaptation Main Price Product</li>
              <li>Adaptation Main Price Packet</li>
            </ul>
          </div>
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>Transfer Product</li>
              <li>Response Packet</li>
              <li>Action For Sold Product and Packet</li>
            </ul>
          </div>
        </div>
      </Card>
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
