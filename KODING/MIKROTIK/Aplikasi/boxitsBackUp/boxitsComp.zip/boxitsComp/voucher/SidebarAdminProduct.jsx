import { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Message } from "primereact/message";
import { Badge } from "primereact/badge";

export default function SidebarAdminProduct() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const countries = [
    { name: "Voucher", icon: "pi pi-qrcode mr-3", notif: "12" },
    { name: "Printing", icon: "pi pi-print mr-3", notif: "2" },
    { name: "Data", icon: "pi pi-calendar mr-3", notif: "22" },
    { name: "PPPoE", icon: "pi pi-home mr-3", notif: "0" },
    { name: "Saldo", icon: "pi pi-wallet mr-3", notif: "2" },
    { name: "Reseller", icon: "pi pi-share-alt mr-3", notif: "200" },
    { name: "Promo", icon: "pi pi-ticket mr-3", notif: "14" },
    { name: "Insentif", icon: "pi pi-gift mr-3", notif: "2" },
    { name: "PLN Refund", icon: "pi pi-bolt mr-3", notif: "0" },
    { name: "Refund", icon: "pi pi-replay mr-3", notif: "2" },
  ];

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
        <Badge
          value={option.notif}
          className="ml-auto"
          severity="success"
        ></Badge>
      </div>
    );
  };

  return (
    <div>
      <Message
        className="w-full mb-2"
        severity="info"
        content={
          <span>
            Prod:
            <b> Printing</b>
          </span>
        }
      />
      <ListBox
        value={selectedCountry}
        onChange={(e) => {
          setSelectedCountry(e.value);
          alert("halo " + e.value.name);
        }}
        options={countries}
        optionLabel="name"
        itemTemplate={countryTemplate}
        className="w-full md:w-14rem"
        listStyle={{ maxHeight: "450px" }}
      />
    </div>
  );
}
