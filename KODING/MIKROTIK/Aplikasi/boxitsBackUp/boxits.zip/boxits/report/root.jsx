import TabReportRoot from "@/boxitsComp/report/TabReportRoot";
import Contain from "@/boxitsComp/report/contain";
import ReportJumbotron from "@/boxitsComp/report/reportJumbotron";

export default function Root() {
  return (
    <>
      <ReportJumbotron />
      <TabReportRoot />
      <div className="card bg-yellow-300 text-blue-800 mt-4 justify-content-start px-4">
        <h5>Breakdown</h5>
        <b>Laporan Administrasi</b>
        <ul>
          <li>Root</li>
          <ul>
            <li>Laporan generate saldo</li>
            <li>Laporan Distribusi saldo</li>
          </ul>
          <li>Admin</li>
          <ul>
            <li>Laporan Aktifitas request saldo</li>
            <li>laporan jual product</li>
            <li>laporan beli jasa paket</li>
            <li>laporan Inventory</li>
          </ul>
          <li>Reseller</li>
          <ul>
            <li>beli saldo</li>
            <li>bonus daan insentif</li>
            <li>transfer saldo</li>
            <li>jual saldo</li>
            <li>jual voucher</li>
            <li>cetak voucher</li>
          </ul>
          <li>EndUser</li>
          <ul>
            <li>beli saldo</li>
            <li>Transfer saldo</li>
            <li>aktifkan voucher</li>
            <li>saldo kadaluarsa</li>
          </ul>
        </ul>

        <b>Product</b>
        <ul>
          <li>Capital</li>
          <li>Product jenis product terjual</li>
          <li>Unit server</li>
          <li>perhitungan per akses point</li>
          <li>Total penjualan</li>
          <li>Sisa</li>
        </ul>
        <b>paket</b>
        <ul>
          <li>Product jenis product terjual</li>
          <li>Unit server</li>
          <li>Total penjualan paket</li>
          <li>sisa</li>
        </ul>
        <b>cost</b>
        <ul>
          <li>Biaya perusahaan</li>
          <li>Biaya wajib</li>
          <li>maintenance</li>
          <li>biaya karyawan</li>
          <li>sppd</li>
          <li>total biaya</li>
          <li>sisa</li>
        </ul>
      </div>

      <div className="card bg-yellow-300 text-blue-800">
        <b>Ringkasan</b>
        <ul>
          <li>laporan emisi</li>
          <li>laporan penjualan</li>
          <li>laporan operasional</li>
          <li>laporan iuran wajib perusahaan</li>
          <li>laporan distribusi gaji</li>
          <li>monitoring dashboard</li>
        </ul>
        <b>Fungsi utama</b>
        <ol>
          <li>tabel product, penjaualan, pembelian</li>
          <li>tabel distribusi, biaya, gaji pokok, </li>
          <li>
            tabel saldo, pendapatan umum, perorang, root, superadmin, admin,
            seller, investor, shareholder, parners, public{" "}
          </li>
          <li>rincian per kategori</li>
          <li>rekapitulasi</li>
          <li>petugas dan assign</li>
          <li>monitoring, evaluating, accounting</li>
          <li></li>
        </ol>
        <b>User</b>
        <ol>
          <li>Root</li>
          <li>Super admin</li>
          <li>Admin</li>
          <li>Seller(mobile)</li>
          <li>Investor</li>
          <li>Shareholder</li>
          <li>Partners</li>
          <li>Public</li>
        </ol>
      </div>
      <Contain />
    </>
  );
}
