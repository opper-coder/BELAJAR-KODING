export default function Admin() {
  return <>Admin</>;
}
