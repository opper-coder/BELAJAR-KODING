export default function Reseller() {
  return (
    <>
      <h3>Reseller</h3>
      <div className="card bg-yellow-300 text-blue-800">
        <b>fungsi utama</b>
        <ol>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
        </ol>
      </div>{" "}
    </>
  );
}
