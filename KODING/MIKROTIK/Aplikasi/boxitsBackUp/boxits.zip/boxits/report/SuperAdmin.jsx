export default function SuperAdmin() {
  return <>Super Admin</>;
}
