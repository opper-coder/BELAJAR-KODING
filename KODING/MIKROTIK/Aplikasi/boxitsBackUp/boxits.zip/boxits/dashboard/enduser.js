
export default function Enduser() {
  return (
    <div>
      dashboard enduser
    </div>
  )
}
