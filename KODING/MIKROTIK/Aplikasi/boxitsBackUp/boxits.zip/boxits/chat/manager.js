export default function Manager() {
  return (
    <>
      chat manager
      <div className="card mt-4 bg-yellow-300 text-red-900">
        <ul>
          <li>Tab</li>
          <ul>
            <li>tombol All contact tampil dalam modal</li>
            <li>list inbox</li>
          </ul>
          <li>conversation</li>
          <li>properties</li>
        </ul>
      </div>
    </>
  );
}
