
export default function Enduser() {
  return (
    <div>
      halo chat enduser
    </div>
  )
}
