
export default function Investor() {
  return (
    <div>
      chat Investor
    </div>
  )
}
