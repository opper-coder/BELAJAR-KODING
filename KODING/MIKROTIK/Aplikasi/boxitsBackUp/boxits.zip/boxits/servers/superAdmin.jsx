export default function SuperAdmin() {
  return <div>SuperAdmin</div>;
}
