export default function Admin() {
  return <div>Admin</div>;
}
