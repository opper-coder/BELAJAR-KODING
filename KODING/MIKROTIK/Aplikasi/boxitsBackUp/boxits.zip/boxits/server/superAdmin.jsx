import SuperAdminJumbotron from "@/boxitsComp/server/sAdminjumbotron";
import SuperAdminRoot from "../../../boxitsComp/server/superAdminRoot";

export default function SuperAdmin() {
  return (
    <>
      <SuperAdminJumbotron />
      <SuperAdminRoot />
    </>
  );
}
