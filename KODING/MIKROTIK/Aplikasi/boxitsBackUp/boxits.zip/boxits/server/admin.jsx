import AdminRoot from "@/boxitsComp/server/adminRoot";
import AdminJumbotron from "@/boxitsComp/server/Adminjumbotron";

export default function SuperAdmin() {
  return (
    <>
      <AdminJumbotron />
      <AdminRoot />
    </>
  );
}
