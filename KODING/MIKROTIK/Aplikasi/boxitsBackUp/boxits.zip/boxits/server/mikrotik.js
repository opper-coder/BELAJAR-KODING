// next link
import Link from "next/link";

// menubar
import { Menubar } from 'primereact/menubar';

// table
import React, { useState, useEffect } from 'react';
import { TreeTable } from 'primereact/treetable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { SelectButton } from 'primereact/selectbutton';
import { NodeService } from './service/NodeService';

// table action
//import { useRouter } from 'next/router';
import { Button } from 'primereact/button';
import { Menu } from 'primereact/menu';

// modal
import { Dialog } from 'primereact/dialog';
import { Divider } from 'primereact/divider';
import { Calendar } from 'primereact/calendar';
import { useRef } from 'react';
import { Toast } from 'primereact/toast';
import { FileUpload } from 'primereact/fileupload';
import { Dropdown } from 'primereact/dropdown';

// ----------------------------------------------------------
export default function Mikrotik() {
  // menubar ------------------------
  const items = [
    {
        label: 'Add Server',
        icon: 'pi pi-fw pi-plus',
        command: () => setVisible(true),
    },
    {
        label: 'Access Point',
        icon: 'pi pi-fw pi-wifi',
        url: './router',
    },
    {
        label: 'Dashboard',
        icon: 'pi pi-fw pi-chart-bar',
        url:'../../',
    },
];

// table ------------------------
const [nodes, setNodes] = useState([]);
const [globalFilter, setGlobalFilter] = useState('');
const [filterMode, setFilterMode] = useState('lenient');
const [filterOptions] = useState([
    { label: 'Lenient', value: 'lenient' },
    { label: 'Strict', value: 'strict' }
]);

useEffect(() => {
    NodeService.getTreeTableNodes().then((data) => setNodes(data));
}, []);

const getHeader = () => {
    return (
        <div className="flex justify-content-end">
            <div className="p-input-icon-left">
                <i className="pi pi-search"></i>
                <InputText type="search" onInput={(e) => setGlobalFilter(e.target.value)} placeholder="Global Search" />
            </div>
        </div>
    );
};

let header = getHeader();

// modal ------------------------
const [visible, setVisible] = useState(false);
const [visible2, setVisible2] = useState(false);
const [visible3, setVisible3] = useState(false);
const [visible4, setVisible4] = useState(false);
const [visible5, setVisible5] = useState(false);
const [visible6, setVisible6] = useState(false);
const [visible7, setVisible7] = useState(false);
const [visible8, setVisible8] = useState(false);
const [visible9, setVisible9] = useState(false);
const [date, setDate] = useState(null);

// dropdown select ------------------------
const [selectedCityRoot, setSelectedCityRoot] = useState(null);    
const [selectedCityRegion, setSelectedCityRegion] = useState(null);    
const [selectedCityBranch, setSelectedCityBranch] = useState(null);    
const [selectedCityUnit, setSelectedCityUnit] = useState(null);    
const [selectedModeRouter, setSelectedModeRouter] = useState(null);

// toast upload ------------------------
const toast = useRef(null);
const onUpload = () => {
    toast.current.show({ severity: 'info', summary: 'Success', detail: 'File Uploaded' });
};
    
    const citiesRoot = [
        { name: 'New York', code: 'NY' },
        { name: 'Rome', code: 'RM' },
        { name: 'London', code: 'LDN' },
        { name: 'Istanbul', code: 'IST' },
        { name: 'Paris', code: 'PRS' }
    ];
    const citiesRegion = [
        { name: 'New York', code: 'NY' },
        { name: 'Rome', code: 'RM' },
        { name: 'London', code: 'LDN' },
        { name: 'Istanbul', code: 'IST' },
        { name: 'Paris', code: 'PRS' }
    ];
    const citiesBranch = [
        { name: 'New York', code: 'NY' },
        { name: 'Rome', code: 'RM' },
        { name: 'London', code: 'LDN' },
        { name: 'Istanbul', code: 'IST' },
        { name: 'Paris', code: 'PRS' }
    ];
    const citiesUnit = [
        { name: 'New York', code: 'NY' },
        { name: 'Rome', code: 'RM' },
        { name: 'London', code: 'LDN' },
        { name: 'Istanbul', code: 'IST' },
        { name: 'Paris', code: 'PRS' }
    ];
    const modeRouter = [
        { name: 'AP', code: 'NY' },
        { name: 'Repeater', code: 'RM' },
        { name: 'Bridge', code: 'LDN' },
        { name: 'WISP', code: 'IST' },
        { name: 'PPPoE', code: 'PRS' }
    ];

// action button
const menu = useRef(null);
const itemsAction = [
    {
        label: 'Action',
        items: [
            {
                label: 'Edit',
                icon: 'pi pi-refresh',
                command:() => setVisible8(true),
            },
            {
                label: 'Delete',
                icon: 'pi pi-times',
                command:() => setVisible3(true),
            },
            {
                label: 'Add Router AP',
                icon: 'pi pi-wifi',
                command:() => setVisible2(true),
            },
            {
                label: 'Properties',
                icon: 'pi pi-info-circle',
                command:() => setVisible4(true),
            }
        ]
    }
];

const actionTemplate = () => {
    return (
      <div>
          <Menu model={itemsAction} popup ref={menu} />
          <Button label="" icon="pi pi-ellipsis-v" onClick={(e) => menu.current.toggle(e)} />
      </div>
    );
  };

// func delete confirm 
const accept = () => {
    toast.current.show({ severity: 'info', summary: 'Confirmed', detail: 'You have accepted', life: 3000 });
}

const reject = () => {
    toast.current.show({ severity: 'warn', summary: 'Rejected', detail: 'You have rejected', life: 3000 });
}

const confirmDelete = () => {
    confirmDialog({
        message: 'Do you want to delete this record?',
        header: 'Delete Confirmation',
        icon: 'pi pi-info-circle',
        acceptClassName: 'p-button-danger',
        accept,
        reject
    });
};

// ------- >>>>>> ------- >>>>>> ------- >>>>>> ------- >>>>>> 
// ------- >>>>>> ------- >>>>>> ------- >>>>>> ------- >>>>>> 

return ( 
<>
    {/* card atas ----------------------------------- */}
      <div className="card bg-blue-100 shadow-1">
        <p className="text-1xl font-bold text-blue-600">Server Mikrotik</p>
        <p className="text-blue-500">Lorem ipsum dolor sit amet consectetur adipisicing elit. Expedita, eos doloremque libero, saepe atque corrupti error facere distinctio necessitatibus ut voluptatum! Aspernatur exercitationem odit ratione delectus. Fugit ullam laboriosam commodi.
        </p>
      </div>

    {/* nav bar ----------------------------------- */}
      <Menubar model={items} /> 

    {/* table ----------------------------------- */}
    <div className="card mt-5">
        <div className="flex justify-content-center mb-4">
            <SelectButton value={filterMode} onChange={(e) => setFilterMode(e.value)} options={filterOptions} />
        </div>
        <TreeTable value={nodes} paginator rows={5} rowsPerPageOptions={[5, 10, 25]} globalFilter={globalFilter} header={header} filterMode={filterMode} tableStyle={{ minWidth: '50rem' }}>
            <Column field="name" header="Name" expander filter filterPlaceholder="Filter by name"></Column>
            <Column field="size" header="Region" filter filterPlaceholder="Filter by type"></Column>
            <Column field="type" header="Branch" filter filterPlaceholder="Filter by type"></Column>
            <Column field="type" header="Unit" filter filterPlaceholder="Filter by type"></Column>
            <Column field="type" header="Action" body={actionTemplate} headerClassName="w-10rem"></Column>
        </TreeTable>
    </div>

{/* =========================================================================================================================================================== */}



        
{/* =========================================================================================================================================================== */}

    {/* action ------------------------------------- */}
    {/* <div className="card flex justify-content-center">
        <Menu model={itemsAction} popup ref={menu} onClick={itemsAction.command}/>
        <Button label="Action" icon="pi pi-ellipsis-v" onClick={(e) => menu.current.toggle(e)} />
    </div> */}

    {/* modal add server ------------------------------------- */}
    {/* <div className="card flex justify-content-center"> */}
    <div >
        {/* <Button label="Add Server" icon="pi pi-external-link" onClick={() => setVisible(true)} /> */}
        {/* <Dialog header="Mikrotik" visible={visible} style={{ width: '50vw' }} onHide={() => setVisible(false)} > */}
        <Dialog header="Add Server" visible={visible} onHide={() => setVisible(false)} className='w-full mx-3 md:w-8 lg:w-6'>
        <div className='card shadow-2'>
            <b className='text-lg'>Parent</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Root</label>
                    <Dropdown value={selectedCityRoot} onChange={(e) => setSelectedCityRoot(e.value)} options={citiesRoot} optionLabel="name" 
                    placeholder="Select a Root" className="w-full md:w-14rem ml-4 p-inputtext-sm" />
                    <label htmlFor="username" className='ml-4'>Region</label>
                    <Dropdown value={selectedCityRegion} onChange={(e) => setSelectedCityRegion(e.value)} options={citiesRegion} optionLabel="name" 
                    placeholder="Select a City Region" className="w-full md:w-14rem ml-4 p-inputtext-sm" />
                    <label htmlFor="username" className='ml-4'>Branch</label>
                    <Dropdown value={selectedCityBranch} onChange={(e) => setSelectedCityBranch(e.value)} options={citiesBranch} optionLabel="name" 
                    placeholder="Select a City Branch" className="w-full md:w-14rem ml-4 p-inputtext-sm" />
                    <label htmlFor="username" className='ml-4'>Unit</label>
                    <Dropdown value={selectedCityUnit} onChange={(e) => setSelectedCityUnit(e.value)} options={citiesUnit} optionLabel="name" 
                    placeholder="Select a City Unit" className="w-full md:w-14rem ml-4 p-inputtext-sm" />
                </div>
       </div>
        <div className='card shadow-2'>
            <b className='text-lg'>Server</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Nama</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama server'/>
                    <label htmlFor="username" className='ml-4'>Password</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Password Mikrotik'/>
                    <label htmlFor="username" className='ml-4'>Ip forward</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Ip Public'/>
                    <label htmlFor="username" className='ml-4'>Domain forward</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama Public Domain'/>
                    <label htmlFor="username" className='ml-4'>Merk</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Mikrotik'/>
                    <label htmlFor="username" className='ml-4'>Type</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='RB 450gx4'/>
                    <label htmlFor="username" className='ml-4'>Ip ISP</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='ip indiehome: 192.168.222.21'/>
                    <label htmlFor="username" className='ml-4'>Ip local</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='ip-alokasi: 192.168.50.1/24'/>
                </div>
       </div>
        <div className='card shadow-2'>
            <b className='text-lg'>ISP Identity</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Nama</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama pemilik ISP'/>
                    <label htmlFor="username" className='ml-4'>Lokasi</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Koordinat'/>
                    <label htmlFor="username" className='ml-4'>Hp/WA</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='kontak'/>
                    <label htmlFor="username" className='ml-4'>Tanggal Registrasi</label>
                    <Calendar value={date} onChange={(e) => setDate(e.value)} dateFormat="dd/mm/yy" className='ml-4'/>
                    <label htmlFor="username" className='ml-4'>Rumah</label>
            <Toast ref={toast}></Toast>
            <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} onUpload={onUpload} className='ml-4'/>
                    <label htmlFor="username" className='ml-4'>Pas Foto</label>
            <Toast ref={toast}></Toast>
            <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} onUpload={onUpload} className='ml-4'/>
                </div>
       </div>

        <div className="card flex justify-content-end">
                <Button label="Save" icon="pi pi-check" severity="success" />
        </div>

        </Dialog>
    </div>

    {/* modal EDIT server ------------------------------------- */}
    {/* <div className="card flex justify-content-center"> */}
    <div >
        {/* <Button label="Add Server" icon="pi pi-external-link" onClick={() => setVisible8(true)} /> */}
        {/* <Dialog header="Mikrotik" visible={visible} style={{ width: '50vw' }} onHide={() => setVisible(false)} > */}
        <Dialog header="Edit Server" visible={visible8} onHide={() => setVisible8(false)} className='w-full mx-3 md:w-8 lg:w-6'>
        <div className='card shadow-2'>
            <b className='text-lg'>Parent</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Root</label>
                    <Dropdown value={selectedCityRoot} onChange={(e) => setSelectedCityRoot(e.value)} options={citiesRoot} optionLabel="name" 
                    placeholder="Select a Root" className="w-full md:w-14rem ml-4 p-inputtext-sm" />
                    <label htmlFor="username" className='ml-4'>Region</label>
                    <Dropdown value={selectedCityRegion} onChange={(e) => setSelectedCityRegion(e.value)} options={citiesRegion} optionLabel="name" 
                    placeholder="Select a City Region" className="w-full md:w-14rem ml-4 p-inputtext-sm" />
                    <label htmlFor="username" className='ml-4'>Branch</label>
                    <Dropdown value={selectedCityBranch} onChange={(e) => setSelectedCityBranch(e.value)} options={citiesBranch} optionLabel="name" 
                    placeholder="Select a City Branch" className="w-full md:w-14rem ml-4 p-inputtext-sm" />
                    <label htmlFor="username" className='ml-4'>Unit</label>
                    <Dropdown value={selectedCityUnit} onChange={(e) => setSelectedCityUnit(e.value)} options={citiesUnit} optionLabel="name" 
                    placeholder="Select a City Unit" className="w-full md:w-14rem ml-4 p-inputtext-sm" />
                </div>
       </div>
        <div className='card shadow-2'>
            <b className='text-lg'>Server</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Nama</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama server'/>
                    <label htmlFor="username" className='ml-4'>Password</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Password Mikrotik'/>
                    <label htmlFor="username" className='ml-4'>Ip forward</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Ip Public'/>
                    <label htmlFor="username" className='ml-4'>Domain forward</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama Public Domain'/>
                    <label htmlFor="username" className='ml-4'>Merk</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Mikrotik'/>
                    <label htmlFor="username" className='ml-4'>Type</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='RB 450gx4'/>
                    <label htmlFor="username" className='ml-4'>Ip ISP</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='ip indiehome: 192.168.222.21'/>
                    <label htmlFor="username" className='ml-4'>Ip local</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='ip-alokasi: 192.168.50.1/24'/>
                </div>
       </div>
        <div className='card shadow-2'>
            <b className='text-lg'>ISP Identity</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Nama</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama pemilik ISP'/>
                    <label htmlFor="username" className='ml-4'>Lokasi</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Koordinat'/>
                    <label htmlFor="username" className='ml-4'>Hp/WA</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='kontak'/>
                    <label htmlFor="username" className='ml-4'>Tanggal Registrasi</label>
                    <Calendar value={date} onChange={(e) => setDate(e.value)} dateFormat="dd/mm/yy" className='ml-4'/>
                    <label htmlFor="username" className='ml-4'>Rumah</label>
            <Toast ref={toast}></Toast>
            <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} onUpload={onUpload} className='ml-4'/>
                    <label htmlFor="username" className='ml-4'>Pas Foto</label>
            <Toast ref={toast}></Toast>
            <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} onUpload={onUpload} className='ml-4'/>
                </div>
       </div>

        <div className="card flex justify-content-end">
                <Button label="Save" icon="pi pi-check" severity="success" />
        </div>

        </Dialog>
    </div>

    {/* modal2 add wifi ------------------------------------- */}
    {/* <div className="card flex justify-content-center"> */}
    <div >
        {/* <Button label="Add Router" icon="pi pi-external-link" onClick={() => setVisible2(true)} /> */}
        {/* <Dialog header="Router" visible={visible2} style={{ width: '50vw' }} onHide={() => setVisible2(false)} > */}
        <Dialog header="Add Router AP" visible={visible2} onHide={() => setVisible2(false)} className='w-full mx-3 md:w-8 lg:w-6'>

        <div className='card shadow-2'>
            <b className='text-lg'>Data Pemilik</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Nama</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama Pemilik'/>
                    <label htmlFor="username" className='ml-4'>Lokasi</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Kordinat locasi'/>
                    <label htmlFor="username" className='ml-4'>Hp/WA</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nomor kontak'/>    
                    <label htmlFor="username" className='ml-4'>Tanggal registrasi</label>
                        <Calendar value={date} onChange={(e) => setDate(e.value)} dateFormat="dd/mm/yy" className='ml-4'/>
                    <label htmlFor="username" className='ml-4'>Foto Rumah</label>
                        <Toast ref={toast}></Toast>
                        <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} onUpload={onUpload} className='ml-4'/>
                    <label htmlFor="username" className='ml-4'>Pas Foto</label>
                        <Toast ref={toast}></Toast>
                        <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} onUpload={onUpload} className='ml-4'/>
                </div>
       </div>
        <div className='card shadow-2'>
            <b className='text-lg'>Data Perangkat</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Merk</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama merk router'/>
                    <label htmlFor="username" className='ml-4'>Type</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Type merk'/>
                    <label htmlFor="username" className='ml-4'>Ip remote</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Alokasi Ip Statik'/>    
                    <label htmlFor="username" className='ml-4'>User Admin</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='User Admin Konfigurasi'/>    
                    <label htmlFor="username" className='ml-4'>Password</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Pass'/>
                    <label htmlFor="username" className='ml-4'>Mode</label>
                    <div className="ml-4">
                        <Dropdown value={selectedModeRouter} onChange={(e) => setSelectedModeRouter(e.value)} options={modeRouter} optionLabel="name" 
                        placeholder="Select a City" className="w-full md:w-14rem" />
                    </div>
                </div>
       </div>
       <div className="card flex justify-content-end">
                <Button label="Save" icon="pi pi-check" severity="success" />
        </div>
        </Dialog>
    </div>

    {/* modal2 EDIT wifi ------------------------------------- */}
    {/* <div className="card flex justify-content-center"> */}
    <div >
        {/* <Button label="Edit Router" icon="pi pi-external-link" onClick={() => setVisible9(true)} /> */}
        <Dialog header="Edit Router AP" visible={visible9} onHide={() => setVisible9(false)} className='w-full mx-3 md:w-8 lg:w-6'>

        <div className='card shadow-2'>
            <b className='text-lg'>Data Pemilik</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Nama</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama Pemilik'/>
                    <label htmlFor="username" className='ml-4'>Lokasi</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Kordinat locasi'/>
                    <label htmlFor="username" className='ml-4'>Hp/WA</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nomor kontak'/>    
                    <label htmlFor="username" className='ml-4'>Tanggal registrasi</label>
                        <Calendar value={date} onChange={(e) => setDate(e.value)} dateFormat="dd/mm/yy" className='ml-4'/>
                    <label htmlFor="username" className='ml-4'>Foto Rumah</label>
                        <Toast ref={toast}></Toast>
                        <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} onUpload={onUpload} className='ml-4'/>
                    <label htmlFor="username" className='ml-4'>Pas Foto</label>
                        <Toast ref={toast}></Toast>
                        <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} onUpload={onUpload} className='ml-4'/>
                </div>
       </div>
        <div className='card shadow-2'>
            <b className='text-lg'>Data Perangkat</b>
            <Divider/>
                <div className="flex flex-column gap-2">
                    <label htmlFor="username" className='ml-4'>Merk</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Nama merk router'/>
                    <label htmlFor="username" className='ml-4'>Type</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Type merk'/>
                    <label htmlFor="username" className='ml-4'>Ip remote</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Alokasi Ip Statik'/>    
                    <label htmlFor="username" className='ml-4'>User Admin</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='User Admin Konfigurasi'/>    
                    <label htmlFor="username" className='ml-4'>Password</label>
                    <InputText id="username" aria-describedby="username-help" className="p-inputtext-sm ml-4" placeholder='Pass'/>
                    <label htmlFor="username" className='ml-4'>Mode</label>
                    <div className="ml-4">
                        <Dropdown value={selectedModeRouter} onChange={(e) => setSelectedModeRouter(e.value)} options={modeRouter} optionLabel="name" 
                        placeholder="Select a City" className="w-full md:w-14rem" />
                    </div>
                </div>
       </div>
       <div className="card flex justify-content-end">
                <Button label="Save" icon="pi pi-check" severity="success" />
        </div>
        </Dialog>
    </div>

    {/* modal3 tambahan ------------------------------------- */}
    {/* <div className="card flex justify-content-center"> */}
    <div >
        {/* <Button label="Modal apapun silahkan" icon="pi pi-external-link" onClick={() => setVisible3(true)} /> */}
        <Dialog header="Delete Confirmation" visible={visible3} onHide={() => setVisible3(false)}  >
            <div className="flex align-items-center" >
                <i className="pi pi-info-circle m-3" style={{ fontSize: '2rem' }} />
                <p className=""> Do you want to delete this record? </p>
            </div>
            <div className="flex justify-content-end mt-3">
                <Button label="No" link onClick={() => setVisible3(false)} />
                <Button label="Yes" severity="danger" className="mx-1"/>
            </div>
        </Dialog>
    </div>


    {/* modal4 properties ------------------------------------- */}
    {/* <div className="card flex justify-content-center"> */}
    <div >
        {/* <Button label="Properties" icon="pi pi-external-link" onClick={() => setVisible4(true)} /> */}
        <Dialog header="Properties" visible={visible4} onHide={() => setVisible4(false)} className='w-full mx-3 md:w-6 lg:w-4'>
        <div class="grid">
            <div class="col-4">Root</div><div class="col-8">: Banggai Laut</div>
            <div class="col-4">Region</div><div class="col-8">: Banggai</div>
            <div class="col-4">Branch</div><div class="col-8">: Banggai</div>
            <div class="col-4">Unit</div><div class="col-8">: Tanobonunungan</div>
            <Divider/>
            <div class="col-4">Nama Server</div><div class="col-8">: Tambora.net</div>
            <div class="col-4">Password</div><div class="col-8">: 123</div>
            <div class="col-4">Ip Forward</div><div class="col-8">: 171.88.217.11</div>
            <div class="col-4">Domain</div><div class="col-8">: abc.Tambora.net</div>
            <div class="col-4">Merk Unit</div><div class="col-8">: Mikrotik</div>
            <div class="col-4">Type Unit</div><div class="col-8">: RB 450gx3</div>
            <div class="col-4">Ip ISP</div><div class="col-8">: dinamic</div>
            <div class="col-4">Ip Local</div><div class="col-8">: 192.168.50.1/24</div>
            <Divider/>
            <div class="col-4">Nama Pemilik</div><div class="col-8">: Rafatul</div>
            <div class="col-4">Lokasi</div><div class="col-8">: long+120190090</div>
            <div class="col-4">Hp / WA</div><div class="col-8">: 081 494 222 116</div>
            <div class="col-4">Tgl Registrasi</div><div class="col-8">: 2 juli 2023</div>
        </div>
            <div class="flex justify-content-end">
                <Button label="Pas Foto" onClick={() => setVisible6(true)} />
                <Dialog header="Pas foto Pemilik" visible={visible6} onHide={() => setVisible6(false)} className='w-full mx-3 md:w-8 lg:w-6' >
                <b>Modal foto</b>
                </Dialog>
                <Button label="Foto Rumah" onClick={() => setVisible7(true)} className='mx-2'/>
                <Dialog header="Foto Rumah" visible={visible7} onHide={() => setVisible7(false)} className='w-full mx-3 md:w-8 lg:w-6 ' >
                <b>Modal foto Rumah</b>
                </Dialog>
                <Button label="Peta" icon="pi pi-map-marker" onClick={() => setVisible3(true)} />
                <Dialog header="Peta Lokasi" visible={visible3} onHide={() => setVisible3(false)} className='w-full mx-3 lg:w-10 h-full' >
                <b>Peta</b>
                </Dialog>
            </div>

        </Dialog>
    </div>

    {/* modal5 Ap properties2 ------------------------------------- */}
    {/* <div className="card flex justify-content-center"> */}
    <div >
        {/* <Button label="Ap Properties" icon="pi pi-external-link" onClick={() => setVisible5(true)} /> */}
        <Dialog header="Ap Properties" visible={visible5} onHide={() => setVisible5(false)} className='w-full mx-3 md:w-6 lg:w-4'>
        <div class="grid">
            <Divider/>
            <div class="col-4">Nama Pemilik</div><div class="col-8">: Rafatul</div>
            <div class="col-4">Lokasi</div><div class="col-8">: long+120190090</div>
            <div class="col-4">Hp / WA</div><div class="col-8">: 081 494 222 116</div>
            <div class="col-4">Tgl Registrasi</div><div class="col-8">: 2 juli 2023</div>
            <Divider/>
            <div class="col-4">Nama AP</div><div class="col-8">: Tambora.net</div>
            <div class="col-4">Admin</div><div class="col-8">: admin</div>
            <div class="col-4">Password</div><div class="col-8">: 123</div>
            <div class="col-4">Ip Remote</div><div class="col-8">: 171.88.217.11</div>
            <div class="col-4">Merk Unit</div><div class="col-8">: TotoLink</div>
            <div class="col-4">Type Unit</div><div class="col-8">: n200rt</div>
            <div class="col-4">Mode</div><div class="col-8">: Repeater</div>

        </div>
            <div class="flex justify-content-end">
                <Button label="Pas Foto" onClick={() => setVisible6(true)} />
                <Dialog header="Pas foto Pemilik" visible={visible6} onHide={() => setVisible6(false)} className='w-full mx-3 md:w-8 lg:w-6' >
                <b>Modal foto</b>
                </Dialog>
                <Button label="Foto Rumah" onClick={() => setVisible7(true)} className='mx-2'/>
                <Dialog header="Foto Rumah" visible={visible7} onHide={() => setVisible7(false)} className='w-full mx-3 md:w-8 lg:w-6 ' >
                <b>Modal foto Rumah</b>
                </Dialog>
                <Button label="Peta" icon="pi pi-map-marker" onClick={() => setVisible3(true)} />
                <Dialog header="Peta Lokasi" visible={visible3} onHide={() => setVisible3(false)} className='w-full mx-3 lg:w-10 h-full' >
                <b>Peta</b>
                </Dialog>
            </div>
        </Dialog>

    </div>
</>
)}





// ----------------------------------------------------- >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> 