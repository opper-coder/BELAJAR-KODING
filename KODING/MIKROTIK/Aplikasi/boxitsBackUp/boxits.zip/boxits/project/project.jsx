import ProjectJumbotron from "@/boxitsComp/project/projectJumbotron";
import TabProject from "@/boxitsComp/project/tabProject";

export default function Project() {
  return (
    <>
      <ProjectJumbotron />
      <TabProject />
      {/* ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>>  */}
      <div className="card mt-4 bg-yellow-300 text-red-900">
        <b>Agenda</b>
        <ul>
          <li>Pertimbangkan Search filter</li>
          <li>Kondisi jika admin:true maka bisa finishkan project</li>
          <li>
            Kondisi jika root:true maka bisa menampilkan dalam List SuperAdmin
          </li>
        </ul>
        <b>Modals</b>
        <ol>
          <li>Add project</li>
          <li>Paket</li>
          <li>Mapping</li>
          <li>Other</li>
        </ol>
        {/* ------------- */}
        <b>Add Project Properties</b>
        <ol>
          <li>
            buka modal &#8811; tombol aktifkan paket : diatasnya ada header dan
            keterangan, Akumulasi nilai cost
          </li>
          <li>Root location</li>
          <li>Name Officer</li>
          <li>Pilih Perangkat, jumlah, Cost</li>
          <li>Pilih Topologi</li>
          <ol>
            <li>Header: paket pemasangan, cost, durasi</li>
            <li>
              Deadline: perjalanan, persiapan, pengerjaan, sanitasi, ke gudang,
              belanja
            </li>
            <li>Router</li>
            <li>OLT</li>
            <li>HTB</li>
            <li>Outdoor</li>
            <li>Indoor</li>
            <li>Kabel</li>
            <li>Fast connector</li>
          </ol>
          <li>ceklist Kondisi Medan</li>
          <li>ceklist Kondisi Sosial</li>
          <li>officer requirement</li>
          <li>tool requirement</li>
          <li>ware requirement</li>
          <li>location requirement</li>
          <li>Timeline</li>
          <li>Durasi</li>
          <li>Cost</li>
          <li>Jumlah</li>
          <br />
          <b>Paket</b>
          <ol>
            <li>
              config mikrotik, config modem, pasang server, pasang OLT, config
              cloud, config: security, loadbalance, timing area, timescheduller,
              clean scheduller,
            </li>
            <li>
              Koneksi: OLT, HTB, Fastconn, plug Listrik, ODP, splitter, pigtail,
              UTP, rj45
            </li>
            <li>
              wiring, Tiang kabel, tiang antenna, panel outdor, solar panel,
              powerbank
            </li>
            <li>
              Analisis: OPM, teropong, rj45 tester, OTDR, Senter Laser, HP gmap,
              HT,
            </li>
            <li>Teknisi: Sambung, Pasang AksesPoint, Pasang antenna, </li>
          </ol>
          <br />
          <b>Topologi</b>
          <ol>
            <li>PTP</li>
            <li>OLT</li>
            <li>HTB</li>
            <li>Wireless</li>
            <li>UTP</li>
          </ol>
        </ol>

        <div> ------------------------------------------- </div>
        <b>Mapping Properties</b>
        <ol>
          <li>timeline project</li>
          <li>Assignment</li>
          <li>paket</li>
          <li>biaya</li>
          <li>durasi</li>
          <li>toolkit</li>
          <li>officer requirement</li>
          <li>tool requirement</li>
          <li>ware requirement</li>
          <li>location requirement</li>
          <br />
          <b>Target</b>
          <ol>
            <li>Memetakan berapa desa potensial di lokasi</li>
            <li>Menamukan Pelanggan rumah rapat</li>
            <li>Menemukan Target cabang</li>
            <li>Menemukan Sumber indiehome</li>
            <li>Menemukan Pelanggan voucher</li>
            <li>Menemukan Pelanggan Rumahan</li>
            <li>Tiang listrik</li>
            <li>menemukan hambatan pada lintasan:</li>
            <ul>
              <li>Jarak hutan lebih dari 5 KM</li>
              <li>Melintasi gunung</li>
              <li>Melintasi gedung</li>
              <li>Melintasi laut dan jurang</li>
              <li>Melintasi binatang buas</li>
              <li>Melintasi larangan hutan lindung atau angker</li>
              <li>Melintasi sungai</li>
              <li>Melintasi fasilitas umum</li>
              <li>Melintasi ruwetnya bangunan pasar</li>
              <li>Melintasi lahan orang</li>
              <li>Menumpang tiang orang</li>
              <li>
                belum ... &#8887; &#8887; &#8887; &#8887; &#8887; &#8887;
                &#8887; &#8887; &#8887;
              </li>
            </ul>
          </ol>
        </ol>

        <div> ------------------------------------------- </div>
        <b>Maintenance Properties</b>
        <ol>
          <li>Assignment</li>
          <li>paket</li>
          <li>biaya</li>
          <li>officer requirement</li>
          <li>tool requirement</li>
          <li>ware requirement</li>
          <li>location requirement</li>
          <br />
          <b>Masalah pada User</b>
          <ol>
            <li>Wifi tidak muncul</li>
            <li>Tidak bisa Loginpage</li>
            <li>Voucher di gunakan di perangkat lain</li>
            <li>Tidak bisa menerima IP DHCP client (manualkan IP)</li>
            <li>Static IP tidak bisa konek</li>
            <li>Masuk login page tidak bisa konek</li>
            <li>Bisa konek putus nyambung</li>
            <li>Lalot</li>
            <li>Hanya bisa pada applikasi tertentu saja</li>
            <li>Koneksi terbatas</li>
          </ol>
          <br />
          <b>Masalah pada Jaringan</b>
          <ol>
            <li>Putus kabel</li>
            <li>Kabel tidak putus no internet</li>
            <li>Redaman tinggi(bending)</li>
            <li>tiang ambruk</li>
            <li>listrik bermasalah</li>
            <li>perangkat bermasalah</li>
            <li>mengurai topologi kabel jaringan terpasang</li>
            <li>Kabel jatuh</li>
            <li>Regangan tinggi(tertarik)</li>
          </ol>
        </ol>
        <div> ------------------------------------------- </div>
        <b>Other Properties</b>
        <ol>
          <li>Fasilitator PLN untuk tiang</li>
          <li>Fasilitator Telkom</li>
          <li>Faasilitator Polsek</li>
          <li>Assignment</li>
          <li>paket</li>
          <li>biaya</li>
          <li>officer requirement</li>
          <li>tool requirement</li>
          <li>ware requirement</li>
          <li>location requirement</li>
        </ol>
        {/* ------ <<<<< ------ <<<<< ------ <<<<< ------ <<<<< ------ <<<<< ------ <<<<< ----- <<<<<  */}
      </div>
    </>
  );
}
