import ListProject from "@/boxitsComp/project/listProject";
import ProjectJumbotronAssign from "@/boxitsComp/project/projectJumbotronAssign";
import Timeline from "@/boxitsComp/project/timelineProject";
export default function Assign() {
  return (
    <>
      <ProjectJumbotronAssign />
      <Timeline />
      <ListProject />

      <div className="card bg-yellow-200 text-blue-800">
        <b>Progress Items</b>
        <ul>
          <li>
            paket satuan pekerjaan (By packet) (modal1) (modal &rarr; ceklist)
          </li>
          <li>
            paket grup pekerjaan (By packet) (modal1) (ada tombol switch &rarr;
            yang akan membentuk ceklist komposisi){" "}
          </li>
          <li>
            paket grup bisa di edit &rarr; bisa manual tanpa switch (modal1)
          </li>
          <li>Jumlah paket default = 1 &rarr; bisa di ubah (modal1)</li>
          <li>saat di create &rarr; masuk ke table daftar paket </li>
          <li>paket dapat di assign (modal2 &rarr; klik kanan pada project)</li>
          <li>setelah di assign, aktif dan memiliki progress ()</li>
          <li>saat progress step selesai maka warna titik berubah</li>
          <li>saat progress all selesai maka dana akan tersalurkan</li>
          <li>tiap titik memiliki modals yang dapat di edit</li>
          <li>Saat edit admin sifatnya request ke SA, lalu SA verify</li>
        </ul>
        <b>Syarat</b>
        <ul>
          <li>Setiap paket memiliki SOP</li>
          <li>
            fitur ini dapat di lihat oleh admin dan di cetakkan surat tugas
            berisi perintah, nilai, deadline dan SOP
          </li>
        </ul>
      </div>
    </>
  );
}
