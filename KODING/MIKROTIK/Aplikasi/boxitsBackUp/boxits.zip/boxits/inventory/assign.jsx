import InventoryJumbotron from "@/boxitsComp/inventory/inventoryJumbotron";
import OwnerMenu from "@/boxitsComp/inventory/ownerMenu";
import SummaryInventory from "@/boxitsComp/inventory/summaryInventory";

export default function Assign() {
  return (
    <>
      <InventoryJumbotron />
      <div className="flex gap-2">
        <OwnerMenu />
        <SummaryInventory />
      </div>
      <div className="card bg-yellow-300 text-blue-800">
        <b>fungsi utama</b>
        <ol>
          <li>pencatatan items, dan properti, barang</li>
          <li>kategori</li>
          <li>periode, bulan, musim, lokasi, putaran</li>
          <li>status: new, running, expired, annualy, broken, finish</li>
          <li>assign</li>
          <li>tabel monitoring, evaluating</li>
          <li>barcode</li>
          <li>printing label</li>
        </ol>
        <b>Fungsi administrator</b>
        <ul>
          <li>Bisa dilihat secara owner sekaligus memiliki lokasi</li>
          <li>
            jika di lihat secara Lokasi akan terlihat random atau bisa di pilih
            pemiliknya
          </li>
          <li>Admin dan super admin</li>
          <li>monitoring root super admin dan admin</li>
          <li>
            Ringkasan pembelian investor dan lokasinya mungkin berhubungan
            dengan dasahboard dan juga penjualan product
          </li>
          <li>Ringkasan pembelian investor dan lokasinya</li>
        </ul>
      </div>
    </>
  );
}
