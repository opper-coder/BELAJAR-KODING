import HargaProduct from "@/boxitsComp/inventory/HargaProduct";
import InventoryJumbotron2 from "@/boxitsComp/inventory/inventoryJumbotron2";
import MenuInventory from "@/boxitsComp/inventory/menuInventory";
import RootSideMenu from "@/boxitsComp/inventory/rootSideMenu";
import { Message } from "primereact/message";

export default function Product() {
  return (
    <>
      <InventoryJumbotron2 />
      <div className="flex w-full gap-2">
        <div className="flex-1">
          <Message
            className="w-full mb-2 justify-content-start px-4"
            severity="success"
            content={
              <p>
                Daftar <b> Harga Product</b> di pasaran{" "}
              </p>
            }
          />
          <div className="flex gap-2x">
            <MenuInventory />
            <HargaProduct />
          </div>
        </div>
        <div className="flex-1">
          <Message
            className="w-full mb-2 justify-content-start px-4"
            severity="warn"
            content={
              <p>
                Daftar Harga <b>Penyesuaian Product</b> di pasaran{" "}
              </p>
            }
          />
          <div className="flex">
            <RootSideMenu />
            <HargaProduct />
          </div>
        </div>
      </div>
    </>
  );
}
