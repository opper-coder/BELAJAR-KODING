import { TabView, TabPanel } from "primereact/tabview";
import { Message } from "primereact/message";
import VoucherAdminJumbotron from "@/boxitsComp/transaction/voucherAdminJumbotron";
import ActionAdmin from "@/boxitsComp/transaction/ActionAdmin";
import ActivityAdmin from "@/boxitsComp/transaction/activityAdmin";
import TransactionAdmin from "@/boxitsComp/transaction/transactionAdmin";
import TableActivatedVoucher from "@/boxitsComp/voucher/TableActivatedVoucher";

// import RootSideMenuProduct from "@/boxitsComp/price/rootSideMenuProduct";
// import HargaDasarPaketAdmin from "@/boxitsComp/voucher/HargaDasarPaketAdmin";
// import HargaDasarPaketAdminPenyesuaian from "@/boxitsComp/voucher/HargaDasarPaketAdminPenyesuaian";
// import HargaDasarProductAdmin from "@/boxitsComp/voucher/HargaDasarProductAdmin";
// import HargaDasarProductAdminPenyesuaian from "@/boxitsComp/voucher/HargaDasarProductAdminPenyesuaian";
// import RootSideMenuPacket from "@/boxitsComp/voucher/rootSideMenuPacket";
// import RootSideMenuProduct from "@/boxitsComp/voucher/rootSideMenuProduct";
// import AdminTree from "@/boxitsComp/users/adminTree";
// import MenuInventory from "@/boxitsComp/inventory/menuInventory";
// import HargaEquipmentAdmin from "@/boxitsComp/voucher/HargaEquipmentAdmin";
// import HargaEquiomentAdminP from "@/boxitsComp/voucher/HargaEquiomentAdminP";
// import PacketAdaptationTable from "@/boxitsComp/voucher/PacketAdaptationTable";
// import ProductAdaptationTable from "@/boxitsComp/voucher/ProductAdaptationTable";

// -----
export default function Admin() {
  const judul = (classwarna, jumlah, judul) => {
    return (
      <>
        <Message
          severity={classwarna}
          className="w-full justify-content-start px-4"
          content={
            <div className="ml-2">
              {judul}: <b>Rp. {jumlah}</b>
            </div>
          }
        />
      </>
    );
  };
  return (
    <>
      <VoucherAdminJumbotron />
      <div>
        <TabView>
          <TabPanel header="Transaction">
            <div className="flex gap-2">
              <div>
                {judul("success", 20000, "Debet: ")}
                <TransactionAdmin />
              </div>
              <div className="flex-1">
                {judul("info", 20000, "Kredit: ")}
                <ActivityAdmin />
              </div>
            </div>
          </TabPanel>
          <TabPanel header="Action">
            <ActionAdmin />
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
