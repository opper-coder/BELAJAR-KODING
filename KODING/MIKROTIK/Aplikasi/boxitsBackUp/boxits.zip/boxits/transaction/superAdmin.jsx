import { TabView, TabPanel } from "primereact/tabview";
import { Message } from "primereact/message";
import VoucherSAdminJumbotron from "@/boxitsComp/transaction/voucherSAdminJumbotron";
import CapitalSA from "@/boxitsComp/transaction/capitalSA";
import ActivitySA from "@/boxitsComp/transaction/activitySA";

// import RootSideMenuProduct from "@/boxitsComp/voucher/rootSideMenuProduct";
// import RootSideMenuPacket from "@/boxitsComp/voucher/rootSideMenuPacket";
// import PriceProductSA from "@/boxitsComp/voucher/priceProductSA";
// import PricePacketSA from "@/boxitsComp/voucher/pricePacketSA";
// import PriceEquipmentPSA from "@/boxitsComp/voucher/priceEquipmentPSA";
// import PriceEquipmentSA from "@/boxitsComp/voucher/priceEquipmentSA";
// import PricePacketPenyesuaianSA from "@/boxitsComp/voucher/pricePacketPenyesuaianSA";
// import PriceProductPSA from "@/boxitsComp/voucher/priceProductPSA";
// import Capital from "@/boxitsComp/voucher/capital";
// import Activity from "@/boxitsComp/voucher/activity";
// import PriceProductPenyesuaian from "@/boxitsComp/voucher/priceProductPenyesuaian";
// import PricePacketPenyesuaian from "@/boxitsComp/voucher/pricePacketPenyesuaian";
// import PriceEquipmentPenyesuaian from "@/boxitsComp/voucher/priceEquipmentP";
// import PriceEquipment from "@/boxitsComp/voucher/priceEquipment";
// import MenuInventory from "@/boxitsComp/inventory/menuInventory";
// import RootSideMenu from "@/boxitsComp/inventory/rootSideMenu";
// import OwnerMenu from "@/boxitsComp/inventory/ownerMenu";
// import AdminTree from "@/boxitsComp/users/adminTree";

// ------------------------------------------------------------------------
export default function Rools() {
  return (
    <>
      <VoucherSAdminJumbotron />
      <div className="mt-4">
        <TabView>
          <TabPanel header="Transaction">
            <div className="flex gap-2">
              <div>
                <div className="mr-2x mb-2">
                  <Message
                    severity="success"
                    className="w-full justify-content-start px-4"
                    content={
                      <span className="ml-2">
                        Debet: <b>Rp. 40.000.000</b>
                      </span>
                    }
                  />
                </div>
                <div className="card">
                  <CapitalSA />
                </div>
              </div>
              <div className="flex-1">
                <div className="mr-2x mb-2">
                  <Message
                    severity="info"
                    className="w-full justify-content-start px-4"
                    content={
                      <span className="ml-2">
                        Kredit: <b>Rp. 20.000.000</b>
                      </span>
                    }
                  />
                </div>
                <div className="card mr-2">
                  <ActivitySA />
                </div>
              </div>
            </div>
          </TabPanel>
          <TabPanel header="Action"></TabPanel>
        </TabView>
      </div>
    </>
  );
}
