import { TabView, TabPanel } from "primereact/tabview";
import { Message } from "primereact/message";
import VoucherRulesJumbotron from "../../../boxitsComp/transaction/voucherRulesJumbotron";
import Capital from "@/boxitsComp/transaction/capital";
import Activity from "@/boxitsComp/transaction/activity";

// import RootSideMenu from "@/boxitsComp/inventory/rootSideMenu";
// import AdminTree from "@/boxitsComp/users/adminTree";
// import MenuInventory from "@/boxitsComp/inventory/menuInventory";
// import RootSideMenuProduct from "@/boxitsComp/voucher/rootSideMenuProduct";
// import RootSideMenuPacket from "@/boxitsComp/voucher/rootSideMenuPacket";
// import PriceProduct from "@/boxitsComp/voucher/priceProduct";
// import PricePacket from "@/boxitsComp/voucher/pricePacket";
// import PriceProductPenyesuaian from "@/boxitsComp/voucher/priceProductPenyesuaian";
// import PricePacketPenyesuaian from "@/boxitsComp/voucher/pricePacketPenyesuaian";
// import PriceEquipment from "@/boxitsComp/voucher/priceEquipment";
// import PriceEquipmentP from "@/boxitsComp/voucher/priceEquipmentP";

export default function Root() {
  const judul = (classwarna, jumlah, judul) => {
    return (
      <>
        <Message
          severity={classwarna}
          className="w-full justify-content-start px-4"
          content={
            <div className="ml-2">
              {judul}: <b>Rp. {jumlah}</b>
            </div>
          }
        />
      </>
    );
  };

  return (
    <>
      <VoucherRulesJumbotron />
      <div className="mt-4">
        <TabView>
          <TabPanel header="Transaction">
            <div className="flex gap-2">
              <div>
                <div className="mr-2x mb-2">
                  {judul("success", 50000000, "debet")}
                </div>
                <div className="card">
                  <Capital />
                </div>
              </div>
              <div className="flex-1">
                <div className="mr-2x mb-2">
                  {judul("info", 40000000, "Kredit")}
                </div>
                <div className="card mr-2">
                  <Activity />
                </div>
              </div>
            </div>
          </TabPanel>
          <TabPanel header="Action"></TabPanel>
        </TabView>
      </div>
    </>
  );
}
