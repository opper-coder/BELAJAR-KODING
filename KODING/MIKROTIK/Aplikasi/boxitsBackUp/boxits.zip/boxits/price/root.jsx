// import HargaDasarPaketProjectPenyesuaian from "@/boxitsComp/price/HargaDasarPaketAdminPenyesuaian";
// import HargaDasarPaketProject from "@/boxitsComp/price/HargaDasarPaketProject";
import { Message } from "primereact/message";
import Capital from "@/boxitsComp/voucher/capital";
import Activity from "@/boxitsComp/voucher/activity";
import RootSideMenu from "@/boxitsComp/inventory/rootSideMenu";
import OwnerMenu from "@/boxitsComp/inventory/ownerMenu";

import { TabView, TabPanel } from "primereact/tabview";
import AdminTree from "@/boxitsComp/users/adminTree";
import MenuInventory from "@/boxitsComp/inventory/menuInventory";
import RootSideMenuProduct from "@/boxitsComp/price/rootSideMenuProduct";
import VoucherRulesJumbotron from "../../../boxitsComp/price/voucherRulesJumbotron";
import RootSideMenuPacket from "@/boxitsComp/price/rootSideMenuPacket";
import PriceProduct from "@/boxitsComp/price/priceProduct";
import PricePacket from "@/boxitsComp/price/pricePacket";
import PriceProductPenyesuaian from "@/boxitsComp/price/priceProductPenyesuaian";
import PricePacketPenyesuaian from "@/boxitsComp/price/pricePacketPenyesuaian";
import PriceEquipmentP from "@/boxitsComp/price/priceEquipmentP";
import PriceEquipment from "@/boxitsComp/price/priceEquipment";

export default function Root() {
  return (
    <>
      <VoucherRulesJumbotron />
      <div className="mt-4">
        <TabView>
          <TabPanel header="Product">
            <div className="flex gap-2">
              {/* <OwnerMenu /> */}
              {/* <RootSideMenu /> */}
              <AdminTree />
              <RootSideMenuProduct />
              <PriceProduct />
              <PriceProductPenyesuaian />
            </div>
          </TabPanel>
          <TabPanel header="Packet">
            <div className="flex gap-2">
              <AdminTree />
              <RootSideMenuPacket />
              <PricePacket />
              <PricePacketPenyesuaian />
            </div>
          </TabPanel>
          <TabPanel header="Equipment">
            <div className="flex gap-2">
              <AdminTree />
              <MenuInventory />
              <PriceEquipment />
              <PriceEquipmentP />
            </div>
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
