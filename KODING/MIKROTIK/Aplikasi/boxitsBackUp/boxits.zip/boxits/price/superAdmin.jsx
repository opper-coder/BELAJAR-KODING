import { Message } from "primereact/message";
import Capital from "@/boxitsComp/voucher/capital";
import Activity from "@/boxitsComp/voucher/activity";
import PriceProductPenyesuaian from "@/boxitsComp/voucher/priceProductPenyesuaian";
import PricePacketPenyesuaian from "@/boxitsComp/voucher/pricePacketPenyesuaian";
import PriceEquipmentPenyesuaian from "@/boxitsComp/voucher/priceEquipmentP";
import PriceEquipment from "@/boxitsComp/voucher/priceEquipment";
import CapitalSA from "@/boxitsComp/voucher/capitalSA";
import ActivitySA from "@/boxitsComp/voucher/activitySA";

import { TabView, TabPanel } from "primereact/tabview";
import RootSideMenuProduct from "@/boxitsComp/voucher/rootSideMenuProduct";
import RootSideMenuPacket from "@/boxitsComp/voucher/rootSideMenuPacket";
import VoucherSAdminJumbotron from "@/boxitsComp/voucher/voucherSAdminJumbotron";
import PriceProductSA from "@/boxitsComp/voucher/priceProductSA";
import PricePacketSA from "@/boxitsComp/voucher/pricePacketSA";
import MenuInventory from "@/boxitsComp/inventory/menuInventory";
import AdminTree from "@/boxitsComp/users/adminTree";
import PriceEquipmentPSA from "@/boxitsComp/voucher/priceEquipmentPSA";
import PriceEquipmentSA from "@/boxitsComp/voucher/priceEquipmentSA";
import PricePacketPenyesuaianSA from "@/boxitsComp/voucher/pricePacketPenyesuaianSA";
import PriceProductPSA from "@/boxitsComp/voucher/priceProductPSA";

export default function Rools() {
  return (
    <>
      <VoucherSAdminJumbotron />
      <div className="mt-4">
        <TabView>
          <TabPanel header="Product">
            <div className="flex gap-2">
              <AdminTree />
              <RootSideMenuProduct />
              <PriceProductSA />
              <PriceProductPSA />
            </div>
          </TabPanel>
          <TabPanel header="Packet">
            <div className="flex gap-2">
              <AdminTree />
              <RootSideMenuPacket />
              <PricePacketSA />
              <PricePacketPenyesuaianSA />
            </div>
          </TabPanel>
          <TabPanel header="Equipment">
            <div className="flex gap-2">
              <AdminTree />
              <MenuInventory />
              <PriceEquipmentSA />
              <PriceEquipmentPSA />
            </div>
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
