// import HargaDasarPaketAdminPenyesuaian from "@/boxitsComp/price/HargaDasarPaketAdminPenyesuaian";
// import HargaEquiomentAdminP from "@/boxitsComp/price/HargaDasarPaketProjectPenyesuaian";
import { Message } from "primereact/message";
import ActionAdmin from "@/boxitsComp/voucher/ActionAdmin";
import PacketAdaptationTable from "@/boxitsComp/voucher/PacketAdaptationTable";
import ActivityAdmin from "@/boxitsComp/voucher/activityAdmin";
import TransactionAdmin from "@/boxitsComp/voucher/transactionAdmin";
import ProductAdaptationTable from "@/boxitsComp/voucher/ProductAdaptationTable";

import { TabView, TabPanel } from "primereact/tabview";
import AdminTree from "@/boxitsComp/users/adminTree";
import RootSideMenuPacket from "@/boxitsComp/price/rootSideMenuPacket";
import RootSideMenuProduct from "@/boxitsComp/price/rootSideMenuProduct";
import VoucherAdminJumbotron from "@/boxitsComp/price/voucherAdminJumbotron";
import MenuInventory from "@/boxitsComp/inventory/menuInventory";
import HargaDasarPaketAdmin from "@/boxitsComp/price/HargaDasarPaketAdmin";
import HargaDasarProductAdmin from "@/boxitsComp/price/HargaDasarProductAdmin";
import HargaDasarProductAdminPenyesuaian from "@/boxitsComp/price/HargaDasarProductAdminPenyesuaian";
import HargaEquipmentAdmin from "@/boxitsComp/price/HargaEquipmentAdmin";
import HargaEquipmentAdminP from "@/boxitsComp/price/HargaEquiomentAdminP";
import HargaDasarPaketAdminP from "@/boxitsComp/price/HargaDasarPaketAdminP";

export default function Admin() {
  return (
    <>
      <VoucherAdminJumbotron />
      <div className="cardx mt-4">
        <TabView>
          <TabPanel header="Product">
            <div className="flex gap-2  ">
              <AdminTree />
              <RootSideMenuProduct />
              <HargaDasarProductAdmin />
              <HargaDasarProductAdminPenyesuaian />
            </div>
          </TabPanel>
          <TabPanel header="Packet">
            <div className="flex gap-2">
              <AdminTree />
              <RootSideMenuPacket />
              <HargaDasarPaketAdmin />
              <HargaDasarPaketAdminP />
            </div>
          </TabPanel>
          <TabPanel header="Equipment">
            <div className="flex gap-2">
              <AdminTree />
              <MenuInventory />
              <HargaEquipmentAdmin />
              <HargaEquipmentAdminP />
            </div>
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
