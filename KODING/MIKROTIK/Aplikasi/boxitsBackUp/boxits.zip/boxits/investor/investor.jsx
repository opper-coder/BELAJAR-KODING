import InvestorJumbotron from "@/boxitsComp/investor/InvestorJumbotron";
import InvestorLayout from "@/boxitsComp/investor/InvestorLayout";

export default function Investor() {
  return (
    <>
      <InvestorJumbotron />
      <InvestorLayout />
      {/* sementara, hapus ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>>  */}
      <div className="card mt-4 bg-yellow-300 text-red-900">
        <b>Fungsi Utama</b>
        <ul>
          <li>Tanam modal</li>
          <li>Alokasi Lokasi Pasar</li>
          <li>Monitoring</li>
          <li>Prosentase</li>
          <li>Kontrak Kerja</li>
          <li>Tidak kerja melainkan hanya Investasi</li>
          <li>Penghasilan di cairkan tiap Bulan</li>
          <li>
            Evaluasi 3 Hari sebelum akhir bulan supaya pencairan tepat waktu
          </li>
          <li>Minimal Investasi 1 tahun</li>
        </ul>
        <b>Langkah selanjutnya</b>
        <ul>
          <li>evaluasi pendapatan</li>
          <li>ambil paket</li>
          <li>tentukan lokasi pasar</li>
          <li>ambil buffering</li>
          <li>cek out</li>
          <li>monitoring pelaksanaan</li>
          <li>cairkan profit</li>
          <li>akhir kontrak</li>
          <li>perpanjang</li>
          <li>kontrak baru</li>
        </ul>
      </div>
      {/* end sementara, hapus ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>>  */}
    </>
  );
}
