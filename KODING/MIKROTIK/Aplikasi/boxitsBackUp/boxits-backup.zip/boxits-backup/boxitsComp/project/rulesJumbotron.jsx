import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";

export default function RulesJumbotron() {
  // menubar ------------------------
  const items = [
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Project Rules"
        subTitle="Project"
        className="mb-4 surface-300"
      >
        <div className="flex gap-4 text-blue-700 m-0">
          <div className="flex-1">
            <b>Fungsi pokok</b>

            <ul className="">
              <li>Penyesuaian Harga Paket</li>
              <li>Di lakukan pada Setiap Lokasi Unit</li>
              <li>Di kirim metode request ke Super Admin</li>
            </ul>
          </div>
          <div className="flex-1">
            <b>Fungsi tambahan</b>
            <ol>
              <li>Melihat Selisih Perubahan pada harga unit</li>
              <li>Berdasarkan Lokasi unit bertanda merah dan kuning</li>
              <li>Reset Perubahan</li>
              <li>Edit</li>
            </ol>
          </div>
        </div>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-2" end={end} />
    </>
  );
}
