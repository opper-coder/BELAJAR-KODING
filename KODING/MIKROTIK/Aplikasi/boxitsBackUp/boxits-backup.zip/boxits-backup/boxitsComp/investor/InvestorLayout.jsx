import { TabView, TabPanel } from "primereact/tabview";
import Evaluasi from "./Evaluasi";
import InvoiceInvestor from "./InvoiceInvestor";
import MonitoringInvestor from "./MonitoringInvestor";

export default function InvestorLayout() {
  return (
    <TabView>
      <TabPanel header="Evaluasi">
        <Evaluasi />
      </TabPanel>
      <TabPanel header="Transaksi">
        <InvoiceInvestor />
      </TabPanel>
      <TabPanel header="Monitoring">
        <MonitoringInvestor />
      </TabPanel>
    </TabView>
  );
}
