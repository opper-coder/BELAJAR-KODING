export default function InvoiceInvestor() {
  return (
    <>
      <div className="card">
        <b>paket tersedia </b>
        <ul>
          <li>paket list yang di ambil</li>
          <li>properties</li>
          <li>tanggal start dan jatuh tempo </li>
          <li>nilai investasi</li>
          <li>nilai persentase</li>
          <li>profil investor</li>
          <li>transaksi </li>
          <li>cairkan saldo</li>
        </ul>
        <b>paket tersedia</b>
        <ul>
          <li>paket list</li>
          <li>harga</li>
          <li>topologi</li>
          <li>lokasi</li>
          <li>flag buffer yang tersedia</li>
          <li>assign paket</li>
        </ul>
      </div>
    </>
  );
}
