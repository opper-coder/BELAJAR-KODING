import React, { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Message } from "primereact/message";

export default function RootSideMenuPacket() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const countries = [
    { name: "Servers", icon: "pi pi-server mr-3" },
    { name: "Mapping", icon: "pi pi-map-marker mr-3" },
    { name: "Maintenace", icon: "pi pi-wrench mr-3" },
    { name: "Other", icon: "pi pi-box mr-3" },
  ];

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
      </div>
    );
  };

  return (
    <div>
      <Message
        severity="info"
        className="w-full mb-2 justify-content-start px-4"
        content={
          <div className="ml-2 ">
            Packet: <b>Server</b>
          </div>
        }
      />
      <ListBox
        value={selectedCountry}
        onChange={(e) => {
          setSelectedCountry(e.value);
          alert("halo" + e.value.name);
        }}
        options={countries}
        optionLabel="name"
        itemTemplate={countryTemplate}
        className="w-full md:w-14rem"
        listStyle={{ maxHeight: "400px" }}
      />
    </div>
  );
}
