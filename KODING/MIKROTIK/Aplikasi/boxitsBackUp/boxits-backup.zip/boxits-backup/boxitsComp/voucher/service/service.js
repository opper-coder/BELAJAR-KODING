export const CustomerService = {
    getData() {
        return [
            {
                id:1,
                idserver:'bgi-pd-123',
                server:'tambora',
                lokasi:'padang',
                harga:2000,
                // status: 'unqualified',
                verified: true,

            },
            {
                id:'2',
                idserver:'bgi-pd-124',
                server:'jayakarta',
                lokasi:'dodung',
                harga:2000,
                // status: 'unqualified',
                verified: false,

            },
            {
                id:'3',
                idserver:'bgi-pd-125',
                server:'gelora',
                lokasi:'adean',
                harga:2000,
                // status: 'unqualified',
                verified: true,

            },
            {
                id:'4',
                idserver:'bgi-pd-126',
                server:'sangalu',
                lokasi:'lonas',
                harga:2000,
                // status: 'unqualified',
                verified: false,
            }
        ];
    },

    getCustomersSmall() {
        return Promise.resolve(this.getData().slice(0, 10));
    },

    getCustomersMedium() {
        return Promise.resolve(this.getData().slice(0, 50));
    },

    getCustomersLarge() {
        return Promise.resolve(this.getData().slice(0, 200));
    },

    getCustomersXLarge() {
        return Promise.resolve(this.getData());
    },

    // getCustomers(params) {
    //     const queryParams = params
    //         ? Object.keys(params)
    //               .map((k) => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
    //               .join('&')
    //         : '';

    //     return fetch('https://www.primefaces.org/data/customers?' + queryParams).then((res) => res.json());
    // }
};
