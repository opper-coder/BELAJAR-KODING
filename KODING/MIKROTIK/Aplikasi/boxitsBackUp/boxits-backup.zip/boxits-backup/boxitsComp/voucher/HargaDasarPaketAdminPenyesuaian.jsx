// import { useState, useEffect } from "react";
// import { DataTable } from "primereact/datatable";
// import { Column } from "primereact/column";
// import { ProductService } from "./service/ProductService";
// import { Message } from "primereact/message";

// export default function HargaDasarPaketAdminPenyesuaian() {
//   const [products, setProducts] = useState([]);

//   useEffect(() => {
//     ProductService.getProducts().then((data) => setProducts(data));
//   }, []);

//   return (
//     <div className="flex-1">
//       <Message
//         className="w-full"
//         severity="warn"
//         content={<b>Harga Adaptasi sesuai Lokasi</b>}
//       />
//       <DataTable
//         value={products}
//         tableStyle={{ minWidth: "20rem" }}
//         size="small"
//         resizableColumns
//         paginator
//         rows={8}
//       >
//         <Column field="code" header="Code"></Column>
//         <Column field="name" header="Paket"></Column>
//         <Column field="category" header="Quota"></Column>
//         <Column field="quantity" header="Bandwidth"></Column>
//         <Column field="quantity" header="MAC"></Column>
//       </DataTable>
//     </div>
//   );
// }

import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { Message } from "primereact/message";
import { Button } from "primereact/button";
// -----
export default function HargaDasarPaketProjectPenyesuaian() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProductsMini().then((data) => setProducts(data));
  }, []);

  const statusBodyTemplate2 = (product) => {
    if (product.quantity < 40 && product.rating == 3) {
      // jika harga product > dari standard  dan verify OK
      return <i className="pi pi-caret-up text-blue-500"></i>;
    } else if (product.quantity < 40 && product.rating > 3) {
      // jika harga product < dari standard  dan verify OK
      return <i className="pi pi-caret-down text-green-500"></i>;
    } else {
      // jika verify false
      return <i className="pi pi-info-circle text-red-500"></i>;
    }
  };
  // context ----------------------------------
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Edit Request",
      icon: "pi pi-fw pi-pencil",
      command: () => viewProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    alert(product.name);
  };

  // end context ----------------------------------
  return (
    <div className="mr-2 flex-1">
      {/* <Message
        severity="warn"
        content={<b>Harga Adaptasi Packet sesuai Lokasi</b>}
        className="w-full justify-content-start px-4"
      /> */}

      <Button
        label="Request Penyesuaian"
        icon="pi pi-reply"
        outlined
        className="w-full"
        onClick={() => alert("penyesuaian Harga")}
      />
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />

      <div className="card mt-2">
        <DataTable
          value={products}
          onContextMenu={(e) => cm.current.show(e.originalEvent)}
          contextMenuSelection={selectedProduct}
          onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
          tableStyle={{ minWidth: "30rem" }}
          size="small"
          resizableColumns
          paginator
          rows={8}
        >
          <Column field="name" header="Unit"></Column>
          <Column
            field="quantity"
            header="Status"
            body={statusBodyTemplate2}
          ></Column>
          <Column field="quantity" header="Selisih"></Column>
          <Column field="code" header="Paket"></Column>
        </DataTable>
      </div>
    </div>
  );
}
