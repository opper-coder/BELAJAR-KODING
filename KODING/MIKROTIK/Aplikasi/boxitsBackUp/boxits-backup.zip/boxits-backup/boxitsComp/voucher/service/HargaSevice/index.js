

export const HargaService = {
    getFVoucher(){
        return [
            {field: 'id', header: '#'},
            {field: 'paket', header: 'Paket'},
            {field: 'quota', header: 'Quota'},
            {field: 'bandwidth', header: 'Bandwidth'},
            {field: 'durasi', header: 'Durasi'},
            {field: 'perangkat', header: 'MAC'},
        ]       
    },
    getHVoucher(){
        return [
            {
                id: 1,
                paket: 2000,
                quota: 'unlimited',
                bandwidth: '1mbps',
                durasi: '2jam',
                perangkat: 1,
            },
            {                
                id: 2,
                paket: 3000,
                quota: 'unlimited',
                bandwidth: '1mbps',
                durasi: '4jam',
                perangkat: 1,
            },
            {                
                id: 3,
                paket: 5000,
                quota: 'unlimited',
                bandwidth: '1mbps',
                durasi: '12jam',
                perangkat: 1,
            },
        ]       
    },
    getFData(){
        return [
            {field: 'id', header: '#'},
            {field: 'paket', header: 'Paket'},
            {field: 'quota', header: 'Quota'},
            {field: 'bandwidth', header: 'Bandwidth'},
            {field: 'durasi', header: 'Durasi'},
            {field: 'perangkat', header: 'MAC'},
        ]
    },           
    getHData(){
        return [
            {
                id: 1,
                paket: 2000,
                quota: '2gb',
                bandwidth: '2mbps',
                durasi: '2jam',
                perangkat: 1,
            },
            {
                id: 2,
                paket: 3000,
                quota: '4gb',
                bandwidth: '2mbps',
                durasi: '2jam',
                perangkat: 1,
            },
            {
                id: 3,
                paket: 5000,
                quota: '12gb',
                bandwidth: '2mbps',
                durasi: '2jam',
                perangkat: 1,
            },
        ]
    },         
    getFPppoe(){
        return [
            {field: 'id', header: '#'},
            {field: 'paket', header: 'Paket'},
            {field: 'harga', header: 'Harga'},
            {field: 'bandwidth', header: 'Bandwidth'},
            {field: 'durasi', header: 'Durasi'},
            {field: 'perangkat', header: 'MAC'},
        ]       
    },
    getHPppoe(){
        return [
            {},
            {},
            {},
        ]       
    },
    getFSaldo(){
        return [
            {field: 'id', header: '#'},
            {field: 'paket', header: 'Paket'},
            {field: 'harga', header: 'Harga'},
            {field: 'durasi', header: 'Bandwidth'},
            {field: 'roaming', header: 'Roaming'},
        ]       
    },
    getHSaldo(){
        return [
            {
                id:1,
                paket:2000,
                harga:2000,
                durasi:'3bulan',
                roaming:2000,
            },
            {
                id:2,
                paket:3000,
                harga:3000,
                durasi:'3bulan',
                roaming:2000,
            },
            {
                id:3,
                paket:5000,
                harga:5000,
                durasi:'3bulan',
                roaming:2000,
            },
        ]       
    },
    getFReseller(){
        return [
            {field: 'id', header: '#'},
            {field: 'paket', header: 'Paket'},
            {field: 'harga', header: 'Harga'},
            {field: 'durasi', header: 'Durasi'},
            {field: 'bonus', header: 'Bonus'},
            {field: 'denda', header: 'Charge'},
            {field: 'cairkan', header: 'Cairkan'},
            {field: 'minSaldo', header: 'Saldo Minimal'},
        ]       
    },
    getHReseller(){
        return [
            {},
            {},
            {},
        ]
    },
    getFPromo(){
        return [
            {field: 'id', header: '#'},
            {field: 'paket', header: 'Paket'},
            {field: 'all', header: 'All'},
            {field: 'member', header: 'Member'},
            {field: 'spesial', header: 'Spesial'},
        ]       
    },
    getHPromo(){
        return [
            {},
            {},
            {},
        ]       
    },
    getFInsentif(){
        return [
            {field: 'id', header: '#'},
            {field: 'paket', header: 'Paket'},
            {field: 'deskripsi', header: 'Deskripsi'},
            {field: 'penerima', header: 'Penerima'},
            {field: 'harga', header: 'Harga'},
        ]
    },
    getHInsentif(){
        return [
            {},
            {},
            {},
        ]
    },
    getFPlnOff(){
        return [
            {field: 'id', header: '#'},
            {field: 'paket', header: 'Paket'},
            {field: 'quota', header: 'Paket'},
            {field: 'bandwidth', header: 'Bandwidth'},
            {field: 'durasi', header: 'Durasi'},
            {field: 'perangkat', header: 'MAC'},
        ]
    },
    getHPlnOff(){
        return [
            {},
            {},
            {},
        ]
    },
    getFPaket(){
        return [
            {field: 'id', header: '#'},
            {field: 'petugas', header: 'Petugas'},
            {field: 'kategori', header: 'Kategori'},
            {field: 'subKategori', header: 'Sub Kategori'},
            {field: 'paket', header: 'Paket'},
            {field: 'harga', header: 'Harga'},
        ]       
    },
    getHPaket(){
        return [
            {},
            {},
            {},
        ]       
    },
    getFSppd(){
        return [
            {field: 'id', header: '#'},
            {field: 'paket', header: 'Paket'},
            {field: 'jarak', header: 'Jarak'},
            {field: 'moda', header: 'Moda Transport'},
            {field: 'nginap', header: 'Menginap'},
            {field: 'akomodasi', header: 'Akomodasi'},
            {field: 'libur', header: 'Libur'},
        ]       
    },
    getHSppd(){
        return [
            {},
            {},
            {},
        ]       
    },
// pemanggil ---------
    getFieldVoucher(){
        return Promise.resolve(this.getFVoucher().slice(0, 15));
    },
    getHargaVoucher(){
        return Promise.resolve(this.getHVoucher().slice(0, 15));
    },
    getFieldData(){
        return Promise.resolve(this.getFData().slice(0, 15));
    },
    getHargaData(){
        return Promise.resolve(this.getHData().slice(0, 15));
    },
    getFieldPppoe(){
        return Promise.resolve(this.getFPppoe().slice(0, 15));
    },
    getHargaPppoe(){
        return Promise.resolve(this.getHPppoe().slice(0, 15));
    },
    getFieldSaldo(){
        return Promise.resolve(this.getFSaldo().slice(0, 15));
    },
    getHargaSaldo(){
        return Promise.resolve(this.getHSaldo().slice(0, 15));
    },
    getFieldReseller(){
        return Promise.resolve(this.getFReseller().slice(0, 15));
    },
    getHargaReseller(){
        return Promise.resolve(this.getHReseller().slice(0, 15));
    },
    getFieldPromo(){
        return Promise.resolve(this.getFPromo().slice(0, 15));
    },
    getHargaPromo(){
        return Promise.resolve(this.getHPromo().slice(0, 15));
    },
    getFieldInsentif(){
        return Promise.resolve(this.getFInsentif().slice(0, 15));
    },
    getHargaInsentif(){
        return Promise.resolve(this.getHInsentif().slice(0, 15));
    },
    getFieldPlnOff(){
        return Promise.resolve(this.getFPlnOff().slice(0, 15));
    },
    getHargaPlnOff(){
        return Promise.resolve(this.getHPlnOff().slice(0, 15));
    },
    getFieldPaket(){
        return Promise.resolve(this.getFPaket().slice(0, 15));
    },
    getHargaPaket(){
        return Promise.resolve(this.getHPaket().slice(0, 15));
    },
    getFieldSppd(){
        return Promise.resolve(this.getFPromo().slice(0, 15));
    },
    getHargaSppd(){
        return Promise.resolve(this.getHPromo().slice(0, 15));
    },

}