import { TabView, TabPanel } from "primereact/tabview";
import RootSideMenuProduct from "./rootSideMenuProduct";
import RootSideMenuPacket from "./rootSideMenuPacket";
import ProductAdaptationTable from "./ProductAdaptationTable";
import HargaDasarProductAdmin from "./HargaDasarProductAdmin";
import HargaDasarProductAdminPenyesuaian from "./HargaDasarProductAdminPenyesuaian";
import PacketAdaptationTable from "./PacketAdaptationTable";
import HargaDasarPaketAdmin from "./HargaDasarPaketAdmin";
import HargaDasarPaketAdminPenyesuaian from "./HargaDasarPaketAdminPenyesuaian";

export default function ProductAdaptation() {
  return (
    <>
      <TabView>
        <TabPanel header="Product">
          <div className="flex gap-2 -ml-4 ">
            <RootSideMenuProduct />
            <div className="flex-1">
              <ProductAdaptationTable />
              <div className="flex gap-4 w-full">
                <HargaDasarProductAdmin />
                <HargaDasarProductAdminPenyesuaian />
              </div>
            </div>
          </div>
        </TabPanel>
        <TabPanel header="Packet">
          <div className="flex gap-2 -ml-4">
            <RootSideMenuPacket />
            <div className="flex-1">
              <PacketAdaptationTable />
              <div className="flex gap-4 w-full">
                <HargaDasarPaketAdmin />
                <HargaDasarPaketAdminPenyesuaian />
              </div>
            </div>
          </div>
        </TabPanel>
      </TabView>
    </>
  );
}
