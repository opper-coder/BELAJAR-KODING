import React, { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Message } from "primereact/message";

export default function RootSideMenuProduct() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const countries = [
    { name: "Voucher", icon: "pi pi-qrcode mr-3" },
    { name: "Printing", icon: "pi pi-print mr-3" },
    { name: "Data", icon: "pi pi-calendar mr-3" },
    { name: "PPPoE", icon: "pi pi-home mr-3" },
    { name: "Saldo", icon: "pi pi-wallet mr-3" },
    { name: "Reseller", icon: "pi pi-share-alt mr-3" },
    { name: "Promo", icon: "pi pi-ticket mr-3" },
    { name: "Insentif", icon: "pi pi-gift mr-3" },
    { name: "PLN Refund", icon: "pi pi-bolt mr-3" },
    { name: "Refund", icon: "pi pi-replay mr-3" },
  ];

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
      </div>
    );
  };

  return (
    <div>
      <Message
        severity="info"
        className="w-full mb-2 justify-content-start px-4"
        content={
          <div className="ml-2 ">
            Product: <b>PPPoE</b>
          </div>
        }
      />
      <ListBox
        value={selectedCountry}
        onChange={(e) => {
          setSelectedCountry(e.value);
          alert("halo " + e.value.name);
        }}
        options={countries}
        optionLabel="name"
        itemTemplate={countryTemplate}
        className="w-full md:w-14rem"
        listStyle={{ maxHeight: "400px" }}
      />
    </div>
  );
}
