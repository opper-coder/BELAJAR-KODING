import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { Button } from "primereact/button";

export default function PricePacket() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  return (
    <div>
      <div className="flex gap-2 mb-2">
        <Button
          label="Add"
          icon="pi pi-plus"
          onClick={() => alert("halo tambahkan data")}
          outlined
          className="flex-1"
        />
        <Button
          icon="pi pi-pencil "
          outlined
          aria-label="Filter"
          onClick={() => alert("halo tambahkan data")}
        />
      </div>
      <div className="card">
        <DataTable
          value={products}
          tableStyle={{ minWidth: "30rem" }}
          size="small"
          resizableColumns
          paginator
          rows={10}
        >
          <Column field="code" header="Paket"></Column>
          <Column field="name" header="Harga"></Column>
          <Column field="category" header="Tugas"></Column>
          <Column field="quantity" header="Durasi"></Column>
        </DataTable>
      </div>
    </div>
  );
}
