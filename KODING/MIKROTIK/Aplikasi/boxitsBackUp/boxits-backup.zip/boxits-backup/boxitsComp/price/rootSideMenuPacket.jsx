// import ServersP from "./paket/ServersP";
// import Servers from "./paket/Servers";
// import PricePacket from "./pricePacket";
// import PricePacketPenyesuaian from "./pricePacketPenyesuaian";
// import Server from "./paket/Servers";

import { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Message } from "primereact/message";
import Packet from "./paket/Packet";
import PacketP from "./paket/PacketP";

export default function RootSideMenuPacket() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [menuPaket, setMenuPaket] = useState("Servers");

  const countries = [
    { name: "Servers", icon: "pi pi-server mr-3" },
    { name: "Mapping", icon: "pi pi-map-marker mr-3" },
    { name: "Maintenance", icon: "pi pi-wrench mr-3" },
    { name: "Other", icon: "pi pi-box mr-3" },
  ];

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
      </div>
    );
  };

  return (
    <>
      <div>
        <Message
          severity="info"
          className="w-full mb-2 justify-content-start px-4"
          content={
            <div className="ml-2 ">
              Packet: <b>{menuPaket}</b>
            </div>
          }
        />
        <ListBox
          value={selectedCountry}
          onChange={(e) => {
            setSelectedCountry(e.value);
            setMenuPaket(e.value.name);
            // alert("halo" + e.value.name);
          }}
          options={countries}
          optionLabel="name"
          itemTemplate={countryTemplate}
          className="w-full md:w-14rem"
          listStyle={{ maxHeight: "400px" }}
        />
      </div>
      <Packet name={menuPaket} />
      <PacketP name={menuPaket} />
    </>
  );
}
