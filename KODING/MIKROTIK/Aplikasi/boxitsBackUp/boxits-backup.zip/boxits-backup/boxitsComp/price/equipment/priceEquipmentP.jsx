import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { Message } from "primereact/message";

export default function PriceEquipmentP(equipmentP) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    switch (equipmentP.name) {
      case "OLT":
        // ganti dengan query yang sesuai
        ProductService.getProductsMini().then((data) => setProducts(data));
        break;
      case "HTB PtP":
        ProductService.getProductsSmall().then((data) => setProducts(data));
        break;
      case "5ghz":
        ProductService.getProductsSmall().then((data) => setProducts(data));
        break;
      case "Combi":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Region":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Office":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Operational":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Mikrotik":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OpenWRT":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Ubiquity":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OLT":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "SFP":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "HTB":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Switch":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "S Manageable":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Router":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Wire FO":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Wire UTP":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Wire Electric":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Stop Contact":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Plug Electric":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "ONT":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Router":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "ESP8266":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "ESP32":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "PTP 2.4 Ghz":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "PTP 5 Ghz":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Fast Conn":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Alcohol":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Protector":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Pigtail":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Cleaver":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Splicer":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OPM":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OTDR":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OLS(OpticalLightsource)":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "VFL(VisualFaultLocator)":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Tool Kit":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Tangga":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "HT":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Savety Belt":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "HeadLamp":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      default:
        ProductService.getProductsMini().then((data) => setProducts(data));
        break;
    }
  }, [equipmentP.name]);

  useEffect(() => {
    ProductService.getProductsMini().then((data) => setProducts(data));
  }, []);

  const statusBodyTemplate2 = (product) => {
    if (product.quantity < 40 && product.rating == 3) {
      // jika harga product > dari standard  dan verify OK
      return <i className="pi pi-caret-up text-blue-500"></i>;
    } else if (product.quantity < 40 && product.rating > 3) {
      // jika harga product < dari standard  dan verify OK
      return <i className="pi pi-caret-down text-green-500"></i>;
    } else {
      // jika verify false
      return <i className="pi pi-info-circle text-red-500"></i>;
    }
  };
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Verify",
      icon: "pi pi-fw pi-thumbs-up",
      command: () => viewProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    alert(product.name);
  };
  return (
    <>
      <div className="flex-1">
        <Message
          severity="info"
          className="w-full mb-2 justify-content-start px-4"
          content={
            <div className="ml-2 ">
              Penyesuaian Root <b>{equipmentP.name}</b>
            </div>
          }
        />
        <div className="card mr-2 w-full">
          <Toast ref={toast} />
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />
          <DataTable
            value={products}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
            tableStyle={{ minWidth: "30rem" }}
            size="small"
            resizableColumns
            paginator
            rows={10}
          >
            <Column field="name" header="Unit"></Column>
            <Column
              field="quantity"
              header="Status"
              body={statusBodyTemplate2}
            ></Column>
            <Column field="quantity" header="Selisih"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
