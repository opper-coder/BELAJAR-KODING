import { useState, useEffect, use } from "react";
import { ProductService } from "./service/ProductService";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";

export default function PriceProduct(product) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    switch (product.name) {
      case "Voucher":
        // ganti dengan query yang sesuai
        ProductService.getProductsMini().then((data) => setProducts(data));
        break;
      case "Printing":
        ProductService.getProductsSmall().then((data) => setProducts(data));
        break;
      case "Data":
        ProductService.getProductsSmall().then((data) => setProducts(data));
        break;
      case "PPPoE":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Saldo":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Reseller":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Insentif":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "PLN Refund":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Refund":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      default:
        ProductService.getProductsMini().then((data) => setProducts(data));
        break;
    }
  }, [product.name]);

  // useEffect(() => {
  //   ProductService.getProducts().then((data) => setProducts(data));
  // }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <>
      <div>
        <div className="flex gap-2 mb-2">
          <Button
            label="Add"
            icon="pi pi-plus"
            onClick={() => alert("halo tambah Packet")}
            outlined
            className="flex-1"
          />
          <Button
            icon="pi pi-pencil "
            aria-label="Filter"
            outlined
            onClick={() => alert("halo tambahkan data")}
          />
        </div>
        <div className="card">
          <DataTable
            value={products}
            tableStyle={{ minWidth: "30rem" }}
            size="small"
            resizableColumns
            paginator
            rows={10}
          >
            <Column field="code" header="#"></Column>
            <Column field="code" header="Product"></Column>
            <Column field="code" header="Harga"></Column>
            <Column field="name" header="Quota"></Column>
            <Column field="quantity" header="Durasi"></Column>
            <Column field="category" header="Bandwidth"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
