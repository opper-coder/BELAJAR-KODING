import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { Button } from "primereact/button";

export default function PriceEquipment(equipment) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    switch (equipment.name) {
      case "OLT":
        // ganti dengan query yang sesuai
        ProductService.getProductsMini().then((data) => setProducts(data));
        break;
      case "HTB PtP":
        ProductService.getProductsSmall().then((data) => setProducts(data));
        break;
      case "5ghz":
        ProductService.getProductsSmall().then((data) => setProducts(data));
        break;
      case "Combi":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Region":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Office":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Operational":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Mikrotik":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OpenWRT":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Ubiquity":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OLT":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "SFP":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "HTB":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Switch":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "S Manageable":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Router":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Wire FO":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Wire UTP":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Wire Electric":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Stop Contact":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Plug Electric":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "ONT":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Router":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "ESP8266":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "ESP32":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "PTP 2.4 Ghz":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "PTP 5 Ghz":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Fast Conn":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Alcohol":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Protector":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Pigtail":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Cleaver":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Splicer":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OPM":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OTDR":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "OLS(OpticalLightsource)":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "VFL(VisualFaultLocator)":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Tool Kit":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Tangga":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "HT":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Savety Belt":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "HeadLamp":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      default:
        ProductService.getProductsMini().then((data) => setProducts(data));
        break;
    }
  }, [equipment.name]);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  return (
    <>
      <div>
        <div className="flex gap-2">
          <div className="w-full flex gap-2 mb-2">
            <Button
              label="Add"
              icon="pi pi-plus"
              onClick={() => alert("halo tambahkan data")}
              outlined
              className="flex-1"
            />
            <Button
              icon="pi pi-pencil "
              outlined
              aria-label="Filter"
              onClick={() => alert("halo tambahkan data")}
            />
          </div>
        </div>
        <div className="card">
          <DataTable
            value={products}
            tableStyle={{ minWidth: "30rem" }}
            size="small"
            resizableColumns
            rows={10}
            paginator
          >
            <Column field="code" header="Paket"></Column>
            <Column field="name" header="Harga"></Column>
            <Column field="category" header="Tugas"></Column>
            <Column field="quantity" header="Durasi"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
