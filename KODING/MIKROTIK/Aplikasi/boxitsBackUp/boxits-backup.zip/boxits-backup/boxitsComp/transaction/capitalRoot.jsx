import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { Button } from "primereact/button";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";

export default function CapitalRoot() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Edit",
      icon: "pi pi-fw pi-pencil",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-times",
      command: () => deleteProduct(selectedProduct),
    },
  ];

  const viewProduct = (product) => {
    alert("hallo" + product.name);
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };

  const formatCurrency = (value) => {
    return value.toLocaleString("en-US", {
      style: "currency",
      currency: "USD",
    });
  };

  const priceBodyTemplate = (rowData) => {
    return formatCurrency(rowData.price);
  };

  return (
    <>
      <div>
        <div className="mt-2x">
          <div className="flex gap-2 mb-2">
            <Button
              label="Add Capital"
              icon="pi pi-plus"
              onClick={() => alert("halo tambahkan data")}
              outlined
              className="flex-1"
            />
            {/* <Button
              icon="pi pi-pencil "
              outlined
              aria-label="Filter"
              onClick={() => alert("halo tambahkan data")}
            /> */}
          </div>
          <Toast ref={toast} />
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />

          <DataTable
            value={products}
            tableStyle={{ minWidth: "12rem" }}
            size="small"
            resizableColumns
            paginator
            rows={8}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
          >
            <Column field="id" header="#" sortable></Column>
            <Column field="name" header="Capital"></Column>
            <Column field="tanggal" header="Tanggal" sortable></Column>
            <Column field="nilai" header="Nilai"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}

//     return (
//         <div className="card">

//             <DataTable value={products} onContextMenu={(e) => cm.current.show(e.originalEvent)} contextMenuSelection={selectedProduct} onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)} tableStyle={{ minWidth: '50rem' }}>
//                 <Column field="code" header="Code"></Column>
//                 <Column field="name" header="Name"></Column>
//                 <Column field="category" header="Category"></Column>
//                 <Column field="price" header="Price" body={priceBodyTemplate} />
//             </DataTable>
//         </div>
//     );
// }
