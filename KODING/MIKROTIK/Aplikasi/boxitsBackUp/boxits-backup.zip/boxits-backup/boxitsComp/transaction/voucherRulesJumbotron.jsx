import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import { Calendar } from "primereact/calendar";
import { Button } from "primereact/button";
import { useState } from "react";
import { Checkbox } from "primereact/checkbox";
import TanggalLive from "../tanggalLive";

export default function VoucherRulesJumbotron() {
  const [date, setDate] = useState(null);
  const [checked, setChecked] = useState(false);
  const items = [
    // {
    //   label: "Add Work Location",
    //   icon: "pi pi-fw pi-plus",
    //   command: () => alert("Tambah Lokasi"),
    // },
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const start = (
    <div className="flex justify-content-center align-items-center gap-2 ml-3">
      <Checkbox
        onChange={(e) => setChecked(e.checked)}
        checked={checked}
      ></Checkbox>
      <label>Auto permission</label>
    </div>
  );
  const end = (
    <div className="flex align-items-center gap-2">
      <TanggalLive />
      <Calendar
        value={date}
        onChange={(e) => setDate(e.value)}
        view="month"
        dateFormat="mm/yy"
        showIcon
      />
      <Button label="Go" text />
    </div>
  );

  return (
    <>
      <Card
        title="Main Voucher"
        subTitle="Main Capital, Main Price Product, Main Price Packet"
        className="mb-4 surface-300 "
      >
        <div className="flex">
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>For Root Admin</li>
              <li>Generate Main Capital</li>
              <li>Generate Main Price Product</li>
              <li>Generate Main Price Packet</li>
            </ul>
          </div>
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>Transfer Capital</li>
              <li>Response Capital</li>
              <li>View All Transfer Type</li>
              <li>Connected with report</li>
            </ul>
          </div>
        </div>
      </Card>
      <Menubar model={items} start={start} className="mb-4" end={end} />
    </>
  );
}
