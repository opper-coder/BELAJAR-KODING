import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { Button } from "primereact/button";

export default function TransferRoot() {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Edit",
      icon: "pi pi-fw pi-pencil",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Banned",
      icon: "pi pi-fw pi-ban",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Verify",
      icon: "pi pi-fw pi-thumbs-up",
      command: () => viewProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };
  const statusBodyTemplate2 = (product) => {
    if (product.quantity < 40 && product.rating > 2) {
      // jika verifikasi TRUE
      return <i className="pi pi-check text-blue-500"></i>;
    } else {
      // jika verify else (FALSE)
      return <i className="pi pi-info-circle text-red-500"></i>;
    }
  };
  return (
    <>
      <div className="flex gap-2 mb-2">
        <Button
          label="Add Transfer Capital"
          icon="pi pi-plus"
          onClick={() => alert("halo tambahkan data")}
          outlined
          className="flex-1"
        />
        {/* <Button
          icon="pi pi-pencil "
          outlined
          aria-label="Filter"
          onClick={() => alert("halo tambahkan data")}
        /> */}
      </div>
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={products}
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        tableStyle={{ minWidth: "50rem" }}
        size="small"
        resizableColumns
        paginator
        rows={7}
      >
        <Column field="name" header="Name"></Column>
        <Column
          field="quantity"
          header="Status"
          body={statusBodyTemplate2}
          sortable
        ></Column>
        <Column field="quantity" header="Jumlah"></Column>
        <Column field="code" header="Tanggal" sortable></Column>
        <Column field="description" header="Tujuan" sortable></Column>
      </DataTable>
    </>
  );
}
