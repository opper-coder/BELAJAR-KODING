import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { Button } from "primereact/button";

export default function Promo(props) {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);

  useEffect(() => {
    switch (props.name) {
      case "Bulan":
        ProductService.getProductsMini().then((data) => setProducts(data));
        break;
      case "Pekan":
        ProductService.getProductsSmall().then((data) => setProducts(data));
        break;
      case "Hari":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      default:
        ProductService.getProducts().then((data) => setProducts(data));
        break;
    }
  }, [props.name]); // eslint-disable-line react-hooks/exhaustive-deps

  // useEffect(() => {
  //   ProductService.getProductsMini().then((data) => setProducts(data));
  // }, []);

  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Freeze",
      icon: "pi pi-fw pi-times-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Activation",
      icon: "pi pi-fw pi-sun",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Banned",
      icon: "pi pi-fw pi-times",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Reset",
      icon: "pi pi-fw pi-history",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Refund",
      icon: "pi pi-fw pi-undo",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "PLN Refund",
      icon: "pi pi-fw pi-bolt",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => deleteProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };

  // templat table -----
  const statusBodyTemplate = (product) => {
    return (
      // <Tag
      //   value={product.inventoryStatus}
      //   severity={getSeverity(product)}
      // ></Tag>
      <i className={getSeverity(product)}></i>
    );
  };

  const getSeverity = (product) => {
    switch (product.inventoryStatus) {
      /*
      
      isi nya bakal seperti ini tinggal sesuaikan database input nya

      case "Properties" :
      return "pi pi-fw pi-info-circle";
      break
      case "Freeze" :
      return "pi pi-fw pi-times-circle";
      break
      case "Activation" :
      return "pi pi-fw pi-sun";
      break
      case "Banned" :
      return "pi pi-fw pi-times";
      break
      case "Reset" :
      return "pi pi-fw pi-history";
      break
      case "Refund" :
      return "pi pi-fw pi-undo";
      break
      case "PLN Refund" :
      return "pi pi-fw pi-bolt";
      break
      case "Delete" :
      return "pi pi-fw pi-trash";
      break
      */

      case "INSTOCK":
        return "pi pi-check text-green-600";

      case "LOWSTOCK":
        return "pi pi-times-circle text-red-600";

      case "OUTOFSTOCK":
        return "pi pi-sun text-blue-600";

      default:
        return null;
    }
  };

  return (
    <>
      <div className="w-full">
        <Button
          label={"Add " + props.name}
          icon="pi pi-plus"
          onClick={() => alert("halo tambahkan data")}
          className="w-full mb-2"
          outlined
          size="small"
        />
        <Toast ref={toast} />
        <ContextMenu
          model={menuModel}
          ref={cm}
          onHide={() => setSelectedProduct(null)}
        />
        <DataTable
          value={products}
          onContextMenu={(e) => cm.current.show(e.originalEvent)}
          contextMenuSelection={selectedProduct}
          onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
          tableStyle={{ minWidth: "30rem" }}
          size="small"
          resizableColumns
          paginator
          rows={10}
          className="card"
        >
          <Column field="id" header="#"></Column>
          <Column field="name" header="Name"></Column>
          <Column
            field="category"
            header="Status"
            body={statusBodyTemplate}
          ></Column>
          <Column field="quantity" header="Jumlah"></Column>
          <Column field="code" header="Tanggal"></Column>
          <Column field="description" header="Tujuan"></Column>
          <Column field="category" header="Type"></Column>
        </DataTable>
      </div>
    </>
  );
}
