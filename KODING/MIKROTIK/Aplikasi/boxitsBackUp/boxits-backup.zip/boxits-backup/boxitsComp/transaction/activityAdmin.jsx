import { TabView, TabPanel } from "primereact/tabview";
import Request from "./request";
import SidebarAdminProduct from "./SidebarAdminProduct";
import SidebarAdminPacket from "./SidebarAdminPacket";
import SidebarAdminInsentif from "./SidebarAdminInsentif";
import SidebarAdminPromo from "./SidebarAdminPromo";
import SidebarAdminIklan from "./SidebarAdminIklan";
import TransactionAdmin from "./transactionAdmin";

export default function ActivityAdmin() {
  const tab1 = (options) => {
    return (
      <div
        className={options.className}
        style={{ cursor: "pointer", marginTop: -1 }}
        onClick={options.onClick}
      >
        <i className="pi pi-file-import mr-2" />
        <span>Request</span>
        <p
          style={{
            marginLeft: "10px",
            borderRadius: "10px",
            textAlign: "center",
            backgroundColor: "#ff4343",
            color: "white",
            fontSize: "10px",
            display: "inline-block",
            minWidth: "20px",
          }}
        >
          45
        </p>
      </div>
    );
  };

  return (
    <>
      <div className="card mt-2">
        <TabView>
          <TabPanel header="Capital">
            <TransactionAdmin />
          </TabPanel>
          <TabPanel headerTemplate={tab1}>
            <Request />
          </TabPanel>
          <TabPanel header="Product">
            <SidebarAdminProduct />
          </TabPanel>
          <TabPanel header="Packet">
            <SidebarAdminPacket />
          </TabPanel>
          <TabPanel header="Insentif">
            <SidebarAdminInsentif />
          </TabPanel>
          <TabPanel header="Promo">
            <SidebarAdminPromo />
          </TabPanel>
          <TabPanel header="Iklan">
            <SidebarAdminIklan />
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
