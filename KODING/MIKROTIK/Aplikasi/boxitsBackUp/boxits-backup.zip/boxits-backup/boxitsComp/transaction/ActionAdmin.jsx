import { TabView, TabPanel } from "primereact/tabview";
import AdminTree from "../users/adminTree";
import SidebarAdminProduct from "./SidebarAdminProduct";

import TableActionProductA from "../voucher/TableActionProductA";
import TableActionPacketA from "../voucher/TableActionPacketA";
import TableActionPromoA from "../voucher/TableActionPromoA";
import TableActionInsentifA from "../voucher/TableActionInsentifA";
import TableActionIklanA from "../voucher/TableActionIklanA";

import SidebarAdminInsentif from "../voucher/SidebarAdminInsentif";
import SidebarAdminPacket from "../voucher/SidebarAdminPacket";
import SidebarAdminPromo from "../voucher/SidebarAdminPromo";
import SidebarAdminIklan from "../voucher/SidebarAdminIklan";

export default function ActionAdmin() {
  return (
    <>
      <section>
        <article>
          <TabView>
            <TabPanel header="Product">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminProduct />
                <TableActionProductA />
              </div>
            </TabPanel>
            <TabPanel header="Packet">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminPacket />
                <TableActionPacketA />
              </div>
            </TabPanel>
            <TabPanel header="Insentif">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminInsentif />
                <TableActionInsentifA />
              </div>
            </TabPanel>
            <TabPanel header="Promo">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminPromo />
                <TableActionPromoA />
              </div>
            </TabPanel>
            <TabPanel header="Iklan">
              <div className="flex gap-2 -ml-4">
                <AdminTree />
                <SidebarAdminIklan />
                <TableActionIklanA />
              </div>
            </TabPanel>
          </TabView>
        </article>
      </section>
    </>
  );
}
