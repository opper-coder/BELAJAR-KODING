import React, { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Badge } from "primereact/badge";
import { Message } from "primereact/message";
import Iklan from "./iklan";

export default function SidebarAdminIklan() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [iklan, setIklan] = useState(null);
  const countries = [
    { name: "Umum", icon: "pi pi-star mr-3", notif: "30" },
    { name: "Region", icon: "pi pi-star mr-3", notif: "10" },
    { name: "Branch", icon: "pi pi-star mr-3", notif: "12" },
    { name: "Unit", icon: "pi pi-star mr-3", notif: "1" },
    { name: "Seller", icon: "pi pi-star mr-3", notif: "1" },
    { name: "User", icon: "pi pi-star mr-3", notif: "1" },
  ];

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
        <Badge
          value={option.notif}
          className="ml-auto"
          severity="success"
        ></Badge>
      </div>
    );
  };

  return (
    <div className="flex gap-2">
      <div>
        <Message
          className=" w-full mb-2 justify-content-start"
          severity="info"
          content={
            <span>
              Iklan: <b>{iklan}</b>
            </span>
          }
        />
        <ListBox
          value={selectedCountry}
          onChange={(e) => {
            setSelectedCountry(e.value);
            setIklan(e.value.name);
            // alert("halo " + e.value.name);
          }}
          options={countries}
          optionLabel="name"
          itemTemplate={countryTemplate}
          className="w-full md:w-14rem"
          listStyle={{ maxHeight: "400px" }}
        />
      </div>
      <Iklan name={iklan} />
    </div>
  );
}
