import { TabView, TabPanel } from "primereact/tabview";
import CapitalSA from "./capitalSA";
import TransferSA from "./transferSA";
import RequestSA from "./requestSA";

export default function Activity() {
  const tab1 = (options) => {
    return (
      <div
        className={options.className}
        style={{ cursor: "pointer" }}
        onClick={options.onClick}
      >
        <i className="pi pi-file-import mr-2" />
        <span>Request</span>
        <p
          style={{
            marginLeft: "10px",
            padding: "-1px",
            borderRadius: "10px",
            textAlign: "center",
            backgroundColor: "#ff4343",
            color: "white",
            fontSize: "10px",
            display: "inline-block",
            minWidth: "20px",
          }}
        >
          45
        </p>
      </div>
    );
  };

  return (
    <>
      <div>
        <TabView>
          <TabPanel header="Capital">
            <CapitalSA />
          </TabPanel>
          <TabPanel header="Transfer">
            <TransferSA />
          </TabPanel>
          <TabPanel headerTemplate={tab1}>
            <RequestSA />
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
