import { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { Button } from "primereact/button";

export default function Transfer(transferProduct) {
  const [products, setProducts] = useState(["Voucher"]);
  useEffect(() => {
    switch (transferProduct.name) {
      case "Voucher":
        ProductService.getProductsMini().then((data) => setProducts(data));
        break;
      case "Printing":
        ProductService.getProductsSmall().then((data) => setProducts(data));
        break;
      case "Data":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "PPPoE":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Saldo":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Reseller":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Promo":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Insentif":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "PLN Refund":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      case "Refund":
        ProductService.getProducts().then((data) => setProducts(data));
        break;
      default:
        break;
    }
  }, [transferProduct.name]);

  return (
    <>
      <div className="w-full">
        <Button
          label="Transfer"
          icon="pi pi-plus"
          onClick={() => alert("halo tambahkan data")}
          className="w-full mb-2"
          outlined
          size="small"
        />

        <DataTable
          value={products}
          size="small"
          resizableColumns
          paginator
          rows={10}
          className="card"
        >
          <Column field="id" header="#"></Column>
          <Column field="name" header="Name"></Column>
          <Column field="quantity" header="Jumlah"></Column>
          <Column field="code" header="Tanggal"></Column>
          <Column field="tujuan" header="Tujuan"></Column>
        </DataTable>
      </div>
    </>
  );
}
