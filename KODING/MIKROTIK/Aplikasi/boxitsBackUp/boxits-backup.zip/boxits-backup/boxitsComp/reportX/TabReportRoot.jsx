import { TabView, TabPanel } from "primereact/tabview";
import ModalRoot from "./ModalRoot";
import ModalAdmin from "./modalAdmin";
import ModalReseller from "./ModalReseller";
import ModalEndUser from "./ModalEndUser";
import Neraca from "./Neraca";

export default function TabReportRoot() {
  return (
    <>
      <TabView>
        <TabPanel header="Neraca">
          <Neraca />
        </TabPanel>
        <TabPanel header="Root">
          <ModalRoot />
        </TabPanel>
        <TabPanel header="Admin">
          <ModalAdmin />
        </TabPanel>
        <TabPanel header="Reseller">
          <ModalReseller />
        </TabPanel>
        <TabPanel header="EndUser">
          <ModalEndUser />
        </TabPanel>
        <TabPanel header="Investor">
          {/* <ModalEndUser /> */}
          <li>list investor</li>
          <li>pembagian dengan investor</li>
          <li>Hasil bersih kita</li>
        </TabPanel>
      </TabView>
    </>
  );
}
