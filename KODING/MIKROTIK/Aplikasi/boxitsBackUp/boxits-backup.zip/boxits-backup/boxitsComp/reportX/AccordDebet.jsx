import { Accordion, AccordionTab } from "primereact/accordion";
import { useState } from "react";
import SaldoReseller from "./SaldoReseller";

export default function AccordDebet() {
  const [reseller, setReseller] = useState(100000000);
  const [pasang, setPasang] = useState(10000000);
  const [iklan, setIklan] = useState(1000000);
  const [root, setRoot] = useState(10000000000);
  const [SA, setSA] = useState(1000000);

  const tab1HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Saldo Reseller</span>
          <span className="text-teal-500">{reseller}</span>
        </div>
      </>
    );
  };
  const tab2HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Pasang Baru</span>
          <span className="text-teal-500">{pasang}</span>
        </div>
      </>
    );
  };
  const tab3HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Iklan</span>
          <span className="text-teal-500">{iklan}</span>
        </div>
      </>
    );
  };
  const tab4HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Saldo Root</span>
          <span className="text-teal-500">{root}</span>
        </div>
      </>
    );
  };
  const tab5HeaderTemplate = (options) => {
    return (
      <>
        <div className="flex justify-content-between w-full">
          <span>Saldo Super Admin</span>
          <span className="text-teal-500">{SA}</span>
        </div>
      </>
    );
  };

  return (
    <Accordion activeIndex={0}>
      <AccordionTab header="Saldo Reseller" headerTemplate={tab4HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
      <AccordionTab header="Saldo Reseller" headerTemplate={tab5HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
      <AccordionTab header="Saldo Reseller" headerTemplate={tab1HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
      <AccordionTab header="Pasang Baru" headerTemplate={tab2HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
      <AccordionTab header="Iklan" headerTemplate={tab3HeaderTemplate}>
        <SaldoReseller />
      </AccordionTab>
    </Accordion>
  );
}
