import NavRoot from "../voucher/navRoot";
import SoldProduct from "./KreditAdmin";
import { TabView, TabPanel } from "primereact/tabview";
import { Message } from "primereact/message";

export default function Contain() {
  return (
    <>
      <div>
        <NavRoot />
        <TabView>
          <TabPanel header="Voucher">
            <Message
              className="mb-2 w-full"
              severity="success"
              content={
                <p>
                  Total penjualan<b> Voucher: Rp. 20.900.000</b>
                </p>
              }
            />
            <SoldProduct />
          </TabPanel>
          <TabPanel header="Data">
            <Message
              className="mb-2 w-full"
              severity="success"
              content={
                <p>
                  Total penjualan<b> Voucher: Rp. 22.900.000</b>
                </p>
              }
            />
            <SoldProduct />
          </TabPanel>
          <TabPanel header="PPPoE">
            <Message
              className="mb-2 w-full"
              severity="success"
              content={
                <p>
                  Total penjualan<b> Voucher: Rp. 20.900.000</b>
                </p>
              }
            />
            <SoldProduct />
          </TabPanel>
          <TabPanel header="Printing">
            <Message
              className="mb-2 w-full"
              severity="success"
              content={
                <p>
                  Total penjualan<b> Voucher: Rp. 20.900.000</b>
                </p>
              }
            />
            <SoldProduct />
          </TabPanel>
          <TabPanel header="Saldo">
            <Message
              className="mb-2 w-full"
              severity="success"
              content={
                <p>
                  Total penjualan<b> Voucher: Rp. 20.900.000</b>
                </p>
              }
            />
            <SoldProduct />
          </TabPanel>
          <TabPanel header="Reseller">
            <Message
              className="mb-2 w-full"
              severity="success"
              content={
                <p>
                  Total penjualan<b> Voucher: Rp. 20.900.000</b>
                </p>
              }
            />
            <SoldProduct />
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
