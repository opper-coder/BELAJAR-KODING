import React, { useState, useEffect } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";

export default function DebetRoot() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  return (
    <div className="">
      <DataTable
        value={products}
        tableStyle={{ minWidth: "30rem" }}
        paginator
        rows={6}
      >
        <Column field="name" header="Name"></Column>
        <Column field="code" header="Jumlah"></Column>
        <Column field="code" header="Tanggal"></Column>
      </DataTable>
    </div>
  );
}
