import { Calendar } from "primereact/calendar";
import { useState } from "react";
import { Message } from "primereact/message";
import NavigasiRoot from "../NavigasiRoot";
import DebetEndUser from "./DebetEndUser";
import KreditEndUser from "./KreditEndUser";

export default function ModalEndUser() {
  const [date, setDate] = useState(null);
  return (
    <>
      <div className="flex justify-content-between align-items-center">
        <Calendar
          value={date}
          onChange={(e) => setDate(e.value)}
          view="month"
          showIcon
        />
        <span>
          Saldo: <b>10.000.000</b>
        </span>
      </div>
      <div className="flex mt-2">
        <div className="flex gap-2 w-full">
          <NavigasiRoot />
          <div>
            <Message
              className="w-full mb-2"
              severity="success"
              content={
                <div className="w-full flex justify-content-between">
                  <span>Debet EndUser</span>
                  <b>Rp. 200.000.000</b>
                </div>
              }
            />
            <div className="card ">
              <DebetEndUser />
            </div>
          </div>
          <div className="flex-1">
            <Message
              className="w-full mb-2"
              severity="warn"
              content={
                <div className="w-full flex justify-content-between">
                  <span>Kredit EndUser</span>
                  <b>Rp. 200.000.000</b>
                </div>
              }
            />
            <div className="card">
              <KreditEndUser />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
