import { TabView, TabPanel } from "primereact/tabview";
import MenuInventory from "./menuInventory";
import AdminTree from "../users/adminTree";

export default function OwnerMenu() {
  return (
    <div>
      <TabView>
        <TabPanel header="RootMode" className="p-0">
          <div className="flex gap-2">
            <AdminTree />
            <MenuInventory />
          </div>
        </TabPanel>
        <TabPanel header="OwnerMode">
          <div className="flex gap-2">
            <AdminTree />
            <MenuInventory />
          </div>
        </TabPanel>
      </TabView>
    </div>
  );
}
