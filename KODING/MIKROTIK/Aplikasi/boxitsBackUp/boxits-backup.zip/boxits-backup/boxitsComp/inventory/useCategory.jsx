import React from "react";
import { TabView, TabPanel } from "primereact/tabview";
import EquipmentTable from "./equipmentTable";

export default function UseCategory() {
  return (
    <div className="card w-full">
      <TabView>
        <TabPanel header="PROPERTIES">{/* <EquipmentProperties /> */}</TabPanel>
        <TabPanel header="All">
          <EquipmentTable />
        </TabPanel>
        <TabPanel header="New">
          <EquipmentTable />
        </TabPanel>
        <TabPanel header="Running">
          <EquipmentTable />
        </TabPanel>
        <TabPanel header="Repair">
          <EquipmentTable />
        </TabPanel>
        <TabPanel header="Broken">
          <EquipmentTable />
        </TabPanel>
        <TabPanel header="Expired">
          <EquipmentTable />
        </TabPanel>
        <TabPanel header="Replacement">
          <EquipmentTable />
        </TabPanel>
        <TabPanel header="Finish">
          <EquipmentTable />
        </TabPanel>
      </TabView>
    </div>
  );
}
