import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ContextMenu } from "primereact/contextmenu";
import { ProductService } from "./service/ProductService";
import { Message } from "primereact/message";

export default function ExplorerInvestor2() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Edit",
      icon: "pi pi-fw pi-pencil",
      command: () => editProduct(selectedProduct),
    },
    {
      label: "Assign",
      icon: "pi pi-fw pi-link",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-times",
      command: () => deleteProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    alert(product.name);
  };

  const editProduct = (product) => {
    alert(product.name);
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    alert(product.name);
    setProducts(_products);
  };

  return (
    <>
      <div className="flex-1">
        <Message
          severity="info"
          className="w-full justify-content-start px-4 mb-2"
          content={
            <div className="w-full flex justify-content-between">
              <div>Investor Pending </div>
            </div>
          }
        />
        <div className="card flex-1">
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />
          <DataTable
            value={products}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
            size="small"
            paginator
            rows={6}
            sortMode="multiple"
          >
            <Column field="code" sortable header="#"></Column>
            <Column field="name" sortable header="Nama"></Column>
            <Column field="category" sortable header="Tanggal"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
