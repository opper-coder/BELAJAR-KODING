// import React, { useState, useEffect, useRef } from "react";
// import { FilterMatchMode, FilterOperator } from "primereact/api";
// import { DataTable } from "primereact/datatable";
// import { Column } from "primereact/column";
// import { InputText } from "primereact/inputtext";
// import { MultiSelect } from "primereact/multiselect";
// import { Dropdown } from "primereact/dropdown";
// import { Tag } from "primereact/tag";
// import { CustomerService } from "./service/CustomerService.jsx";
// import { Image } from "primereact/image";
// import { ContextMenu } from "primereact/contextmenu";
// import { Toast } from "primereact/toast";
// import { ProductService } from "./service/ProductService";

// export default function ExplorerInvestor() {
//   const [customers, setCustomers] = useState(null);
//   const [filters, setFilters] = useState({
//     global: { value: null, matchMode: FilterMatchMode.CONTAINS },
//     name: {
//       operator: FilterOperator.AND,
//       constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
//     },
//     "country.name": {
//       operator: FilterOperator.AND,
//       constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
//     },
//     representative: { value: null, matchMode: FilterMatchMode.IN },
//     status: {
//       operator: FilterOperator.OR,
//       constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
//     },
//   });

//   const [selectedCustomer, setSelectedCustomer] = useState(null);
//   const representatives = [
//     { name: "Amy Elsner", image: "amyelsner.png" },
//     { name: "Anna Fali", image: "annafali.png" },
//     { name: "Asiya Javayant", image: "asiyajavayant.png" },
//     { name: "Bernardo Dominic", image: "bernardodominic.png" },
//     { name: "Elwin Sharvill", image: "elwinsharvill.png" },
//     { name: "Ioni Bowcher", image: "ionibowcher.png" },
//     { name: "Ivan Magalhaes", image: "ivanmagalhaes.png" },
//     { name: "Onyama Limba", image: "onyamalimba.png" },
//     { name: "Stephen Shaw", image: "stephenshaw.png" },
//     { name: "XuXue Feng", image: "xuxuefeng.png" },
//   ];
//   const statuses = [
//     "unqualified",
//     "qualified",
//     "new",
//     "negotiation",
//     "renewal",
//   ];

//   const getSeverity = (status) => {
//     switch (status) {
//       case "unqualified":
//         return "danger";

//       case "qualified":
//         return "success";

//       case "new":
//         return "info";

//       case "negotiation":
//         return "warning";

//       case "renewal":
//         return null;
//     }
//   };

//   useEffect(() => {
//     CustomerService.getCustomersSmall().then((data) => setCustomers(data));
//   }, []);

//   const representativeBodyTemplate = (rowData) => {
//     const representative = rowData.representative;

//     return (
//       <div className="flex align-items-center gap-2">
//         <Image
//           alt={representative.name}
//           src={`https://primefaces.org/cdn/primereact/images/avatar/${representative.image}`}
//           width="32"
//         />
//         <span>{representative.name}</span>
//       </div>
//     );
//   };

//   const representativeFilterTemplate = (options) => {
//     return (
//       <MultiSelect
//         value={options.value}
//         options={representatives}
//         itemTemplate={representativesItemTemplate}
//         onChange={(e) => options.filterCallback(e.value)}
//         optionLabel="name"
//         placeholder="Any"
//         className="p-column-filter"
//       />
//     );
//   };

//   const representativesItemTemplate = (option) => {
//     return (
//       <div className="flex align-items-center gap-2">
//         <Image
//           alt={option.name}
//           src={`https://primefaces.org/cdn/primereact/images/avatar/${option.image}`}
//           width="32"
//         />
//         <span>{option.name}</span>
//       </div>
//     );
//   };

//   const statusBodyTemplate = (rowData) => {
//     return (
//       <Tag value={rowData.status} severity={getSeverity(rowData.status)} />
//     );
//   };

//   const statusFilterTemplate = (options) => {
//     return (
//       <Dropdown
//         value={options.value}
//         options={statuses}
//         onChange={(e) => options.filterCallback(e.value, options.index)}
//         itemTemplate={statusItemTemplate}
//         placeholder="Select One"
//         className="p-column-filter"
//         showClear
//       />
//     );
//   };

//   const statusItemTemplate = (option) => {
//     return <Tag value={option} severity={getSeverity(option)} />;
//   };

//   const onGlobalFilterChange = (event) => {
//     const value = event.target.value;
//     let _filters = { ...filters };

//     _filters["global"].value = value;

//     setFilters(_filters);
//   };

//   const renderHeader = () => {
//     const value = filters["global"] ? filters["global"].value : "";

//     return (
//       <span className="p-input-icon-left">
//         <i className="pi pi-search" />
//         <InputText
//           type="search"
//           value={value || ""}
//           onChange={(e) => onGlobalFilterChange(e)}
//           placeholder="Global Search"
//         />
//       </span>
//     );
//   };

//   const header = renderHeader();
//   // -------------------------------

//   // statusBodyTemplate -----
//   const actionBodyTemplate = (product) => {
//     return <i className={getAction(product)}></i>;
//   };

//   const getAction = (product) => {
//     switch (product.id) {
//       case 1001:
//         return "pi pi-bolt text-primary";
//       case 1002:
//         return "pi pi-times text-primary";
//       case 1003:
//         return "pi pi-slack text-primary";
//       case 1004:
//         return "pi pi-star-fill text-primary";
//       case 1005:
//         return "pi pi-star text-primary";
//       case 1006:
//         return "pi pi-history text-primary";
//       default:
//         return "pi pi-sun text-green-500";
//     }
//   };
//   // Context -------------------------------
//   const [products, setProducts] = useState([]);
//   const [selectedProduct, setSelectedProduct] = useState(null);
//   const toast = useRef(null);
//   const cm = useRef(null);

//   const menuModel = [
//     {
//       label: "Properties",
//       icon: "pi pi-fw pi-info-circle",
//       command: () => viewProduct(selectedProduct),
//     },
//     {
//       label: "Activation",
//       icon: "pi pi-fw pi-sun",
//       command: () => viewProduct(selectedProduct),
//     },
//     {
//       label: "Edit",
//       icon: "pi pi-fw pi-pencil",
//       command: () => viewProduct(selectedProduct),
//     },
//     {
//       label: "Delete",
//       icon: "pi pi-fw pi-trash",
//       command: () => deleteProduct(selectedProduct),
//     },
//   ];

//   useEffect(() => {
//     ProductService.getProductsMini().then((data) => setProducts(data));
//   }, []); // eslint-disable-line react-hooks/exhaustive-deps

//   const viewProduct = (product) => {
//     toast.current.show({
//       severity: "info",
//       summary: "Product Selected",
//       detail: product.name,
//     });
//   };

//   const deleteProduct = (product) => {
//     let _products = [...products];

//     _products = _products.filter((p) => p.id !== product.id);

//     toast.current.show({
//       severity: "error",
//       summary: "Product Deleted",
//       detail: product.name,
//     });
//     setProducts(_products);
//   };

//   const formatCurrency = (value) => {
//     return value.toLocaleString("en-US", {
//       style: "currency",
//       currency: "USD",
//     });
//   };

//   const priceBodyTemplate = (rowData) => {
//     return formatCurrency(rowData.price);
//   };

//   return (
//     <div className="flex-1">
//       {/* <Button label="Add New Investor" className="mb-2 w-full" outlined /> */}
//       <Toast ref={toast} />
//       <ContextMenu
//         model={menuModel}
//         ref={cm}
//         onHide={() => setSelectedProduct(null)}
//       />
//       <DataTable
//         value={customers}
//         paginator
//         rows={6}
//         rowsPerPageOptions={[5, 10, 25, 50]}
//         header={header}
//         filters={filters}
//         onFilter={(e) => setFilters(e.filters)}
//         selection={selectedCustomer}
//         onSelectionChange={(e) => setSelectedCustomer(e.value)}
//         selectionMode="single"
//         dataKey="id"
//         stateStorage="session"
//         stateKey="dt-state-demo-local"
//         emptyMessage="No customers found."
//         tableStyle={{ minWidth: "30rem" }}
//         size="small"
//         resizableColumns
//         // -----
//         onContextMenu={(e) => cm.current.show(e.originalEvent)}
//         contextMenuSelection={selectedProduct}
//         onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
//       >
//         <Column
//           field="name"
//           header="Name"
//           sortable
//           filter
//           filterPlaceholder="Search"
//         ></Column>
//         <Column
//           header="Agent"
//           body={representativeBodyTemplate}
//           sortable
//           sortField="representative.name"
//           filter
//           filterField="representative"
//           showFilterMatchModes={false}
//           filterElement={representativeFilterTemplate}
//           filterMenuStyle={{ width: "14rem" }}
//         ></Column>
//         <Column
//           header="Action"
//           body={actionBodyTemplate}
//           sortable
//           sortField="country.name"
//           filter
//           filterField="country.name"
//           filterPlaceholder="Search"
//         ></Column>
//         <Column
//           field="status"
//           header="Product"
//           body={statusBodyTemplate}
//           sortable
//           filter
//           filterElement={statusFilterTemplate}
//           filterMenuStyle={{ width: "14rem" }}
//         ></Column>
//       </DataTable>
//     </div>
//   );
// }

import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ContextMenu } from "primereact/contextmenu";
import { ProductService } from "./service/ProductService";
import { Message } from "primereact/message";

export default function ExplorerInvestor() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Edit",
      icon: "pi pi-fw pi-pencil",
      command: () => editProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-times",
      command: () => deleteProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    alert(product.name);
  };

  const editProduct = (product) => {
    alert(product.name);
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    alert(product.name);
    setProducts(_products);
  };

  return (
    <>
      <div className="flex-1">
        <Message
          severity="success"
          className="w-full justify-content-start px-4 mb-2"
          content={
            <div className="w-full flex justify-content-between">
              <div>Investor Actived</div>
              <div
                className="text-cyan-600 hover:text-blue-800 cursor-pointer"
                onClick={() => alert("halo")}
              >
                <i className="pi pi-plus mr-1"></i>
                Investor
              </div>
            </div>
          }
        />
        <div className="card flex-1">
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />
          <DataTable
            value={products}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
            size="small"
            paginator
            rows={6}
            sortMode="multiple"
          >
            <Column field="code" sortable header="#"></Column>
            <Column field="name" sortable header="Nama"></Column>
            <Column field="category" sortable header="Tanggal"></Column>
          </DataTable>
        </div>
      </div>
    </>
  );
}
