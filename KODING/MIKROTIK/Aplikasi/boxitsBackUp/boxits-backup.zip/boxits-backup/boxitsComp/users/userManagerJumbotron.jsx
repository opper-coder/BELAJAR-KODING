import { useState } from "react";
import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import { InputText } from "primereact/inputtext";
import { Calendar } from "primereact/calendar";
import TanggalLive from "../tanggalLive";

export default function UserManagerJumbotron() {
  const [date, setDate] = useState("null");

  // menubar ------------------------
  const items = [
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="User Managers"
        subTitle="Monitoring Admin, User, investor, end User list and Properties"
        className="mb-4 surface-300 "
      >
        <ul className="text-blue-700 m-0">
          <li>
            Structural Manager Tree, Structural, Freelancer, investor, End User
            List
          </li>
          <li>List Right panel</li>
          <li>Create, Edit, delete account and Properties </li>
          <li>Root and Date search</li>
        </ul>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
