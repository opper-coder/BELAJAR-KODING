import { TabView, TabPanel } from "primereact/tabview";
import { Image } from "primereact/image";
import { Button } from "primereact/button";
import SidebarReseller from "./SidebarReseller";

export default function ActivitySeller() {
  return (
    <>
      <div className="card w-full">
        <TabView>
          <TabPanel header="Properties">
            <div className="flex gap-2">
              <div className="card flex justify-content-center">
                <Image src="/gambar/user.png" alt="Image" width="100" />
              </div>
              <div className="card flex-1 flex">
                <ul className="list-none" style={{ width: "20%" }}>
                  <li className="mb-2">Nama</li>
                  <li className="mb-2">Alamat</li>
                  <li className="mb-2">Bank</li>
                  <li className="mb-2">Rekening</li>
                  <li className="mb-2">Hp</li>
                  <li className="mb-2">Tanggal register</li>
                  <li className="mb-2">Login Sejak</li>
                  <li className="mb-2">Total amount</li>
                  <Button label="Properties" text className="mt-4" />
                </ul>
                <ul className="list-none">
                  <li className="mb-2 capitalize font-bold">: aisyah</li>
                  <li className="mb-2 capitalize font-bold">: saiti</li>
                  <li className="mb-2 capitalize font-bold">: bri</li>
                  <li className="mb-2 capitalize font-bold">: 121212</li>
                  <li className="mb-2 capitalize font-bold">: 081333444777</li>
                  <li className="mb-2 capitalize font-bold">: 12/1/2023</li>
                  <li className="mb-2 capitalize font-bold">: 6 bulan lalu</li>
                  <li className="mb-2 capitalize font-bold">: 3000000</li>
                </ul>
              </div>
            </div>
          </TabPanel>
          <TabPanel header="Balance">
            <div className="flex gap-2">
              <SidebarReseller />
            </div>
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
