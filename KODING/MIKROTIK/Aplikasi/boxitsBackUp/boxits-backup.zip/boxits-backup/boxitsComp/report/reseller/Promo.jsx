import TablePromo from "./TabelPromo";

export default function Promo() {
  return (
    <div className="card w-full">
      <TablePromo />
    </div>
  );
}
