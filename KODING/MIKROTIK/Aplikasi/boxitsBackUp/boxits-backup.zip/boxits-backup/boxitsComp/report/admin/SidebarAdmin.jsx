import { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Message } from "primereact/message";
import { Badge } from "primereact/badge";
import Capital from "../reseller/Capital";
import Transfer from "../reseller/Transfer";
import Promo from "../reseller/Promo";
import RecapAdmin from "./RecapAdmin";

export default function SidebarAdmin() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [reseller, setReseller] = useState("Recap");
  const countries = [
    { name: "Recap", icon: "pi pi-star-fill mr-3", notif: "30" },
    { name: "Capital", icon: "pi pi-star-fill mr-3", notif: "10" },
    { name: "Transfer", icon: "pi pi-star-fill mr-3", notif: "12" },
    { name: "Promo", icon: "pi pi-star-fill mr-3", notif: "12" },
  ];

  const TampilHalaman = () => {
    switch (reseller) {
      case "Recap":
        return <RecapAdmin />;
        break;
      case "Capital":
        return <Capital />;
        break;
      case "Transfer":
        return <Transfer />;
        break;
      case "Promo":
        return <Promo />;
        break;
      default:
        return <RecapAdmin />;
        break;
    }
  };

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
        <Badge
          value={option.notif}
          className="ml-auto"
          severity="success"
        ></Badge>
      </div>
    );
  };

  return (
    <div className="flex gap-2 w-full">
      <div>
        <Message
          className=" w-full mb-2 justify-content-start"
          severity="info"
          content={
            <span>
              Menu: <b>{reseller}</b>
            </span>
          }
        />
        <ListBox
          value={selectedCountry}
          onChange={(e) => {
            setSelectedCountry(e.value);
            setReseller(e.value.name);
            // alert("halo " + e.value.name);
          }}
          options={countries}
          optionLabel="name"
          itemTemplate={countryTemplate}
          className="w-full md:w-14rem"
          listStyle={{ maxHeight: "400px" }}
        />
      </div>
      {TampilHalaman()}
    </div>
  );
}
