import { useState } from "react";
import { ListBox } from "primereact/listbox";
import { Message } from "primereact/message";
import { Badge } from "primereact/badge";
import RecapRoot from "./RecapRoot";
import Capital from "./Capital";
import Promo from "./Promo";

export default function SidebarRoot() {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [reseller, setReseller] = useState(null);
  const countries = [
    { name: "Recap", icon: "pi pi-star-fill mr-3", notif: "10" },
    { name: "Capital", icon: "pi pi-star-fill mr-3", notif: "10" },
    { name: "Promo", icon: "pi pi-star-fill mr-3", notif: "12" },
  ];

  const TampilHalaman = () => {
    switch (reseller) {
      case "Recap":
        return <RecapRoot />;
        break;
      case "Capital":
        return <Capital />;
        break;
      case "Promo":
        return <Promo />;
        break;
      default:
        return <RecapRoot />;
        break;
    }
  };

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
        <Badge
          value={option.notif}
          className="ml-auto"
          severity="success"
        ></Badge>
      </div>
    );
  };

  return (
    <div className="flex gap-2 w-full">
      <div>
        <Message
          className=" w-full mb-2 justify-content-start"
          severity="info"
          content={
            <span>
              Menu: <b>{reseller}</b>
            </span>
          }
        />
        <ListBox
          value={selectedCountry}
          onChange={(e) => {
            setSelectedCountry(e.value);
            setReseller(e.value.name);
            // alert("halo " + e.value.name);
          }}
          options={countries}
          optionLabel="name"
          itemTemplate={countryTemplate}
          className="w-full md:w-14rem"
          listStyle={{ maxHeight: "400px" }}
        />
      </div>
      {TampilHalaman()}
      {/* <reseller name={reseller} /> */}
    </div>
  );
}
