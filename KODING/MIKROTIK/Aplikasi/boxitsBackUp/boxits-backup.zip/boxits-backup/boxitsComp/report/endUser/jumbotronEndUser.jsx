import { useState } from "react";
import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import { Calendar } from "primereact/calendar";
import { Button } from "primereact/button";
import TanggalLive from "../../tanggalLive";

export default function JumbotronEndUser() {
  const [date, setDate] = useState(null);
  const items = [
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
      <Calendar
        value={date}
        onChange={(e) => setDate(e.value)}
        view="month"
        dateFormat="mm/yy"
        showIcon
      />
      <Button label="Go" text />
    </div>
  );

  return (
    <>
      <Card
        title="Report Reseller"
        subTitle="hirarcical Root, Order, Transfer, Sell, Balance, Liquidation, profit, promo"
        className="mb-4 surface-300 "
      >
        <div className="flex">
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>Hirarcical root</li>
              <li>Order Capital</li>
              <li>Transfer To other Reseller, liquidation,</li>
            </ul>
          </div>
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              <li>Promo</li>
              <li>Bonus</li>
              <li>Profit</li>
            </ul>
          </div>
        </div>
      </Card>
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
