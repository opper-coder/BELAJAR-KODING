import TableTransfer from "./TabelTransfer";

export default function Transfer() {
  return (
    <div className="card w-full">
      <TableTransfer />
    </div>
  );
}
