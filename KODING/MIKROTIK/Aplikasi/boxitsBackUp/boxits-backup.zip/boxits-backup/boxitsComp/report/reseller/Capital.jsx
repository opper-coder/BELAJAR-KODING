import TabelCapital from "./TabelCapital";

export default function Capital() {
  return (
    <div className="card w-full">
      <TabelCapital />
    </div>
  );
}
