// import { TabPanel, TabView } from "primereact/tabview";
// import Capital from "./Capital";
// import Voucher from "./Voucher";
// import Data from "./Data";

import SidebarEnduser from "./SidebarEndUser";

export default function Transaction() {
  return (
    <>
      <SidebarEnduser />
    </>
  );
}
