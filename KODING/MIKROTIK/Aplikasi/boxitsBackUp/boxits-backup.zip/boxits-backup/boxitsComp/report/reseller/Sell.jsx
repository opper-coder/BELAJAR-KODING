import { TabPanel, TabView } from "primereact/tabview";
import TabelVoucher from "./TabelVoucher";
import TabelData from "./TabelData";
import TabelPrinting from "./TabelPrinting";
import TabelSaldo from "./TabelSaldo";
import TabelPPPoE from "./TabelPPPoE";

export default function Sell() {
  return (
    <div className="card w-full">
      <TabView>
        <TabPanel header="Voucher">
          <TabelVoucher />
        </TabPanel>
        <TabPanel header="Data">
          <TabelData />
        </TabPanel>
        <TabPanel header="Printing">
          <TabelPrinting />
        </TabPanel>
        <TabPanel header="Saldo">
          <TabelSaldo />
        </TabPanel>
        <TabPanel header="PPPoE">
          <TabelPPPoE />
        </TabPanel>
      </TabView>
    </div>
  );
}
