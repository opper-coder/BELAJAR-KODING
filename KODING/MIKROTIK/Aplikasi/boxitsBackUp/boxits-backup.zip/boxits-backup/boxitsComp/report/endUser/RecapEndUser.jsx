import { Divider } from "primereact/divider";

export default function RecapEndUser() {
  return (
    <>
      <div className="flex w-full card">
        <ul className="flex-1 list-none">
          <li>Modal</li>
          <Divider />
          <li>Penjualan</li>
          <li>Promo</li>
          <li>Transfer</li>
          <li>Saldo</li>
          <Divider />
          <li>Profit</li>
          <Divider />
        </ul>
        <ul className="list-none">
          <li className="font-bold text-green-500 text-right">20.000.000</li>
          <Divider />
          <li className="font-bold text-red-500 text-right">18.000.000</li>
          <li className="text-right">18.000.000</li>
          <li className="text-right">5.000.000</li>
          <li className="text-right">4.000.000</li>
          <Divider />
          <li className="text-right">1.000.000</li>
          <Divider />
        </ul>
        <div className="flex-1"></div>
        <div className="flex-1"></div>
      </div>
    </>
  );
}

/*
Reseller
-----------------------------
modal           1000
penjualan       1000
promo           1000
-----
rincian:
penjualan
  voucher
  printing  
  data
  PPPoE
transfer
  ke admin pencairan
  ke sesama reseller
promo
-----

*/
