import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import TanggalLive from "../tanggalLive";

export default function Jumbotron() {
  // menubar ------------------------
  const items = [
    {
      label: "Add Region",
      icon: "pi pi-fw pi-plus",
      command: () => alert("Tambah Lokasi, properties, oleh root, SA, Admin"),
    },
    {
      label: "View Region",
      icon: "pi pi-fw pi-user",
      command: () => region(),
    },
    {
      label: "Deleted Node",
      icon: "pi pi-fw pi-trash",
      url: "./deletedAccount",
    },
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Root Server"
        subTitle="Node Location Root, Admin Assign "
        className="mb-4 surface-300"
      >
        <div className="flex gap-4 text-blue-700 m-0">
          <div className="flex-1">
            <b>Fungsi pokok</b>
            <ul>
              <li>Add Location Region</li>
              <li>Add Server</li>
              <li>Add AP</li>
              <li>Add Server/AP properties</li>
            </ul>
          </div>
          <div className="flex-1">
            <ul>
              <li>Assign Employee</li>
              <li>Assign Server</li>
              <li>Assign AP</li>
              <li>CRUD</li>
              <li>Verify</li>
            </ul>
          </div>
          <div className="flex-1">
            <ul>
              <li>Request</li>
              <li>Acuan Penugasan Paket Project oleh semua admin</li>
              <li>Acuan bagi titik lokasi kerjasama Investor</li>
              <li>Acaun lainya</li>
            </ul>
          </div>
        </div>
      </Card>
      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
