import React, { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Tag } from "primereact/tag";
import { Image } from "primereact/image";
import { CustomerService } from "./service/CustomerService";

import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
// import { ProductService } from "./service/ProductService";

export default function ServerAP() {
  const [customers, setCustomers] = useState([]);
  const [expandedRows, setExpandedRows] = useState([]);

  useEffect(() => {
    CustomerService.getCustomersMedium().then((data) => setCustomers(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const headerTemplate = (data) => {
    return (
      <React.Fragment>
        <Image
          alt={data.representative.name}
          src={`https://primefaces.org/cdn/primereact/images/avatar/${data.representative.image}`}
          width="32"
          style={{ verticalAlign: "middle" }}
          className="ml-2"
        />
        <span
          className="vertical-align-middle text-cyan-600 hover:text-blue-800 cursor-pointer "
          onClick={() => alert("Halo Properties " + data.representative.name)}
        >
          <span className="pl-1 ">
            {" | "}
            <i className="pi pi-info-circle mx-1"></i>
            Prop
          </span>
        </span>
        <span
          className="vertical-align-middle text-cyan-600 hover:text-blue-800 cursor-pointer "
          onClick={() => alert("Halo Add router " + data.representative.name)}
        >
          <span>
            {" | "}
            <i className="pi pi-wifi mx-1"></i>
            Add |
          </span>
        </span>
        <span className="vertical-align-middle ml-2 font-bold">
          {data.representative.name}
        </span>
      </React.Fragment>
    );
  };

  const footerTemplate = (data) => {
    return (
      <React.Fragment>
        <td colSpan={5}>
          <div className="flex justify-content-end font-bold w-full">
            Total Customers: {calculateCustomerTotal(data.representative.name)}
          </div>
        </td>
      </React.Fragment>
    );
  };

  const statusBodyTemplate = (rowData) => {
    return (
      <Tag value={rowData.status} severity={getSeverity(rowData.status)} />
    );
  };

  const calculateCustomerTotal = (name) => {
    let total = 0;

    if (customers) {
      for (let customer of customers) {
        if (customer.representative.name === name) {
          total++;
        }
      }
    }

    return total;
  };

  const getSeverity = (status) => {
    switch (status) {
      case "unqualified":
        return "danger";

      case "qualified":
        return "success";

      case "new":
        return "info";

      case "negotiation":
        return "warning";

      case "renewal":
        return null;
    }
  };
  // ----------------------------------------
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Edit",
      icon: "pi pi-fw pi-pencil",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Remote",
      icon: "pi pi-fw pi-share-alt",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-times",
      command: () => deleteProduct(selectedProduct),
    },
  ];

  // useEffect(() => {
  //   ProductService.getProductsMini().then((data) => setProducts(data));
  // }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };
  // getCustomersXLarge
  // ---------------------------------------------------
  return (
    <div className="cardx w-full">
      <Toast ref={toast} />

      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={customers}
        rowGroupMode="subheader"
        groupRowsBy="representative.name"
        sortMode="single"
        sortField="representative.name"
        sortOrder={1}
        expandableRowGroups
        expandedRows={expandedRows}
        onRowToggle={(e) => setExpandedRows(e.data)}
        rowGroupHeaderTemplate={headerTemplate}
        rowGroupFooterTemplate={footerTemplate}
        paginator
        rows={30}
        size="small"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
      >
        <Column field="name" header="Name"></Column>
        <Column field="company" header="Merk"></Column>
        <Column field="date" header="Tanggal"></Column>
        <Column
          field="status"
          header="Status"
          body={statusBodyTemplate}
        ></Column>
      </DataTable>
    </div>
  );
}
