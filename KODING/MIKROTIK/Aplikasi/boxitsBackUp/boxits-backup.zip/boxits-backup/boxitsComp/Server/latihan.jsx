export default function Latihan() {
  return <div>Latihan</div>;
}
