import { TabView, TabPanel } from "primereact/tabview";
import ServerOffLine from "./ServerOffLine";
import ApOffLine from "./ApOffLine";
export default function ServerApOffline() {
  return (
    <div className="w-full">
      <TabView>
        <TabPanel header="Server">
          <ServerOffLine />
        </TabPanel>
        <TabPanel header="Router">
          <ApOffLine />
        </TabPanel>
      </TabView>
    </div>
  );
}
