import { Menubar } from "primereact/menubar";
import { Card } from "primereact/card";
import { InputText } from "primereact/inputtext";
import TanggalLive from "../tanggalLive";

export default function ServerJumbotron() {
  // menubar ------------------------
  const items = [
    {
      label: "Add Region",
      icon: "pi pi-fw pi-plus",
      command: () => alert("Tambah Lokasi, properties, oleh root, SA, Admin"),
    },
    // {
    //   label: "Access Point",
    //   icon: "pi pi-fw pi-wifi",
    //   url: "./router",
    // },
    {
      label: "Deleted Node",
      icon: "pi pi-fw pi-trash",
      url: "./deletedAccount",
    },
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Card
        title="Root"
        subTitle="Node Location Root, Admin Assign "
        className="mb-4 surface-300"
      >
        <div className="flex gap-4 text-blue-700 m-0">
          <div className="flex-1">
            <b>Fungsi pokok</b>

            <ul className="">
              <li>Generate Node Root Location.</li>
              <ol>
                <li>Acuan Penugasan Paket Project oleh semua admin</li>
                <li>Acuan pemrosesan Project Server, Akses Point</li>
                <li>Acuan bagi titik lokasi kerjasama</li>
                <li>
                  Acaun Lokasi bagi Investor dimana mereka membelanjakan
                  modalnya
                </li>
              </ol>
              <li>Menambahkan Super Admin Account Sampai ke hilir</li>
            </ul>
          </div>
          <div className="flex-1">
            <b>Fungsi tambahan</b>
            <ol>
              <li>Add root, Add child</li>
              <li>Edit Properties</li>
              <li>Delete Node</li>
              <li>Verify request child</li>
            </ol>
          </div>
        </div>
      </Card>

      {/* nav bar ----------------------------------- */}
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
