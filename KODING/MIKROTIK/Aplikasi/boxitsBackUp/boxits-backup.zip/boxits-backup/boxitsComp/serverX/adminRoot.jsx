// import { useState, useEffect, useRef } from "react";
// import { TreeTable } from "primereact/treetable";
// import { ContextMenu } from "primereact/contextmenu";
// import { Toast } from "primereact/toast";
// import { Column } from "primereact/column";
// import { NodeService } from "../../pages/boxits/server/service/NodeService";
// import { Tag } from "primereact/tag";

// export default function AdminRoot() {
//   const [nodes, setNodes] = useState([]);
//   const [expandedKeys, setExpandedKeys] = useState(null);
//   const [selectedNodeKey, setSelectedNodeKey] = useState(null);
//   const toast = useRef(null);
//   const cm = useRef(null);
//   const menu = [
//     {
//       label: "Properies",
//       icon: "pi pi-info-circle",
//       command: () => {
//         alert("action server");
//       },
//     },
//     {
//       label: "Add Child",
//       icon: "pi pi-plus",
//       command: () => {
//         alert("action server");
//       },
//     },
//     {
//       label: "Edit",
//       icon: "pi pi-pencil",
//       command: () => {
//         alert("action server");
//       },
//     },
//     {
//       label: "Toggle",
//       icon: "pi pi-sort",
//       command: () => {
//         let _expandedKeys = { ...expandedKeys };

//         if (_expandedKeys[selectedNodeKey])
//           delete _expandedKeys[selectedNodeKey];
//         else _expandedKeys[selectedNodeKey] = true;

//         setExpandedKeys(_expandedKeys);
//       },
//     },
//   ];

//   useEffect(() => {
//     NodeService.getTreeTableNodes().then((data) => setNodes(data));
//   }, []);

//   const header = <h6>Hierarchical Structure Location and Admin</h6>;

//   // templat table-----
//   const statusBodyTemplate = () => {
//     return <Tag value="Active" severity="success"></Tag>;
//   };

//   const statusBodyTemplate2 = (product) => {
//     if (product.quantity < 40 && product.rating > 2) {
//       // jika verifikasi TRUE
//       return <i className="pi pi-check text-blue-500"></i>;
//     } else {
//       // jika verify else (FALSE)
//       return <i className="pi pi-reply text-red-500"></i>;
//     }
//   };

//   return (
//     <div className="card">
//       <Toast ref={toast} />

//       <ContextMenu
//         model={menu}
//         ref={cm}
//         onHide={() => setSelectedNodeKey(null)}
//       />
//       <TreeTable
//         header={header}
//         value={nodes}
//         expandedKeys={expandedKeys}
//         onToggle={(e) => setExpandedKeys(e.value)}
//         contextMenuSelectionKey={selectedNodeKey}
//         onContextMenuSelectionChange={(event) =>
//           setSelectedNodeKey(event.value)
//         }
//         onContextMenu={(event) => cm.current.show(event.originalEvent)}
//         tableStyle={{ minWidth: "50rem" }}
//         size={"small"}
//         resizableColumns
//       >
//         <Column field="name" header="Name" expander></Column>
//         <Column
//           field="type"
//           header="Status"
//           body={statusBodyTemplate2}
//         ></Column>
//         <Column field="size" header="Size"></Column>
//         <Column field="type" header="Type"></Column>
//         <Column
//           field="type"
//           header="Product"
//           body={statusBodyTemplate}
//         ></Column>
//       </TreeTable>
//     </div>
//   );
// }

import React, { useState, useEffect, useRef } from "react";
import { Tree } from "primereact/tree";
import { NodeService } from "./service/NodeService";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ProductService } from "./service/ProductService";
import { ContextMenu } from "primereact/contextmenu";
import { Message } from "primereact/message";

export default function FilterDemo() {
  const [nodes, setNodes] = useState([]);
  const [products, setProducts] = useState([]);

  const [selectedProduct, setSelectedProduct] = useState(null);
  const cm = useRef(null);

  const menuModel = [
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => propProduct(selectedProduct),
    },
    {
      label: "Edit",
      icon: "pi pi-pencil",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-trash",
      command: () => {
        alert("halo Child tree " + selectedNodeKey);
      },
    },
  ];

  useEffect(() => {
    NodeService.getTreeNodes().then((data) => setNodes(data));
  }, []);

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);
  // ---
  const viewProduct = (product) => {
    alert("halo Child tree " + product.name);
  };
  const propProduct = (product) => {
    alert("halooo prop " + product.name);
  };
  // ---
  // const [nodes2, setNodes2] = useState([]);
  const [expandedKeys, setExpandedKeys] = useState({});
  const [selectedNodeKey, setSelectedNodeKey] = useState(null);
  const cm2 = useRef(null);
  const menu = [
    {
      label: "Properties",
      icon: "pi pi-info-circle",
      command: () => {
        alert("halo properties tree " + selectedNodeKey);
      },
    },
    {
      label: "Show Seller",
      icon: "pi pi-book",
      command: () => {
        alert("halo properties tree " + selectedNodeKey);
      },
    },
    {
      label: "Edit",
      icon: "pi pi-pencil",
      command: () => {
        alert("action server");
      },
    },
    {
      label: "Delete",
      icon: "pi pi-trash",
      command: () => {
        alert("halo delet tree " + selectedNodeKey);
      },
    },
    {
      label: "Toggle",
      icon: "pi pi-sort",
      command: () => {
        let _expandedKeys = { ...expandedKeys };

        if (_expandedKeys[selectedNodeKey])
          delete _expandedKeys[selectedNodeKey];
        else _expandedKeys[selectedNodeKey] = true;

        setExpandedKeys(_expandedKeys);
      },
    },
  ];

  useEffect(() => {
    NodeService.getTreeNodes().then((data) => setNodes(data));
  }, []);
  return (
    <div className="cardx flex gap-2">
      <div>
        <Message
          severity="success"
          className="w-full justify-content-start px-4 mb-2"
          content={<div className="ml-2">Tree Activated</div>}
        />
        <ContextMenu model={menu} ref={cm2} />
        <Tree
          value={nodes}
          filter
          filterMode="lenient"
          filterPlaceholder="Lenient Filter"
          className="w-full md:w-30rem"
          expandedKeys={expandedKeys}
          onToggle={(e) => setExpandedKeys(e.value)}
          contextMenuSelectionKey={selectedNodeKey}
          onContextMenuSelectionChange={(e) => setSelectedNodeKey(e.value)}
          onContextMenu={(e) => cm2.current.show(e.originalEvent)}
        />
      </div>
      <div className="w-full">
        <Message
          severity="info"
          className="w-full justify-content-start px-4 mb-2"
          content={<div className="ml-2">Seller List</div>}
        />
        <div className="card w-full">
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />
          <DataTable
            value={products}
            className="w-full"
            size="small"
            paginator
            rows={8}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
          >
            <Column field="code" header="Code"></Column>
            <Column field="name" header="Name"></Column>
            <Column field="category" header="Category"></Column>
            <Column field="quantity" header="Quantity"></Column>
          </DataTable>
        </div>
      </div>
    </div>
  );
}
