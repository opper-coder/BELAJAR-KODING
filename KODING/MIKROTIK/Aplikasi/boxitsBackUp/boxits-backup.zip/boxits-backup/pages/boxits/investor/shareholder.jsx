export default function Shareholder() {
  return (
    <>
      inv Shareholder
      {/* sementara, hapus ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>>  */}
      <div className="card mt-4 bg-yellow-300 text-red-900">
        <b>Fungsi Utama</b>
        <ul>
          <li>Hanya User yang dipilih oleh Root</li>
          <li>Mendapat porsi ...%</li>
          <li>Setelah di ambil: biaya dan pengembangan aplikasi</li>
          <li>bekerja sama-sama</li>
          <li>biaya dari perusahaan</li>
          <li>jika biaya sendiri maka prosentasi ...%</li>
          <li>minimal memegang suatu wilyah luas seperti kabupaten</li>
        </ul>
      </div>
      {/* end sementara, hapus ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>>  */}
    </>
  );
}
