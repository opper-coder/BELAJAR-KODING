// AUTORIZATION ------------------------

/*
add lokasi
add server
add AP 
add Paket
add Product
add user
assign server
assign employee
assign product 
assign paket 
req add lokasi
req add server
req add AP 
req add Paket
req add Product
req add user 
transfer product
request product
daftarkan 

// ALGORITMA ----------------------------

HP 

MIKROTIK
  - konfig dasar
  - konfig keamanan
  - create user profile
  - create user via remote dengan name, pass generate dari web
  - hapus terjadwal 4 bulan sekali user 
  - restart terjadwal 1x24 jam 3 malam
  - konfig remote ke ddns atau via VPN VPS kita (IP Public remote)
  - atur wallet garden ke website login page user, dan admin reseller
  - atur login page redirect ke loginpage websites
  - bikin app webview ke link admin reseller

WEBSITE
	- remote mikrotik
	- enduser akses wifi
    - redirect ke halaman login website
		- portal login (wallet garden) 
    - register dan login
    - order data via web
    - aktif kan voucher
      - cek jika ada saldo maka bisa masuk aktifkan
		  - remote mikrotik create user 
      - ambil data create terbaru, dan kirim sebagai props ke login page mikrotik kembali untuk masuk
      - simpan session sebagai login saat ini sampai batas waktu berjalan 
      - session bisa di gunakan sebagai login kembali (relogin dengan user session tadi)
		- 
  - website mencatat transaksi lewat  

// TO do LIST ----------------------------




*/

import { useState, useEffect } from "react";
import { Message } from "primereact/message";
import { ListBox } from "primereact/listbox";
import JumbotronServer from "@/boxitsComp/Server/Jumbotron";
import RootTreeServer from "@/boxitsComp/Server/RootTreeServer";
import ServerAP from "@/boxitsComp/Server/ServerAP";
import ApOffLine from "@/boxitsComp/Server/ApOffLine";
import ServerOffLine from "@/boxitsComp/Server/ServerOffLine";
import AddServer from "@/boxitsComp/Server/AddServer";
import DeleteServer from "@/boxitsComp/Server/DeleteServer";
import DeleteAP from "@/boxitsComp/Server/DeleteAP";
import PermissionRoot from "@/boxitsComp/Server/PermissionRoot";
import AllServer from "@/boxitsComp/Server/AllServer";
import AllAP from "@/boxitsComp/Server/AllAP";
// import AdminTreeDynamic from "@/boxitsComp/utility/adminTreeDynamic";
// import ServerApPending from "@/boxitsComp/Server/ServerApPending";
// import ServerApOffline from "@/boxitsComp/Server/ServerApOffline";
// import ServerApOffline from "@/boxitsComp/Server/ServerApOffline";

export default function Root() {
  const [selectedMenu, setSelectedMenu] = useState("Active");
  const [judulMenu, setJudulMenu] = useState("Active");

  const cities = [
    { name: "Add Server", code: "PRS" },
    { name: "Active", code: "NY" },
    { name: "Server Off", code: "LDN" },
    { name: "AP Off", code: "IST" },
    { name: "Del Server", code: "PRS" },
    { name: "Del AP", code: "PRS" },
    { name: "All Server", code: "PRS" },
    { name: "All AP", code: "PRS" },
  ];

  const TampilkanHalaman = (menu) => {
    switch (menu) {
      case "Active":
        return (
          <>
            <ServerAP />
          </>
        );
        break;
      case "Server Off":
        return (
          <>
            <ServerOffLine />
          </>
        );
        break;
      case "AP Off":
        return (
          <>
            <ApOffLine />
          </>
        );
        break;
      case "Add Server":
        return (
          <>
            <AddServer />
          </>
        );
        break;
      case "Del Server":
        return (
          <>
            <DeleteServer />;
          </>
        );
        break;
      case "Del AP":
        return (
          <>
            <DeleteAP />;
          </>
        );
        break;
      case "All Server":
        return (
          <>
            <AllServer />;
          </>
        );
        break;
      case "All AP":
        return (
          <>
            <AllAP />;
          </>
        );
        break;
      default:
        return (
          <>
            <ServerAP />
          </>
        );
    }
  };

  const judul = (classwarna, jumlah, judul) => {
    return (
      <>
        <Message
          severity={classwarna}
          className="w-full justify-content-start px-4 mb-2"
          content={
            <div className="ml-2">
              {judul}
              <b>{jumlah}</b>
            </div>
          }
        />
      </>
    );
  };

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className="pi pi-bookmark mr-3"></i>
        <div>{option.name}</div>
      </div>
    );
  };

  const MenuServer = () => {
    return (
      <>
        <ListBox
          value={selectedMenu}
          onChange={(e) => {
            setSelectedMenu(e.value);
            setJudulMenu(e.value.name);
            console.log(judulMenu);
          }}
          options={cities}
          optionLabel="name"
          className="w-full md:w-14rem"
          itemTemplate={countryTemplate}
        />
      </>
    );
  };

  return (
    <>
      <JumbotronServer />
      <PermissionRoot />
      <div className="card flex gap-2">
        <RootTreeServer />
        {/* <AdminTreeDynamic /> */}
        <div>
          {judul("info", "", judulMenu)}
          <MenuServer />
        </div>
        <div className="flex-1 ">
          {judul("info", "", "Daftar status Server")}
          <div className="card">{TampilkanHalaman(judulMenu)}</div>
        </div>
      </div>
    </>
  );
}
