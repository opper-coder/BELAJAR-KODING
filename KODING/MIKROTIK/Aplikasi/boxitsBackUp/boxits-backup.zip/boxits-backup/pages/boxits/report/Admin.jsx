import { Message } from "primereact/message";
import JumbotronReseller from "@/boxitsComp/report/reseller/jumbotronReseller";
import ActivitySeller from "@/boxitsComp/report/reseller/ActivitySeller";
import RootTreeServer from "@/boxitsComp/report/reseller/RootTreeServer";

export default function Reseller() {
  const judul = (classwarna, jumlah, judul) => {
    return (
      <>
        <Message
          severity={classwarna}
          className="w-full justify-content-start px-4"
          content={
            <div className="ml-2 ">
              {judul}: <b>Rp. {jumlah}</b>
            </div>
          }
        />
      </>
    );
  };

  return (
    <>
      <JumbotronReseller />
      <div className="flex gap-2">
        <div className="flex-1">
          <div className="flex gap-2">
            {judul("success", "40.000.000", "Debet: ")}
            {judul("info", "20.000.000", "Kredit: ")}
          </div>
          <div className="flex gap-2 mt-2">
            <RootTreeServer />
            <ActivitySeller />
          </div>
        </div>
      </div>
    </>
  );
}
