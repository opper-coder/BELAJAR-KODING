import Link from "next/link";
import { Button } from "primereact/button";
import { useState, useEffect, useRef } from "react";
import { ProductService } from "./service/ProductService.js";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ContextMenu } from "primereact/contextmenu";
import { TabView, TabPanel } from "primereact/tabview";

export default function DeletedAccount() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const cm = useRef(null);
  const menuModel = [
    {
      label: "Action",
      icon: "pi pi-fw pi-check",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => propProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []);

  const viewProduct = (product) => {
    alert("action " + product.name);
  };
  const propProduct = (product) => {
    alert("halooo prop " + product.name);
  };

  return (
    <>
      <div className="mb-4">
        <Link href="./root">
          <Button label="Back" icon="pi pi-arrow-left" />
        </Link>
      </div>

      {/* --- */}

      <TabView>
        <TabPanel header="Deleted Server">
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />
          <DataTable
            value={products}
            className="w-full"
            size="small"
            paginator
            rows={20}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
          >
            <Column field="code" header="Code"></Column>
            <Column field="name" header="Name"></Column>
            <Column field="category" header="Category"></Column>
            <Column field="quantity" header="Quantity"></Column>
          </DataTable>
        </TabPanel>
        <TabPanel header="Deleted Unit">
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />
          <DataTable
            value={products}
            className="w-full"
            size="small"
            paginator
            rows={20}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
          >
            <Column field="code" header="Code"></Column>
            <Column field="name" header="Name"></Column>
            <Column field="category" header="Category"></Column>
            <Column field="quantity" header="Quantity"></Column>
          </DataTable>
        </TabPanel>
        <TabPanel header="Deleted Seller">
          <ContextMenu
            model={menuModel}
            ref={cm}
            onHide={() => setSelectedProduct(null)}
          />
          <DataTable
            value={products}
            className="w-full"
            size="small"
            paginator
            rows={20}
            onContextMenu={(e) => cm.current.show(e.originalEvent)}
            contextMenuSelection={selectedProduct}
            onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
          >
            <Column field="code" header="Code"></Column>
            <Column field="name" header="Name"></Column>
            <Column field="category" header="Category"></Column>
            <Column field="quantity" header="Quantity"></Column>
          </DataTable>
        </TabPanel>
      </TabView>
    </>
  );
}
