import { TabView, TabPanel } from "primereact/tabview";
import { useState } from "react";
import UserManagerJumbotron from "@/boxitsComp/users/userManagerJumbotron";
import AdminTree from "@/boxitsComp/users/adminTree";
import ExplorerInvestor from "@/boxitsComp/users/explorerInvestor";
import ExplorerInvestor2 from "@/boxitsComp/users/explorerInvestor2";
import ExplorerStructural from "@/boxitsComp/users/explorerStructural";
import ExplorerStructural2 from "@/boxitsComp/users/explorerStructural2";
import ExplorerServerHome from "@/boxitsComp/users/explorerServerHome";
import ExplorerServerHome2 from "@/boxitsComp/users/explorerServerHome2";
import ExplorerFreelancer from "@/boxitsComp/users/explorerFreelancer";
import ExplorerFreelancer2 from "@/boxitsComp/users/explorerFreelancer2";
import ExplorerEndUser from "@/boxitsComp/users/explorerEndUser";
import ExplorerRegion from "@/boxitsComp/users/explorerRegion";
import ExplorerRegion2 from "@/boxitsComp/users/explorerRegion2";
import ExplorerEndUser2 from "@/boxitsComp/users/explorerEndUser2";

export default function Manager() {
  const [root, setRoot] = useState(true);
  return (
    <>
      <UserManagerJumbotron />
      <div className="card flex gap-2">
        <AdminTree />
        <div className="card w-full">
          <TabView>
            <TabPanel header="Investor" className={root ? "block" : "hidden"}>
              <div className="flex gap-2">
                <ExplorerInvestor />
                <ExplorerInvestor2 />
              </div>
            </TabPanel>
            <TabPanel header="Region" className={root ? "block" : "hidden"}>
              <div className="flex gap-2">
                <ExplorerRegion />
                <ExplorerRegion2 />
              </div>
            </TabPanel>
            <TabPanel header="Struktural">
              <div className="flex gap-2">
                <ExplorerStructural />
                <ExplorerStructural2 />
              </div>
            </TabPanel>
            <TabPanel header="Server Home">
              <div className="flex gap-2">
                <ExplorerServerHome />
                <ExplorerServerHome2 />
              </div>
            </TabPanel>
            <TabPanel header="Freelancer">
              <div className="flex gap-2">
                <ExplorerFreelancer />
                <ExplorerFreelancer2 />
              </div>
            </TabPanel>
            <TabPanel header="Enduser">
              {" "}
              <div className="flex gap-2">
                <ExplorerEndUser />
                <ExplorerEndUser2 />
              </div>
            </TabPanel>
          </TabView>
        </div>
      </div>
    </>
  );
}
