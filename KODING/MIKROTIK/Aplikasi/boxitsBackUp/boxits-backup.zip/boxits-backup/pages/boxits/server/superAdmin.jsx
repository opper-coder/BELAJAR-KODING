import SuperAdminJumbotron from "@/boxitsComp/serverX/sAdminjumbotron";
import SuperAdminRoot from "../../../boxitsComp/serverX/superAdminRoot";

export default function SuperAdmin() {
  return (
    <>
      <SuperAdminJumbotron />
      <SuperAdminRoot />
    </>
  );
}
