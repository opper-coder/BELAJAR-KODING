import RootJumbotron from "../../../boxitsComp/serverX/rootJumbotron";
import ServerRoot from "@/boxitsComp/serverX/serverRoot";

export default function Root() {
  return (
    <>
      <RootJumbotron />
      <div className="card">
        <ServerRoot />
      </div>

      {/*   <> ----- <> ----- <> ----- <><> ----- <> ----- <> ----- <>  */}
      <div className="card text-blue-800 bg-blue-100">
        <ul>
          <li>STRUKTUR</li>
          <ul>
            <li>
              <b>Root</b> : adalah hirarki lokasi dari wilayah, cabang, ranting.
              di buat oleh pemilik
            </li>
            <li>
              <b>Server</b> : adalah mikrotik di bawah ranting (root terbawah)
            </li>
            <li>
              <b>SuperAdmin</b> : adalah pemilik wilayah luas tertinggi
            </li>
            <li>
              <b>Admin</b> : adalah representasi cabang/kecamatan
            </li>
            <li>
              <b>Reseller</b> : adalah representasi outlet
            </li>
            <li>
              <b>Enduser</b> : adalah pengguna akhir
            </li>
          </ul>
          <br />
          <li>stackholder :</li>
          <ol>
            <li>root</li>
            <li>superadmin</li>
            <li>admin</li>
            <li>seller</li>
            <li>enduser</li>
          </ol>
          <br />
          <li>Otorisasi</li>
          <ul>
            <li>
              Otorisasi paling atas memiliki fungsi dibawahnya dengan nama:nama
              posisition:root(sesuai hirarki)
            </li>
            <li>
              root : Add root, add super admin, verify mikrotik, add capital,
              transfer capital, action capital
            </li>
            <li>superadmin : add admin, verify seller</li>
            <li>
              admin : addreq server, addreq seller, add anduser, addreq paket,
              transfer
            </li>
            <li>seller : </li>
            <li>enduser : </li>
          </ul>
          <br />
          <li>aktifitas</li>
          <ul>
            <li>add </li>
            <li>addreq </li>
            <li>edit </li>
            <li>assign </li>
            <li>verify </li>
            <li>transfer </li>
          </ul>
        </ul>
      </div>
      <div className="card bg-yellow-200">
        <span className="text-3xl text-white p-2X py-1 px-2 bg-blue-600 border-round-xl ">
          &#9992;
        </span>
        <br />
        <ul>
          <li>DATABASE DESAIN</li>
          <ul>
            <li> root &gt; region &gt; branch &gt; unit </li>
            <li> server </li>
            <li> voucher </li>
            <li> user </li>
            <li> project </li>
            <li> inventory </li>
          </ul>
          <br />
          <li>ACTION</li>
          <ul>
            <li>Table</li>
            <li>Assign</li>
            <li></li>
          </ul>
        </ul>
      </div>

      {/*   <> ----- <> ----- <> ----- <><> ----- <> ----- <> ----- <>  */}
    </>
  );
}
