export default function Public() {
  return (
    <>
      inv public
      {/* sementara, hapus ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>>  */}
      <div className="card mt-4 bg-yellow-300 text-red-900">
        <b>Fungsi Utama</b>
        <ul>
          <li>Pemilik ISP</li>
          <li>Mau bekerja sama menggunakan sistem ini</li>
          <li>biaya mereka sendiri</li>
          <li>pembagian hasil 50% atau jangan di sebutkan prosentase</li>
          <li>Lokasi di luar jangkauan kita</li>
        </ul>
      </div>
      {/* end sementara, hapus ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>>  */}
    </>
  );
}
