import { Message } from "primereact/message";
import VoucherRulesJumbotron from "../../../boxitsComp/transaction/voucherRulesJumbotron";
import Activity from "@/boxitsComp/transaction/activity";

export default function SuperAdmin() {
  const judul = (classwarna, jumlah, judul) => {
    return (
      <>
        <Message
          severity={classwarna}
          className="w-full justify-content-start px-4"
          content={
            <div className="ml-2">
              {judul}: <b>Rp. {jumlah}</b>
            </div>
          }
        />
      </>
    );
  };

  return (
    <>
      <VoucherRulesJumbotron />
      <div className="flex-1">
        <div className="flex gap-2">
          <div className="mb-2 flex-1">{judul("success", 40000, "Debet")}</div>
          <div className="mb-2 flex-1">{judul("info", 35000, "Kredit")}</div>
        </div>
        <div className="card mr-2">
          <Activity />
        </div>
      </div>
    </>
  );
}
