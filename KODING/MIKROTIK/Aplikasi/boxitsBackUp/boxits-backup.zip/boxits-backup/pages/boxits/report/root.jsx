import RootTreeServer from "@/boxitsComp/report/root/RootTreeServer";
import SidebarRoot from "@/boxitsComp/report/root/SidebarRoot";
import JumbotronRoot from "@/boxitsComp/report/root/jumbotronRoot";
import { Button } from "primereact/button";
import { Image } from "primereact/image";
import { Message } from "primereact/message";
import { TabView, TabPanel } from "primereact/tabview";

export default function RootReport() {
  const judul = (classwarna, jumlah, judul) => {
    return (
      <>
        <Message
          severity={classwarna}
          className="w-full justify-content-start px-4"
          content={
            <div className="ml-2 ">
              {judul}: <b>Rp. {jumlah}</b>
            </div>
          }
        />
      </>
    );
  };

  return (
    <>
      <JumbotronRoot />
      <div className="flex gap-2">
        {judul("success", "40.000.000", "Debet: ")}
        {judul("info", "20.000.000", "Kredit: ")}
      </div>
      <div className="flex gap-2 mt-2">
        <RootTreeServer />
        <div className="card flex-1">
          <TabView>
            <TabPanel header="Properties">
              <div className="flex gap-2">
                <div className="card flex justify-content-center">
                  <Image src="/gambar/user.png" alt="Image" width="100" />
                </div>
                <div className="card flex-1 flex">
                  <ul className="list-none" style={{ width: "20%" }}>
                    <li className="mb-2">Nama</li>
                    <li className="mb-2">Alamat</li>
                    <li className="mb-2">Bank</li>
                    <li className="mb-2">Rekening</li>
                    <li className="mb-2">Hp</li>
                    <li className="mb-2">Tanggal register</li>
                    <li className="mb-2">Login Sejak</li>
                    <li className="mb-2">Total amount</li>
                    <Button label="Properties" text className="mt-4" />
                  </ul>
                  <ul className="list-none">
                    <li className="mb-2 capitalize font-bold">: aqil</li>
                    <li className="mb-2 capitalize font-bold">: saiti</li>
                    <li className="mb-2 capitalize font-bold">: bri</li>
                    <li className="mb-2 capitalize font-bold">: 121212</li>
                    <li className="mb-2 capitalize font-bold">
                      : 081333444777
                    </li>
                    <li className="mb-2 capitalize font-bold">: 12/1/2023</li>
                    <li className="mb-2 capitalize font-bold">
                      : 6 bulan lalu
                    </li>
                    <li className="mb-2 capitalize font-bold">: 3000000</li>
                  </ul>
                </div>
              </div>
            </TabPanel>
            <TabPanel header="Balance">
              <SidebarRoot />
            </TabPanel>
          </TabView>
        </div>
      </div>

      {/* <ReportJumbotron /> */}
      {/* <TabReportRoot /> */}
      <div className="card bg-yellow-300 text-blue-800 mt-4 justify-content-start px-4">
        <h5>Breakdown</h5>
        <b>Laporan Administrasi</b>
        <ul>
          <li>Root</li>
          <ul>
            <li>Laporan generate saldo</li>
            <li>Laporan Distribusi saldo</li>
          </ul>
          <li>Admin</li>
          <ul>
            <li>Laporan Aktifitas request saldo</li>
            <li>laporan jual product</li>
            <li>laporan beli jasa paket</li>
            <li>laporan Inventory</li>
          </ul>
          <li>Reseller</li>
          <ul>
            <li>beli saldo</li>
            <li>bonus daan insentif</li>
            <li>transfer saldo</li>
            <li>jual saldo</li>
            <li>jual voucher</li>
            <li>cetak voucher</li>
          </ul>
          <li>EndUser</li>
          <ul>
            <li>beli saldo</li>
            <li>Transfer saldo</li>
            <li>aktifkan voucher</li>
            <li>saldo kadaluarsa</li>
          </ul>
        </ul>

        <b>Product</b>
        <ul>
          <li>Capital</li>
          <li>Product jenis product terjual</li>
          <li>Unit server</li>
          <li>perhitungan per akses point</li>
          <li>Total penjualan</li>
          <li>Sisa</li>
        </ul>
        <b>paket</b>
        <ul>
          <li>Product jenis product terjual</li>
          <li>Unit server</li>
          <li>Total penjualan paket</li>
          <li>sisa</li>
        </ul>
        <b>cost</b>
        <ul>
          <li>Biaya perusahaan</li>
          <li>Biaya wajib</li>
          <li>maintenance</li>
          <li>biaya karyawan</li>
          <li>sppd</li>
          <li>total biaya</li>
          <li>sisa</li>
        </ul>
      </div>

      <div className="card bg-yellow-300 text-blue-800">
        <b>Ringkasan</b>
        <ul>
          <li>laporan emisi</li>
          <li>laporan penjualan</li>
          <li>laporan operasional</li>
          <li>laporan iuran wajib perusahaan</li>
          <li>laporan distribusi gaji</li>
          <li>monitoring dashboard</li>
        </ul>
        <b>Fungsi utama</b>
        <ol>
          <li>tabel product, penjaualan, pembelian</li>
          <li>tabel distribusi, biaya, gaji pokok, </li>
          <li>
            tabel saldo, pendapatan umum, perorang, root, superadmin, admin,
            seller, investor, shareholder, parners, public{" "}
          </li>
          <li>rincian per kategori</li>
          <li>rekapitulasi</li>
          <li>petugas dan assign</li>
          <li>monitoring, evaluating, accounting</li>
          <li></li>
        </ol>
        <b>User</b>
        <ol>
          <li>Root</li>
          <li>Super admin</li>
          <li>Admin</li>
          <li>Seller(mobile)</li>
          <li>Investor</li>
          <li>Shareholder</li>
          <li>Partners</li>
          <li>Public</li>
        </ol>
      </div>
      {/* <Contain /> */}
    </>
  );
}
