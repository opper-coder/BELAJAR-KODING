/* 
bikin tab pada react
-----------------------------------------------
STATE: 
  const [toggle, setToggle] = useState(1);
HTML:
  - class= "tab-active"               // bikin 3 tombol tab
  - class= "content-show"           // bikin 3 content display
CSS: 
  - .tab{display: none}               // kondisi awal
  - .tab-active{display: block}       // style pada tombol aktif nya > sebelumnya juga kasih CSS kondisi awal 
  - .content{display: none}           // kondisi awal
  - .content-show{display: block}     // style pada contain: kondisi default, kondisi aktif
FUNCTION:
  function toggleTab(id){setToggle(id)}             // pengubah state dengan menerima param sebut saja id
TOMBOL:
  onclick={()=>toggleTab(1)}          // trigger dengan mengirim parameter state
REACTION:
  class={ toggle == 1 ? content-active : content }  // pada class ada ternary css
*/

import { useState } from "react";

export default function Users() {
  const [toggle, setToggle] = useState(1);
  return (
    <>
      {/* sementara, hapus ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>>  */}
      <div className="card mt-4 bg-yellow-300 text-red-900">
        <b>Contoh Todo List, silahkan Copas!</b>
        <ul>
          <li>Jumbotron</li>
          <li>
            pada table kanan bisa menyesuaikan tiap baris dan akan melakukan
            request ke root &gt; selection table event
          </li>
          <li>
            status request: terkirim, menunggu, di tolak, timeout (1 minggu),
          </li>
          <li>modal: hanya ubah harga saja send request</li>
        </ul>
      </div>
      {/* end sementara, hapus ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>> ------ >>>>>  */}
      <code>
        <div className="card">
          shortcut vs code tools - buka folder project ke vscode via terminal
          buka terminal -- super + t / ctrl + alt + t :-- cd folder tujuan -- ls
          -- .code - ctrl+` atau bisa ctrl+j : terminal. ` - ctrl+, : setting
          vscode, misalnya aktifkan formatter on save - ctrl+k+s : daftar
          shortcut text - ctrl+k : uppercase - : lowercase cursor -
          alt+shift+arrow : tambah cursor keyboard - alt+klik : tambah cursor
          mouse - ctrl+enter : enter cursor tanpa jatuhkan baris -
          ctrl+shift+enter : cursor naik diatasnya dan bikin baris kosong - :
          home, end pindah baris - alt+arrow : pindah baris - ctrl+alt+shift :
          duplicate - ctrl+x : cut line(empty selection) - ctrl+c : copy
          line(empty selection) - ctrl+delete : hapus satu kata - ctrl+shift+k :
          hapus satu baris selection - ctrl+d : seleksi satu kata di cursor --
          kalau berulang seleksi kata yang sama - ctrl+l : selecsi satu baris di
          cursor -- kalau berulang seleksi baris berikutnya Navigasi folder -
          ctrl+shift+e : membuka file sidebar - ctrl+p -- nama file : mencari
          file dari folder2 kita di sidebar - ctrl+p -- ctrl+shift+o -- @nama :
          mancari method, variabel, array, obj dll dalam halaman bersangkutan
          saja - ctrl+p+t -- #nama : mancari method, variabel, array, obj dll
          dalam semua halaman dalam project bahkan dalam framework - ctrl+p --
          :15 : menuju kebaris 15 - ctrl+tab : pindah tab butuh riset lagi
          dengan vscode -- help -- keyboard shortcut reference
        </div>
        <div className="card tab">
          <button
            className={toggle == 1 ? "bg-blue-200" : "bg-blue-50"}
            onClick={() => setToggle(1)}
          >
            tab - 1
          </button>
          <button
            className={toggle == 2 ? "bg-blue-200" : "bg-blue-50"}
            onClick={() => setToggle(2)}
          >
            tab - 2
          </button>
          <button
            className={toggle == 3 ? "bg-blue-200" : "bg-blue-50"}
            onClick={() => setToggle(3)}
          >
            tab - 3
          </button>
          <article className={toggle == 1 ? "block" : "hidden"}>
            tab1 Tulisan ku satu
          </article>
          <article className={toggle == 2 ? "block" : "hidden"}>
            tab2 Tulisan ku duaa
          </article>
          <article className={toggle == 3 ? "block" : "hidden"}>
            tab3 Tulisan ku tiga
          </article>
        </div>

        {/* ------------------------------ */}
        <div className="card">
          <h5>Catatan Fitur:</h5>
          <li>restart mikrotik</li>
          <ul>
            <li>periodic</li>
            <li>Manual</li>
            <li>auto restart saat ada traffic berhenti selama 15 menit</li>
            <li></li>
          </ul>
          <li>mikrotik</li>
          <ul>
            <li>Cek Apakah AP hidup atau tidak dengan netwatch</li>
            cek jumlah user aktif dengan flag nama router akses saat di aktifkan
            <li>
              pengecekan di lakukan setiap 30 menit sekali jam kantor 1 jam
              sekali jam diluar kantor
            </li>
            <li>eko martantoh bisa remote totolink di mikrotik</li>
            <li>
              terapkan khusus notifikasi sangat penting di tellegram(mini
              dashboard)
            </li>
            <li>Speedtest sebuah server &gt; periode 1 jam sekali </li>
            <li>baca semua judul2 di citraweb dan channel2 lainya</li>
            <li></li>
            <li>penerapan berikutnya</li>
            <ul>
              <li>Tanggal</li>
              <li>Root</li>
              <li>Lokasi</li>
              <li>Administrator</li>
              <li>Investor</li>
              <li>Filter</li>
            </ul>
          </ul>
        </div>
        {/* ------------------------------ */}
        <div className="card">
          <h5>Perancangan interface umum</h5>
          <ul>
            <li>nav umum</li>
            <li>navigasi session:</li>
            <ul>
              <li>users account</li>
              <li>root location</li>
              <li>tanggal</li>
              <li>paket kategori</li>
              <li>kategori</li>
            </ul>
            <li>Navigasi Items root</li>
            <li>Navigasi otorization (hidden/show,enable/disable)</li>
            <ul>
              <li>root</li>
              <li>superadmin</li>
              <li>admin</li>
              <li>seller</li>
              <li>enduser</li>
            </ul>
          </ul>
        </div>
        {/* ------------------------------ */}
        <div className="card">
          <h5>Catatan:</h5>
          <ul>
            <li>sumberdata:</li>
            <ul>
              <li>umum</li>
              <li>per page</li>
              <li>bikin alur</li>
              <li>design db</li>
              <li>
                slice 40 row data(supaya query tidak terlalu berat lakukan
                pembatasan pengambilan data 40 baris terbaru)
              </li>
              <li>
                ada toggle pengambilan data secara keseluruhan default 40 baris
              </li>
            </ul>
            <li>interface:</li>
            <ul>
              <li className="text-red-600 bg-yellow-100 font-bold">alur</li>
              <li className="text-red-600 bg-yellow-100 font-bold">
                bahasa diksi
              </li>
              <li>admin</li>
              <li>
                implementasi grid sistem dan responsive &#8680; copas layout
                dari documentasi lalu masukkan element
              </li>
            </ul>
            <li>Modals:</li>
            <ul>
              <li>Umum</li>
              <li>Per Page</li>
            </ul>
            <li>Client Componen NextJs</li>
            <ul>
              <li>useEffect</li>
              <li>cache</li>
              <li>modal dan form</li>
              <li>pelajari next lagi</li>
            </ul>
          </ul>
        </div>

        {/* ------------------------------- */}
        <div className="card">
          <h5>TodoList Sedang berjalan</h5>
          <ul>
            <li>tambahan</li>
            <ul>
              <li className="text-teal-700 bg-teal-100 font-bold">
                pada server root bisa add root wilayah dan juga pengurusnya,
                jadi ada tab <q>wilayah</q> dan tab <q>admin</q>
              </li>
              <li className="text-teal-700 bg-teal-100 font-bold">
                perbaikan diksi jumbotron
              </li>
              <li>Evaluasi cara kerja root Super Admin admin </li>
              <ul>
                <li>generate super admin</li>
              </ul>
            </ul>
          </ul>
        </div>
      </code>
    </>
  );
}
