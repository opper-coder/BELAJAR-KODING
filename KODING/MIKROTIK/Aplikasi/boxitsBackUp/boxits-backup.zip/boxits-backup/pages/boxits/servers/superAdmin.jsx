import { useState } from "react";
import { Message } from "primereact/message";
import { ListBox } from "primereact/listbox";
import RootTreeServer from "@/boxitsComp/Server/RootTreeServer";
import ServerAP from "@/boxitsComp/Server/ServerAP";
import ApOffLine from "@/boxitsComp/serverX/ApOffLine";
import ServerOffLine from "@/boxitsComp/Server/ServerOffLine";
import AddServer from "@/boxitsComp/Server/AddServer";
import DeleteServer from "@/boxitsComp/Server/DeleteServer";
import DeleteAP from "@/boxitsComp/Server/DeleteAP";
import PermissionRoot from "@/boxitsComp/Server/PermissionRoot";
import AllServer from "@/boxitsComp/Server/AllServer";
import AllAP from "@/boxitsComp/Server/AllAP";
import JumbotronSA from "@/boxitsComp/Server/JumbotronSA";

export default function SuperAdmin() {
  const [selectedMenu, setSelectedMenu] = useState("Active");
  const [judulMenu, setJudulMenu] = useState("Active");

  const cities = [
    { name: "Add req Server", code: "PRS" },
    { name: "Active", code: "NY" },
    { name: "Server Off", code: "LDN" },
    { name: "AP Off", code: "IST" },
    { name: "Del Server", code: "PRS" },
    { name: "Del AP", code: "PRS" },
    { name: "All Server", code: "PRS" },
    { name: "All AP", code: "PRS" },
  ];

  const TampilkanHalaman = (menu) => {
    switch (menu) {
      case "Active":
        return (
          <>
            <ServerAP />
          </>
        );
        break;
      case "Server Off":
        return (
          <>
            <ServerOffLine />
          </>
        );
        break;
      case "AP Off":
        return (
          <>
            <ApOffLine />
          </>
        );
        break;
      case "Add Server":
        return (
          <>
            <AddServer />
          </>
        );
        break;
      case "Del Server":
        return (
          <>
            <DeleteServer />;
          </>
        );
        break;
      case "Del AP":
        return (
          <>
            <DeleteAP />;
          </>
        );
        break;
      case "All Server":
        return (
          <>
            <AllServer />;
          </>
        );
        break;
      case "All AP":
        return (
          <>
            <AllAP />;
          </>
        );
        break;
      default:
        return (
          <>
            <ServerAP />
          </>
        );
    }
  };

  const judul = (classwarna, jumlah, judul) => {
    return (
      <>
        <Message
          severity={classwarna}
          className="w-full justify-content-start px-4 mb-2"
          content={
            <div className="ml-2">
              {judul}
              <b>{jumlah}</b>
            </div>
          }
        />
      </>
    );
  };

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className="pi pi-bookmark mr-3"></i>
        <div>{option.name}</div>
      </div>
    );
  };

  const MenuServer = () => {
    return (
      <>
        <ListBox
          value={selectedMenu}
          onChange={(e) => {
            setSelectedMenu(e.value);
            setJudulMenu(e.value.name);
          }}
          options={cities}
          optionLabel="name"
          className="w-full md:w-14rem"
          itemTemplate={countryTemplate}
        />
      </>
    );
  };

  return (
    <>
      <JumbotronSA />
      <PermissionRoot />
      <div className="card flex gap-2">
        <RootTreeServer />
        {/* <AdminTreeDynamic /> */}
        <div>
          {judul("info", "", judulMenu)}
          <MenuServer />
        </div>
        <div className="flex-1 ">
          {judul("info", "", "Daftar status Server")}
          <div className="card">{TampilkanHalaman(judulMenu)}</div>
        </div>
      </div>
    </>
  );
}
