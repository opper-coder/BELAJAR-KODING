
export default function Investor() {
  return (
    <div>
      dashboard investor
    </div>
  )
}
