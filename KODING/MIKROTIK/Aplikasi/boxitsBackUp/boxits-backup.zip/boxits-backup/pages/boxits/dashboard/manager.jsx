export default function Manager() {
  return (
    <>
      <div className="card bg-yellow-300 text-blue-800">
        <b>Fungsi utama</b>
        <ul>
          <li>performa mesin</li>
          <li>performa pejualan</li>
          <li>performa pembiayaan</li>
          <li>kategori User monitoring</li>
        </ul>
        <b>Performa mesin</b>
        <ul>
          <li>lokasi operasional</li>
          <li>ISP aktif</li>
          <li>server aktif</li>
          <li>AP aktif</li>
          <li>user aktif</li>
          <li>remote</li>
        </ul>
        <b>Performa Penjualan</b>
        <ul>
          <li>modal</li>
          <li>product</li>
          <li>biaya</li>
          <li>gaji</li>
          <li>insentif</li>
          <li>porsi</li>
        </ul>
        <b>Assets</b>
        <ul>
          <li>alat wajib server</li>
          <li>alat habis pakai</li>
          <li>peralatan/tools</li>
          <li>sarana</li>
          <li>fasilitas</li>
        </ul>
      </div>
    </>
  );
}
