// import HargaDasarPaketProjectPenyesuaian from "@/boxitsComp/price/HargaDasarPaketAdminPenyesuaian";
// import HargaDasarPaketProject from "@/boxitsComp/price/HargaDasarPaketProject";
// import { Message } from "primereact/message";
// import Capital from "@/boxitsComp/voucher/capital";
// import Activity from "@/boxitsComp/voucher/activity";
// import RootSideMenu from "@/boxitsComp/inventory/rootSideMenu";
// import OwnerMenu from "@/boxitsComp/inventory/ownerMenu";
// import PriceProductPenyesuaian from "@/boxitsComp/price/priceProductPenyesuaian";
// import PriceProduct from "@/boxitsComp/price/priceProduct";
// import PricePacket from "@/boxitsComp/price/pricePacket";
// import PricePacketPenyesuaian from "@/boxitsComp/price/pricePacketPenyesuaian";
// import PriceEquipmentP from "@/boxitsComp/price/priceEquipmentP";
// import PriceEquipment from "@/boxitsComp/price/priceEquipment";

import { TabView, TabPanel } from "primereact/tabview";
import AdminTree from "@/boxitsComp/users/adminTree";
import MenuInventory from "@/boxitsComp/inventory/menuInventory";
import RootSideMenuProduct from "@/boxitsComp/price/rootSideMenuProduct";
import VoucherRulesJumbotron from "../../../boxitsComp/price/voucherRulesJumbotron";
import RootSideMenuPacket from "@/boxitsComp/price/rootSideMenuPacket";

export default function Root() {
  return (
    <>
      <VoucherRulesJumbotron />
      <div className="mt-4">
        <TabView>
          <TabPanel header="Product">
            <div className="flex gap-2">
              <AdminTree />
              <RootSideMenuProduct />
              {/* <OwnerMenu /> */}
              {/* <RootSideMenu /> */}
            </div>
          </TabPanel>
          <TabPanel header="Packet">
            <div className="flex gap-2">
              <AdminTree />
              <RootSideMenuPacket />
            </div>
          </TabPanel>
          <TabPanel header="Equipment">
            <div className="flex gap-2">
              <AdminTree />
              <MenuInventory />
            </div>
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
