import ServerJumbotron from "@/boxitsComp/serverX/serverJumbotron";
import ServerServer from "@/boxitsComp/serverX/serverServer";

export default function Server() {
  return (
    <>
      <ServerJumbotron />
      <div className="flex gap-2">
        <ServerServer />
      </div>
    </>
  );
}

/*

items 
1. add server mikrotik
2. list mikrotik
3. add router
4. list router
5. assign to root
6. server root

UI
+ root server dan router 



*/
