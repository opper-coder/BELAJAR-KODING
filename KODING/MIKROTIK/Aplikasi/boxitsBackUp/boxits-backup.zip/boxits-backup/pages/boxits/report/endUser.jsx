import RecapEndUser from "@/boxitsComp/report/endUser/RecapEndUser";
import RootTreeServer from "@/boxitsComp/report/endUser/RootTreeServer";
import JumbotronEndUser from "@/boxitsComp/report/endUser/jumbotronEndUser";
import Transaction from "@/boxitsComp/report/endUser/transaction";
import { Button } from "primereact/button";
import { Image } from "primereact/image";
import { Message } from "primereact/message";
import { TabView, TabPanel } from "primereact/tabview";

// const properties = [
//   { field: "nama", isi: "aqil" },
//   { field: "alamat", isi: "saiti" },
//   { field: "bank", isi: "bri" },
//   { field: "rek", isi: "121212" },
//   { field: "hp", isi: "081333444777" },
//   { field: "tgl Register", isi: "12/1/2023" },
//   { field: "login sejak", isi: "6 bulan" },
//   { field: "total amount", isi: "3000000" },
// ];

export default function EndUser() {
  const judul = (classwarna, jumlah, judul) => {
    return (
      <>
        <Message
          severity={classwarna}
          className="w-full justify-content-start px-4"
          content={
            <div className="ml-2 ">
              {judul}: <b>Rp. {jumlah}</b>
            </div>
          }
        />
      </>
    );
  };

  return (
    <>
      <JumbotronEndUser />
      <div className="flex gap-2">
        {judul("success", "40.000.000", "Debet: ")}
        {judul("info", "20.000.000", "Kredit: ")}
      </div>
      <div className=" flex gap-2 mt-2">
        <RootTreeServer />

        <div className="card flex-1">
          <TabView>
            <TabPanel header="Properties">
              <div className="flex gap-2">
                <div className="card flex justify-content-center">
                  <Image src="/gambar/user.png" alt="Image" width="100" />
                </div>
                <div className="card flex-1 flex">
                  <ul className="list-none" style={{ width: "20%" }}>
                    <li className="mb-2">Nama</li>
                    <li className="mb-2">Alamat</li>
                    <li className="mb-2">Bank</li>
                    <li className="mb-2">Rekening</li>
                    <li className="mb-2">Hp</li>
                    <li className="mb-2">Tanggal register</li>
                    <li className="mb-2">Login Sejak</li>
                    <li className="mb-2">Total amount</li>
                    <Button label="Properties" text className="mt-4" />
                  </ul>
                  <ul className="list-none">
                    <li className="mb-2 capitalize font-bold">: hamrin</li>
                    <li className="mb-2 capitalize font-bold">: saiti</li>
                    <li className="mb-2 capitalize font-bold">: bri</li>
                    <li className="mb-2 capitalize font-bold">: 121212</li>
                    <li className="mb-2 capitalize font-bold">
                      : 081333444777
                    </li>
                    <li className="mb-2 capitalize font-bold">: 12/1/2023</li>
                    <li className="mb-2 capitalize font-bold">
                      : 6 bulan lalu
                    </li>
                    <li className="mb-2 capitalize font-bold">: 3000000</li>
                  </ul>
                </div>
              </div>
            </TabPanel>
            <TabPanel header="Transaction">
              <Transaction />
            </TabPanel>
          </TabView>
        </div>
      </div>
    </>
  );
}
