import AdminRoot from "@/boxitsComp/serverX/adminRoot";
import AdminJumbotron from "@/boxitsComp/serverX/Adminjumbotron";

export default function SuperAdmin() {
  return (
    <>
      <AdminJumbotron />
      <AdminRoot />
    </>
  );
}
