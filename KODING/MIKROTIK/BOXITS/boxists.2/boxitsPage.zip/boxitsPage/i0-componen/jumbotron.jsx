/* eslint-disable react/jsx-key */
import { Card } from "primereact/card";

/*
CONFIG:
  // jumbotron ----->
  const propsJumbo = {
    title: "User",
    subtitle: "Managemen Users, Hirarki, Autentikasi, Authority",
    column1: [
      "For Root Admin",
      "Generate Main Capital",
      "Generate Main Price Product",
      "Generate Main Price Packet",
    ],
    column2: [
      "Transfer Capital",
      "Response Capital",
      "View All Transfer Type",
      "Connected with report",
    ],
  };

CALL:

<Jumbotron proper={propsJumbo} />

*/

export default function Jumbotron(props) {
  return (
    <>
      <Card
        title={props.proper.title}
        subTitle={props.proper.subtitle}
        className="mb-4 surface-300 "
      >
        <div className="flex">
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              {props.proper.column1.map((a) => (
                <li>{a}</li>
              ))}
            </ul>
          </div>
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              {props.proper.column2.map((a) => (
                <li>{a}</li>
              ))}
            </ul>
          </div>
          <div className="flex-1">
            <ul className="text-blue-700 m-0">
              {props.proper.column3.map((a) => (
                <li>{a}</li>
              ))}
            </ul>
          </div>
        </div>
      </Card>
    </>
  );
}
