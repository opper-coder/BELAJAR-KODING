import { useRef, useState, useEffect } from "react";
import { ConfirmDialog, confirmDialog } from "primereact/confirmdialog";
import { Toast } from "primereact/toast";

export default function ModalActive(props) {
  /*
  CARA PANGGIL
  // MODAL ACTIVATE CONFIRM ----------------
  const [activate, setActivate] = useState(false);
  const properActivate = {
    activate: activate,
    row: selectedProduct?.name, // nama data yang mau di activate
    tutup: (d) => setActivate(d),
  };
  
  useEffect(() => {
    setSelectedProduct(null);
  }, [activate]);
  // -----------------------
  <ModalActive proper={properActivate} />
  */

  const toast = useRef(null);
  const [tutup, setTutup] = useState(false);

  const accept = () => {
    toast.current.show({
      severity: "info",
      summary: "Confirmed",
      detail: "You have accepted",
      life: 3000,
    });
    setTutup(false);
  };

  const reject = () => {
    toast.current.show({
      severity: "warn",
      summary: "Rejected",
      detail: "You have rejected",
      life: 3000,
    });
    setTutup(false);
  };

  const activate = () => {
    confirmDialog({
      message: `Do you want to Activate ${props.proper.row}?`,
      header: "Activate Confirmation",
      icon: "pi pi-info-circle",
      acceptClassName: "p-button-success",
      accept,
      reject,
    });
  };
  useEffect(() => {
    props.proper.tutup(tutup);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props]);

  return (
    <>
      <Toast ref={toast} />
      <ConfirmDialog />
      {props.proper.activate === true ? activate() : null}
    </>
  );
}
