/* eslint-disable react-hooks/exhaustive-deps */
/* 
FUNGSI:
Tabel dinamis: data, kolom, baris, contex menu list , state selected rows (id data nya),

PENGATURAN CALLER:
0. di file sumber ini, no config.
1. COPAS: code ini di halaman pemanggil ubah nama functions
2. EDIT: ubah sumber db, baris, kolom, contex, state contex, sesuai keinginan.
----------------------------------------

import TableDynamic from "../../i0-componen/tableDynamic";
import { useState, useEffect } from "react";
import { BoxitsDb } from "../../i0-componen/data/BoxitsDb";

export default function PageRegion() {
  const [sumberData, setSumberData] = useState([]);
  const [listContex, setListContex] = useState([]);

  useEffect(() => {
    BoxitsDb.getProducts().then((data) =>
      setSumberData(data[0]["items"][0]["items"])
    );
  }, []);

  const propsTable = {
    db: sumberData,
    baris: 9,
    satu: (data) => setListContex(data),
    columns: [
      { field: "name", header: "Nama" },
      { field: "userId", header: "UserId" },
      { field: "password", header: "Password" },
    ],
    contex: [
      {
        label: "Edit",
        icon: "pi pi-fw pi-pencil",
        command: () => popup(),
      },
      {
        label: "Delete",
        icon: "pi pi-fw pi-trash",
        command: () => popup(),
      },
    ],
  };

  const popup = () => {
    // ambil data dari db mis: "listContex.id" ngambil ID untuk proses selanjutnya
    alert(listContex.name);
  };

  return (
    <>
      <TableDynamic tabel={propsTable} />
    </>
  );
}
*/

import { useState, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ContextMenu } from "primereact/contextmenu";

export default function TableDynamic(props) {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const cm = useRef(null);

  return (
    <div className="w-full">
      <ContextMenu
        model={props.tabel.contex}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={props.tabel.db}
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => {
          setSelectedProduct(e.value);
          props.tabel.satu(e.value);
        }}
        size="small"
        stripedRows
        paginator
        rows={props.tabel.baris}
        tableStyle={{ minWidth: "25rem" }}
        resizableColumns
        columnResizeMode="expand"
      >
        {props.tabel.columns.map((col, i) => (
          <Column
            key={col.field}
            field={col.field}
            header={col.header}
            sortable
          />
        ))}
      </DataTable>
    </div>
  );
}
