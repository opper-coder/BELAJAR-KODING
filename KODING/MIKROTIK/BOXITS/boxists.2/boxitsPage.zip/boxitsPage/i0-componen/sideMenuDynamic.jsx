/*
KETERANGAN:
1. FILE: no config disini.
2. COPAS: keterangan ini ke halaman pemanggila, ubah nama komponen, dan ubah isi menu.
3. error: jika stateSideMenu = null tampilkan (halaman kuning misalnya) (yaitu saat toggle)
// ----------------------------------------------------
*/
/* 
import { useState } from "react";
import SideMenuDynamic from "../i0-componen/sideMenuDynamic";

export default function Product() {
  const [stateSideMenu, setStateSideMenu] = useState();
  const propSideMenu = {
    default: "",
    operStateSideMenu: (data) => setStateSideMenu(data),
    list: [
      { name: "Servers", icon: "pi pi-user mr-3" },
      { name: "Mapping", icon: "pi pi-map-marker mr-3" },
      { name: "Maintenance", icon: "pi pi-wrench mr-3" },
    ],
  };

  const tampilHalaman = (d) => {
    if (d !== undefined) {
      return <div className="card w-full">Tampil halaman asli</div>;
    } else {
      return (
        <div className="card w-full bg-yellow-100">
          Tampilkan data dengan klik <b>Sidemenu</b> di samping
        </div>
      );
    }
  };

  return (
    <>
      <div className="flex gap-2">
        <SideMenuDynamic proper={propSideMenu} />
        {tampilHalaman(stateSideMenu)}
      </div>
    </>
  );
}
*/

import { useState } from "react";
import { ListBox } from "primereact/listbox";

export default function SideMenuDynamic(props) {
  const [selectedCountry, setSelectedCountry] = useState({
    name: props.proper.default,
  });

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
      </div>
    );
  };

  props.proper.operStateSideMenu(selectedCountry?.name);

  return (
    <div className="flex justify-content-center">
      <ListBox
        value={selectedCountry}
        onChange={(e) => setSelectedCountry(e.value)}
        options={props.proper.list}
        optionLabel="name"
        itemTemplate={countryTemplate}
        className="w-full md:w-14rem"
      />
    </div>
  );
}
