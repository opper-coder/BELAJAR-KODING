// import { TransactionDb } from "./data/TransactionDb";

// export default function Accounting(props) {
// export const Accounting = {
//   a: "alamat",
//   b: "badut",
// saldo: TransactionDb.getCustomersXLarge().then((d) => {
//   let total = 0;
//   for (let i = 0; i < d.length; i++) {
//     if (d[i].name === "20jt") {
//       continue;
//     }
//     total += d[i].price;
//   }
//   return total;
//   console.log(total);
// }),
// };

// closeAutoMonthly() {
//   queryfilterIn: [
//     "flowIn",
//     "seller_id",
//     "jabatan",
//     "region",
//     "month_of",
//     "approve",
//   ];
//   queryfilterOut: [
//     "flowOut",
//     "seller_id",
//     "jabatan",
//     "region",
//     "month_of",
//     "approve",
//   ];
//   queryfilterWithDraw: [
//     "flowWith",
//     "seller_id",
//     "jabatan",
//     "region",
//     "month_of",
//     "approve",
//   ];
//   ("in - out - withDraw");
// },
// currentReport() {
//   queryfilterIn: ["flowIn", "penjual", "jabatan", "lokasi", "bulanke"];
//   queryfilterOut: ["flowOut", "penjual", "jabatan", "lokasi", "bulanke"];
//   ("in - out");
// }

//   return <>INI ACCOUNTING</>;
// }

// =======================================================
