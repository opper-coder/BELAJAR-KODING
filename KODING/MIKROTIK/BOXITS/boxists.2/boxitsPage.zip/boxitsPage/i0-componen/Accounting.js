export default function Accounting(props) {
  // closeAutoMonthly() {
  //   queryfilterIn: [
  //     "flowIn",
  //     "seller_id",
  //     "jabatan",
  //     "region",
  //     "month_of",
  //     "approve",
  //   ];
  //   queryfilterOut: [
  //     "flowOut",
  //     "seller_id",
  //     "jabatan",
  //     "region",
  //     "month_of",
  //     "approve",
  //   ];
  //   queryfilterWithDraw: [
  //     "flowWith",
  //     "seller_id",
  //     "jabatan",
  //     "region",
  //     "month_of",
  //     "approve",
  //   ];
  //   ("in - out - withDraw");
  // },
  // currentReport() {
  //   queryfilterIn: ["flowIn", "penjual", "jabatan", "lokasi", "bulanke"];
  //   queryfilterOut: ["flowOut", "penjual", "jabatan", "lokasi", "bulanke"];
  //   ("in - out");
  // }
  return <>INI ACCOUNTING</>;
}
