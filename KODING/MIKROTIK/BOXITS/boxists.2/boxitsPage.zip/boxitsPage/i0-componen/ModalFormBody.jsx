/*
// MODAL FORM BODY -----------------------------
 // MODAL FORM BODY -----------------------------
  const [modalFormBody, setModalFormBody] = useState(false);
  const properModalFormBody = {
    modal: modalFormBody,
    judul: "Add Administrator",
    tombol: "Add Official",
    width: "30vw",
    warna: "success", // prymary, success, danger, warning, info
    modalTutup: (d) => setModalFormBody(d),
    content: (
      <ModalContentFormBody
        terpilih={selectedProduct}
        bodi={"Apakah anda akan Menyetujui Transaksi ini senilai"}
      />
    ),
  };
// ----------------------------------------

<ModalForm proper={properModalFormBody} />
<Button
    // ini triggernya
    onClick={() => setModalFormBody(true)}
    label={properModal.tombol}
/>
*/

import { useState, useEffect } from "react";
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";

export default function ModalFormBody(props) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(props.proper.modal);
  }, [props.proper.modal]);

  const footerContent = (
    <div>
      <Button
        label="No"
        icon="pi pi-times"
        onClick={() => props.proper.modalTutup(false)}
        className="p-button-outlined"
        // className="p-button-text"
      />
      <Button
        label="Yes"
        icon="pi pi-check"
        onClick={() => props.proper.modalTutup(false)}
        severity={props.proper.warna}
        // severity="success"
        // autoFocus
      />
    </div>
  );

  return (
    <>
      <Dialog
        header={props.proper.judul}
        visible={visible}
        onHide={() => props.proper.modalTutup(false)}
        style={{ width: props.proper.width }}
        breakpoints={{ "960px": "75vw", "641px": "100vw" }}
        footer={footerContent}
      >
        {props.proper.content}
      </Dialog>
    </>
  );
}
