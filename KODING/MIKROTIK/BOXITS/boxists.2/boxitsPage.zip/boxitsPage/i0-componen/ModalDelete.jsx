import { useRef, useState, useEffect } from "react";
import { ConfirmDialog, confirmDialog } from "primereact/confirmdialog";
import { Toast } from "primereact/toast";

export default function ModalDelete(props) {
  /*
  // MODAL DELETE CONFIRM ----------------
  const [hapus, setHapus] = useState(false);
  const properHapus = {
    hapus: hapus,
    row: selectedProduct?.name, // nama data yang mau di hapus
    tutup: (d) => setHapus(d),
  };
  
  // karena untuk keperluan klik kanan maka data klik kanan harus di hapus saat selesai
  useEffect(() => {
    setSelectedProduct(null);
  }, [hapus]);
  // -----------------------
  // import komponen utama modal hapus setelah return 
  <ModalConfirm proper={properHapus} />
  // pada klik kanan trigger pakai ini 
  command: () => setHapus(true),
  */

  const toast = useRef(null);
  const [tutup, setTutup] = useState(false);

  const accept = () => {
    toast.current.show({
      severity: "info",
      summary: "Confirmed",
      detail: "You have accepted",
      life: 3000,
    });
    setTutup(false);
  };

  const reject = () => {
    toast.current.show({
      severity: "warn",
      summary: "Rejected",
      detail: "You have rejected",
      life: 3000,
    });
    setTutup(false);
  };

  const hapus = () => {
    confirmDialog({
      message: `Do you want to delete ${props.proper.row}?`,
      header: "Delete Confirmation",
      icon: "pi pi-info-circle",
      acceptClassName: "p-button-danger",
      accept,
      reject,
    });
  };

  useEffect(() => {
    props.proper.tutup(tutup);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props]);

  return (
    <>
      <Toast ref={toast} />
      <ConfirmDialog />
      {props.proper.hapus === true ? hapus() : null}
      {props.proper.activate === true ? activation() : null}
    </>
  );
}
