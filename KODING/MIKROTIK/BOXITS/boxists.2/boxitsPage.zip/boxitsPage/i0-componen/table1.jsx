import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { CustomerService } from "./data/CustomerService";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";

export default function Table1(props) {
  const [customers, setCustomers] = useState([]);

  useEffect(() => {
    CustomerService.getCustomersMedium().then((data) => setCustomers(data));
  }, []);

  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "View",
      icon: "pi pi-fw pi-search",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-times",
      command: () => viewProduct(selectedProduct),
    },
  ];

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  return (
    <div>
      <p>
        ini ada props data: <b className="text-red-500">{props.satu}</b> sub
        data<b className="text-red-500"> {props.dua} </b>
        periksa apakah isi tabel juga berubah saat di pangil
      </p>
      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <Toast ref={toast} />
      <DataTable
        value={customers}
        paginator
        stripedRows
        rows={12}
        // tableStyle={{ minWidth: "50rem" }}
        size="small"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
      >
        <Column
          field="name"
          header="Name"
          // style={{ width: "25%" }}
          sortable
        ></Column>
        <Column
          sortable
          field="country.name"
          header="Country"
          // style={{ width: "25%" }}
        ></Column>
        <Column
          sortable
          field="company"
          header="Company"
          // style={{ width: "25%" }}
        ></Column>
        <Column
          sortable
          field="representative.name"
          header="Representative"
          style={{ width: "25%" }}
        ></Column>
      </DataTable>
    </div>
  );
}
