/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable react-hooks/exhaustive-deps */

/* 
FUNGSI:
Tabel dinamis: data, kolom, baris, contex menu list , state selected rows (id data nya), dan switch data pada multi

PENGATURAN CALLER:
0. sama dengan tableDynamic sebelumnya tapi ada tambahan "switch database"
1. copas code ini di halaman pemanggil ubah nama functions
2. ubah sumber db, baris, kolom, contex, state contex, dan swicth data tabel, sesuai keinginan.
3. poin terpenting adalah stateTabel ?????????
----------------------------------------
*/

/*
import TableDynamic from "../../i0-componen/tableDynamic";
import { useState, useEffect } from "react";
import { BoxitsDb } from "../../i0-componen/data/BoxitsDb";

export default function PageRegion(props) {
  const [sumberData, setSumberData] = useState([]);
  const [listContex, setListContex] = useState([]);
  const [menuSelected, setMenuSelected] = useState();
  const [isiTabel, setIsiTabel] = useState();

  useEffect(() => {
    BoxitsDb.getProducts().then((data) => setSumberData(data));
  }, []);

  const propsTable = {
    db: isiTabel,
    baris: 9,
    satu: (data) => setListContex(data),
    columns: [
      { field: "name", header: "Nama" },
      { field: "quantity", header: "Jumlah" },
      { field: "code", header: "Kode" },
    ],
    contex: [
      {
        label: "satu",
        icon: "pi pi-fw pi-box",
        command: () => popup(),
      },
      {
        label: "dua",
        icon: "pi pi-fw pi-question",
        command: () => popup(),
      },
    ],
  };

  const popup = () => {
    // ambil ID pada baris tabel, disini untuk proses selanjutnya
    alert(listContex.name);
  };

  // pilih isiTabel saat "menuSelected" berubah (ada simulasi tombol di bawah)
  useEffect(() => {
    switch (menuSelected) {
      case "satu":
        setIsiTabel(sumberData[0]["items"]);
        break;
      case "dua":
        setIsiTabel(sumberData[1]["items"]);
        break;
      default:
        setIsiTabel(sumberData);
        break;
    }
  }, [menuSelected]);

  return (
    <>
      <button onClick={() => setMenuSelected("satu")}>Satu</button>
      <button onClick={() => setMenuSelected("dua")}>Dua</button>
      <TableDynamic tabel={propsTable} />
    </>
  );
}
*/

import { useState, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ContextMenu } from "primereact/contextmenu";

export default function TableDynamic2(props) {
  const [selectedProduct, setSelectedProduct] = useState(null);
  const cm = useRef(null);

  return (
    <div className="w-full">
      <ContextMenu
        model={props.tabel.contex}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={props.tabel.db}
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => {
          setSelectedProduct(e.value);
          props.tabel.satu(e.value);
        }}
        size="small"
        stripedRows
        paginator
        rows={props.tabel.baris}
        tableStyle={{ minWidth: "40rem" }}
      >
        {props.tabel.columns.map((col, i) => (
          <Column
            key={col.field}
            field={col.field}
            header={col.header}
            // sortable
          />
        ))}
      </DataTable>
    </div>
  );
}
