export const TransactionDb = {
  getData() {
    return [
      // {
      //   id: 999,
      //   category: "Product", // Project, Subscribe, Investor,
      //   super_admin_id: "said7865",
      //   region: "banggai laut",
      //   admin_id: null, // "aid98908"
      //   agency_id: null, // "agid898"
      //   seller_id: "ada", // "selid989"
      //   to_uid: "uid7679", // uid9898
      //   locate: "Banggai - Timbong",
      //   invoice: "inv122", // inv3243
      //   product: "capital", // capital, saldo, voucher, data, pppoe, promo // --------->
      //   date: "2024-01-10",
      //   month_of: 1, // untuk menghitung putaran bulan
      //   name: "20jt", // 20jt, sld2jt, vc2000, dt5000, pp150, pro2000, representasi harga
      //   price: 20000000,
      //   type: "send", // send req
      //   status: "delivered", // ready, wait, delivered, up, finish,    // -------->
      //   approve: true, // selesai
      //   flow: "in" // in, on, out, with // di gunakan untuk membedakan in= order out=jual on= process system selain jual atau order with=withDraw pencairan
      // },
      {
        id: 998,
        category: "product",
        super_admin_id: "ace",
        region: "banggai laut",
        admin_id: "alex",
        agency_id: null,
        seller_id: "apet",
        to_uid: "uid7679",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        product: "capital",
        date: "2024-01-10",
        month_of: 1,
        name: "20jt",
        price: 20000000,
        type: "send",
        status: "delivered",
        approve: true,
        flow: "out",
      },
      {
        id: 999,
        category: "product",
        super_admin_id: "said7865",
        region: "banggai laut",
        admin_id: null,
        agency_id: null,
        seller_id: "asas",
        to_uid: "uid7679",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        product: "voucher",
        date: "2024-01-10",
        month_of: 1,
        name: "30jt",
        price: 20000000,
        type: "send",
        status: "delivered",
        approve: false,
        flow: "out",
      },
      {
        id: 999,
        category: "product",
        super_admin_id: "said7865",
        region: "banggai",
        admin_id: null,
        agency_id: null,
        seller_id: "asas adda",
        to_uid: "uid7679",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        product: "voucher",
        date: "2024-01-10",
        month_of: 1,
        name: "30jt",
        price: 20000000,
        type: "send",
        status: "delivered",
        approve: false,
        flow: "out",
      },
    ];
  },

  getCustomersSmall() {
    return Promise.resolve(this.getData().slice(0, 10));
  },

  getCustomersMedium() {
    return Promise.resolve(this.getData().slice(0, 50));
  },

  getCustomersLarge() {
    return Promise.resolve(this.getData().slice(0, 200));
  },

  getCustomersXLarge() {
    return Promise.resolve(this.getData());
  },

  getCustomers(params) {
    const queryParams = params
      ? Object.keys(params)
          .map(
            (k) => encodeURIComponent(k) + "=" + encodeURIComponent(params[k])
          )
          .join("&")
      : "";

    return fetch(
      "https://www.primefaces.org/data/customers?" + queryParams
    ).then((res) => res.json());
  },
};
