export const TransactionDb = {
  getData() {
    return [
      // DESAIN ULANG FIELD

      // {
      //   id: 999,
      //   category: "Product", // Project, Subscribe, Investor,
      //   uid: "uid7679", // uid9898
      //   to_uid: "uid7679", // uid9898
      //   seller_id,
      //   admin_id: "alex",
      //   agency_id: null,
      //   seller_id: "apet",
      //   position: "admin", // melihat posisi
      //   region: "banggai laut",
      //   locate: "Banggai - Timbong",
      //   invoice: "inv122", // inv3243
      //   product: "capital", // capital, saldo, voucher, data, pppoe, promo // --------->
      //   name: "20jt", // 20jt, sld2jt, vc2000, dt5000, pp150, pro2000, representasi harga
      //   month_of: 1, // untuk menghitung putaran bulan
      //   week_off: 33, // putaran minggu ke
      //   date: "2024-01-10",  //
      //   price: 20000000,
      //   type: "send", // send req
      //   status: "delivered", // ready, wait, delivered, up, finish,    // -------->
      //   approve: true, // sudah ada di tabel periksa dulu
      //   flow: "in" // in, on, out, with // di gunakan untuk membedakan in= order out=jual on= process system selain jual atau order with=withDraw pencairan
      // },

      {
        id: 997,
        category: "product",
        position: "admin",
        super_admin_id: "ace",
        region: "banggai laut",
        admin_id: "alex",
        agency_id: null,
        seller_id: "apet",
        uid: "uid7679",
        to_uid: "uid7679",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        product: "voucher",
        date: "2024-01-11",
        month_of: 1,
        name: "20jt",
        price: 200,
        type: "send",
        status: "delivered",
        approve: true,
        flow: "in",
      },
      {
        id: 998,
        category: "product",
        position: "admin",
        super_admin_id: "ace",
        region: "banggai laut",
        admin_id: "alex",
        agency_id: null,
        seller_id: "apet",
        uid: "uid7679",
        to_uid: "uid7679",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        product: "voucher",
        date: "2024-01-10",
        month_of: 1,
        name: "20jt",
        price: 200,
        type: "send",
        status: "delivered",
        approve: true,
        flow: "out",
      },
      {
        id: 999,
        category: "product",
        position: "admin",
        super_admin_id: "said7865",
        region: "banggai laut",
        admin_id: null,
        agency_id: null,
        seller_id: "asas",
        uid: "uid7679",
        to_uid: "uid7679",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        product: "voucher",
        date: "2024-01-10",
        month_of: 1,
        name: "30jt",
        price: 200,
        type: "send",
        status: "delivered",
        approve: true,
        flow: "out",
      },
      {
        id: 1000,
        category: "product",
        position: "admin",
        super_admin_id: "said7865",
        region: "banggai laut",
        admin_id: null,
        agency_id: null,
        seller_id: "asas adda",
        uid: "uid7679",
        to_uid: "uid7679",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        product: "voucher",
        date: "2024-01-10",
        month_of: 1,
        name: "30jt",
        price: 300,
        type: "send",
        status: "delivered",
        approve: true,
        flow: "out",
      },
    ];
  },

  getCustomersSmall() {
    return Promise.resolve(this.getData().slice(0, 10));
  },

  getCustomersMedium() {
    return Promise.resolve(this.getData().slice(0, 50));
  },

  getCustomersLarge() {
    return Promise.resolve(this.getData().slice(0, 200));
  },

  getCustomersXLarge() {
    return Promise.resolve(this.getData());
  },

  getCustomers(params) {
    const queryParams = params
      ? Object.keys(params)
          .map(
            (k) => encodeURIComponent(k) + "=" + encodeURIComponent(params[k])
          )
          .join("&")
      : "";

    return fetch(
      "https://www.primefaces.org/data/customers?" + queryParams
    ).then((res) => res.json());
  },
};
