export const Accounting = {
  /*
getDataFilter()     -> fungsi ambildata db jadi object
getConvertArray()   -> kita bisa konversi pada field/key jadi array
getSumArray()       -> jumlahkan array nya
getLast()           -> ambil data terakhir 
getHari()           -> 
getTanggal()        -> 
getBulan()          -> 
getTahun()          -> 

getCapital          -> ambil capital untuk user terkait,
getSold             -> ambil terjual semua product 
getBonus            -> ambil 15% dari penjualan saat ini ke user bersangkutan
getPrive            -> prive adalah transaksi voucher ke seseorang yang yg tdk menggunakan biaya modal
getPromo            -> promo adalah transaksi voucher ke banyak orang yg tdk menggunakan biaya modal 
getSubscriber       -> adalah pembayaran yang dilakukan oleh agency tiap bulan untuk aktifasi menggunakan pemotongan saldo
getAutoSubs         -> subsidi subscribe 300rb

getExitMonth        -> AccIn - AccOut pd bulan ini kecuali promo, prive
getCurrent          -> saldo sekarang yang belum ditutup bulan
getDebet            -> sama
getKredit           -> semua penjualan selain promo dan prive dan subscriber

getPorsion          -> Gaji sekarang
getWithDraw         -> Transaksi pencairan

getAdd              -> 
getSell             -> 
getEdit             -> 
getFrezze           -> 
getBanned           -> 
getActivate         -> 
getDelete           -> 
getApprove          -> 
getVerifi           -> 
getReject           -> 
getBalance          -> 

getResi             -> 
*/

  /*  Contoh saja-------------------- */
  haloAccounting() {
    return <>INI METHOD ACCOUNTING</>;
  },

  /* 
AMBIL DATA TERFILTER 
-------------------------------------
  useEffect(() => {
    (async () => {
      try {
        // ambil data disini, import Dulu ya
        const data = await TransactionDb.getCustomersXLarge();
        const hasilFilter = await Accounting.getDataFilter(
          // filter
          {
            category: "product",
            product: "voucher",
          },
          // hasilnya object
          data
        );
        // aksi sini silahkan
        console.log("Data setelah difilter:", hasilFilter);
      } catch (error) {
        console.error(error.message);
      }
    })();
  }, []);
  -------------------------------------
  */

  async getDataFilter(kondisi, data) {
    try {
      const hasilFilter = data.filter((item) =>
        Object.entries(kondisi).every(([key, value_1]) => item[key] === value_1)
      );

      return hasilFilter;
    } catch (error) {
      console.error("Terjadi kesalahan:", error);

      return 0;
    }
  },

  /* AMBIL DATA DR SUMBER YG KITA TENTUKAN TERFILTER DAN TERAKHIR BERDASAR TANGGAL
  --------------------------------------------------------------------------------
  // Contoh Call fungsi getLast tinggal kamu import db yang kamu pilih aja dan panggil db nya pada transactions
  useEffect(() => {
    (async () => {
      try {
        // ambil data disini, import Dulu ya
        const transactions = await TransactionDb.getCustomersXLarge();
        const lastTransactionFiltered = await Accounting.getLast(
          // filter
          {
            category: "product",
            position: "admin",
          },
          transactions
        );
        // hasilnya satu data terakhir secara tanggal
        console.log(
          "Satu Data terakhir setelah difilter:",
          lastTransactionFiltered
        );
      } catch (error) {
        console.error(error.message);
      }
    })();
  }, []);
  --------------------------------------------------------------------------------
  */

  async getLast(filterCriteria = {}, transactions) {
    try {
      const filteredTransactions = transactions.filter((transaction) => {
        for (const key in filterCriteria) {
          if (transaction[key] !== filterCriteria[key]) {
            return false;
          }
        }
        return true;
      });

      if (filteredTransactions.length === 0) {
        return null;
      }

      const sortedTransactions = filteredTransactions.sort((a, b) => {
        const dateA = new Date(a.date);
        const dateB = new Date(b.date);
        return dateB - dateA;
      });

      return sortedTransactions[0];
    } catch (error) {
      throw new Error(
        "Gagal mendapatkan data transaksi terakhir: " + error.message
      );
    }
  },

  /* GET TANGGAL 
  -------------------------------------
  */
  getHari() {
    const sekarang = new Date();
    const waktu = sekarang.getDay();
    return waktu;
  },
  getTanggal() {
    const sekarang = new Date();
    const waktu = sekarang.getDate();
    return waktu;
  },
  getBulan() {
    const sekarang = new Date();
    const waktu = sekarang.getMonth() + 1;
    return waktu;
  },
  getTahun() {
    const sekarang = new Date();
    const waktu = sekarang.getFullYear();
    return waktu;
  },

  /* konversi object ke array 
  -------------------------------------
  try {
    const pricesArray = getConvertArray(data);
    console.log(pricesArray); // Output: [100, 150, 200, 120, 180]
  } catch (error) {
    console.error(error.message);
  }
  -------------------------------------
  getConvertArray(data)
  */

  getConvertArray(data) {
    if (!Array.isArray(data)) {
      throw new Error("Input bukanlah sebuah array!");
    }
    const hasilKonversi = data.map((item) => item.price);
    return hasilKonversi;
  },

  /* ISI ARRAY DI TOTAL KAN
  -------------------------------------
   getSumArray(deret)
   atau kombinasi ini tinggal copas:
        console.log(
          Accounting.getSumArray(Accounting.getConvertArray(hasilFilter))
        );
  */

  getSumArray(deret) {
    let hasil = 0;
    for (let i = 0; i < deret.length; i++) {
      hasil += deret[i];
    }
    return hasil;
  },

  setTopUp() {
    /*
    - saldo: dr saldo terakhir 
    - paketTopup
    - saldo terakhir
    - tanggal:
    - uid:
    - from_uid:
    - position:
    - location:
    - flow: in
    - product: saldo
    */
  },
  setSelling() {
    /*
    - saldo
    - paketJual
    - saldo terakhir
    - tanggal:
    - uid:
    - to_uid
    - position:
    - location:
    - flow: out
    - product: saldo
    */
  },

  // -----------------------------------------------------
  getPorsion() {
    let kondisi = {};
    /*
    - root: sisa hasil usaha
    - super_admin: 20% dari semua penjualan admin downline
    - admin: 1,5 juta
    - agency: 12% dari seluruh penjualan agency
    - reseller: 3000 per 10ribu penjualan
    - enduser: dapat promo
    */
  },
};
