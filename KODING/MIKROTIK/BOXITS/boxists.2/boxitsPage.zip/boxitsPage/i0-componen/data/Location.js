export const Location = {
  getTreeNodesData() {
    return [
      {
        key: "0",
        icon: "pi pi-fw pi-bitcoin",
        label: "All Location",
        data: {
          name: "All Location",
          type: "Boxits",
          official: "Root",
        },
      },
      {
        key: "1",
        icon: "pi pi-fw pi-bookmark-fill",
        label: "Banggai laut",
        data: {
          name: "Banggai Laut",
          type: "Investor",
          official: "Rafa",
        },
        children: [
          {
            key: "1-0",
            icon: "pi pi-fw pi-bookmark",
            label: "Adean",
            data: {
              name: "Adean",
              type: "Investor",
              official: "Rafa",
            },
            children: [
              {
                key: "1-0-0",
                icon: "pi pi-fw pi-flag",
                label: "Mominit",
                data: {
                  name: "Mominit",
                  type: "Investor",
                  official: "Rafa",
                },
              },
              {
                key: "1-0-1",
                icon: "pi pi-fw pi-flag",
                label: "Gonggong",
                data: {
                  name: "Gonggong",
                  type: "Investor",
                  official: "Rafa",
                },
              },
              {
                key: "1-0-2",
                icon: "pi pi-fw pi-flag",
                label: "Monsongan",
                data: {
                  name: "Monsongan",
                  type: "Investor",
                  official: "Rafa",
                },
              },
            ],
          },
          {
            key: "1-1",
            icon: "pi pi-fw pi-bookmark",
            label: "Banggai Staff",
            data: {
              name: "Banggai Staff",
              type: "Investor",
              official: "Rafa",
            },
            children: [
              {
                key: "1-1-0",
                icon: "pi pi-fw pi-flag",
                label: "Tinakin",
                data: {
                  name: "Tinakin",
                  type: "Investor",
                  official: "Rafa",
                },
              },
              {
                key: "1-1-1",
                icon: "pi pi-fw pi-flag",
                label: "Dodung",
                data: {
                  name: "Dodung",
                  type: "Investor",
                  official: "Rafa",
                },
              },
              {
                key: "1-1-2",
                icon: "pi pi-fw pi-flag",
                label: "Bebang",
                data: {
                  name: "Bebang",
                  type: "Investor",
                  official: "Rafa",
                },
              },
            ],
          },
        ],
      },
      {
        key: "2",
        icon: "pi pi-fw pi-bookmark-fill",
        label: "Banggai",
        data: {
          name: "Banggai",
          type: "Investor",
          official: "Rafa",
        },
        children: [
          {
            key: "2-0",
            icon: "pi pi-fw pi-bookmark",
            label: "Simpangraya",
            data: {
              name: "Simpangraya",
              type: "Investor",
              official: "Rafa",
            },
            children: [
              {
                key: "2-0-0",
                icon: "pi pi-fw pi-flag",
                label: "Sumbermulya",
                data: {
                  name: "Sumbermulya",
                  type: "Investor",
                  official: "Rafa",
                },
              },
            ],
          },
        ],
      },
    ];
  },

  getTreeNodes() {
    return Promise.resolve(this.getTreeNodesData());
  },
};
