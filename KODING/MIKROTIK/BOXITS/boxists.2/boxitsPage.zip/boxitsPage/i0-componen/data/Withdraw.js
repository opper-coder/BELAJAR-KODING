export const Withdraw = {
  getData() {
    return [
      {
        id: 999,
        admin_id: "alex",
        position: "ada",
        to_uid: "uid7679",
        name: "rafa",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        date: "2024-01-10",
        month_of: 1,
        price: 200,
        type: "send",
        status: "delivered",
        approve: true,
      },
      {
        id: 998,
        admin_id: "solly",
        position: "ada",
        to_uid: "uid7679",
        name: "aza",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        date: "2024-01-10",
        month_of: 1,
        price: 300,
        type: "sss",
        status: "delivered",
        approve: true,
      },
      {
        id: 997,
        admin_id: "ghofur",
        position: "ada",
        to_uid: "uid7679",
        name: "lintang",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        date: "2024-01-10",
        month_of: 1,
        price: 500,
        type: "send",
        status: "delivered",
        approve: true,
      },
    ];
  },

  getCustomersSmall() {
    return Promise.resolve(this.getData().slice(0, 10));
  },

  getCustomersMedium() {
    return Promise.resolve(this.getData().slice(0, 50));
  },

  getCustomersLarge() {
    return Promise.resolve(this.getData().slice(0, 200));
  },

  getCustomersXLarge() {
    return Promise.resolve(this.getData());
  },

  getCustomers(params) {
    const queryParams = params
      ? Object.keys(params)
          .map(
            (k) => encodeURIComponent(k) + "=" + encodeURIComponent(params[k])
          )
          .join("&")
      : "";

    return fetch(
      "https://www.primefaces.org/data/customers?" + queryParams
    ).then((res) => res.json());
  },

  // --------------------------------------------------------

  // getAqil() {
  //   const coba = this.getCustomersMedium();
  //   coba.then((d) => {
  //     console.log(d[0].name);
  //   });
  // },

  getAqil() {
    this.getCustomersXLarge().then((d) => {
      let total = 0;
      for (let i = 0; i < d.length; i++) {
        if (d[i].name === "lintang") {
          continue;
        }
        total += d[i].price;
      }
      return total;
      console.log(total);
    });
  },
};
