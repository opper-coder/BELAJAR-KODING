export const Withdraw = {
  getData() {
    return [
      {
        id: 999,
        admin_id: "alex",
        position: "ada",
        to_uid: "uid7679",
        name: "rafa",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        date: "2024-01-10",
        month_of: 1,
        price: 20000000,
        type: "send",
        status: "delivered",
        approve: true,
      },
      {
        id: 998,
        admin_id: "solly",
        position: "ada",
        to_uid: "uid7679",
        name: "rafa",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        date: "2024-01-10",
        month_of: 1,
        price: 20000000,
        type: "send",
        status: "delivered",
        approve: true,
      },
      {
        id: 997,
        admin_id: "ghofur",
        position: "ada",
        to_uid: "uid7679",
        name: "rafa",
        locate: "Banggai - Timbong",
        invoice: "inv122",
        date: "2024-01-10",
        month_of: 1,
        price: 20000000,
        type: "send",
        status: "delivered",
        approve: true,
      },
    ];
  },

  getCustomersSmall() {
    return Promise.resolve(this.getData().slice(0, 10));
  },

  getCustomersMedium() {
    return Promise.resolve(this.getData().slice(0, 50));
  },

  getCustomersLarge() {
    return Promise.resolve(this.getData().slice(0, 200));
  },

  getCustomersXLarge() {
    return Promise.resolve(this.getData());
  },

  getCustomers(params) {
    const queryParams = params
      ? Object.keys(params)
          .map(
            (k) => encodeURIComponent(k) + "=" + encodeURIComponent(params[k])
          )
          .join("&")
      : "";

    return fetch(
      "https://www.primefaces.org/data/customers?" + queryParams
    ).then((res) => res.json());
  },
};
