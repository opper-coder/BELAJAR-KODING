import { useState, useEffect, useRef } from "react";
import { classNames } from "primereact/utils";
import { FilterMatchMode, FilterOperator } from "primereact/api";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Tag } from "primereact/tag";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
import { TransactionDb } from "@/pages/boxitsPage/i0-componen/data/TransactionDb";
import { ContextMenu } from "primereact/contextmenu";

export default function TableDynamicProductFilter(props) {
  /*
RINGKASAN TUGAS DESAIN:
-----------------------
1. tentukan field yang diperlukan dalam database sumberdatanya tabel product tersebut. 
    a. hidden untuk filter: administrator, tabel produk, bulan,  
    b. show di tabel: untuk filter, untuk info evaluasi 
    c. coba simulasi desain field apa saja dengan excel
    d. replace db dengan desain mu, perhatikan format yang di buat
2. bikin state dan logic if atau switch
4. desain body template
4. pilih filter sederhana pakai <search>
5. pilih filter <list option>
6. dinamic untuk halaman lain: kayaknya tidak bisa hanya bisa di: sumberdata, option

PROPS DINAMIC
-----------------------
  product:
    product: jenis, harga, tanggal, 
    user: super admin, admin, agency, reseller, enduser, investor,    
    service: jual, response, 
    activity: req, res
    solusi: reset, delete, freeze, activate, 

HANDLING TABLE PRIMEREACT
-----------------------
PERSIAPAN:
1. siapkan halaman
2. copas semua code dari sumber "documetasi"
3. ganti nama komponen dengan nama yang anda miliki
4. siapkan sumberdata copas dari doc lalu letakan di suatu tempat
5. import sumberdata tersebut ke dalam komponen anda ini

MODIFIKASI:
1. jika anda mau menggunakan database bawaan tinggal langkah handling saja di bawah
2. jika mau db yang baru silahkan buat susun field baru yang kamu punya di luar db
3. jika sudah jadi, silahkan masukan ke index pertama di db yg sudah ada untuk pengujian
4. perhatikan format penulisan, format value, nested, array, object dll
5. coba tampilkan field ke tabel dengan meng copas field yang memiliki "type data", dan "type filter" yang sama
6. field: isi dengan field data base kamu punya
7. filter: aktifkan maka otomatis akan di buatkan filter input text,
8. filterfield: atau ganti field selain input text CEKIDOC saja 
9. callback: jika kita menggunakan filter advance pada field tersebut harap periksa 
    masing2 callback nya(biasanya ada 1 - 3 callback) mungkin membutuhkan variabel data atau object pengganti
10. initFilters: mengatur kuery data yang di tampilkan bisa di lihat value pada field di "initFilters" 
      name: {value: null} artinya datatable tidak di filter 
      name: {value: "aqil"} artinya nama hanya di tampilkan aqil punya saja 
      date: {value: new Date("2018-02-16")} untuk menuliskan hardcode tanggal formatnya sepeti ini
11. body: selain itu kamu bisa mengatur body tampilan field sesuai gayamu udah itu saja sihh
12. kombinasi: kalau sudah tinggal kombinasikan dengan klik kanan dsb silahkan saja

MODIFIKASI:
-----------------------
field:
    desain field di db. caranya copas satu row yg sudah ada lalu replace field dengan keperluan kalian, 
    kemudian hapus semua field2 aslinya 
    perhatikan cara menulis format: type data, nested
    tiap tahapan coba jalankan

db: 
    lalu fungsi pemanggil "methoddb" ganti nama dengan kita punya, lalu ubah import di halaman, coba jalankan

filter: 
    tambahkan elemen filter di state: filter copas dari elemen lainya
    const [filters, setFilters] = useState({
        name: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    });
body: 
    body template yaitu callback return element html, ambil dataRow dari args
    body:{(row)=>{return<>"halo" + row</>}}
field: 
    tambahkan atribut field: berisi key db. untuk tampilkan data db
        <Column
          field="name"
          header="Name"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
filter:
    tinggal tambahkan atribut filter showFilterMenu: true default tidak harus di tulis, maka otomatis filter dengan search 
filterField:
    (pengganti field: menampilkan data db) jika pilihanya adalah dropdown atau filter option lainya 
    maka di butuhkan callback template option nya
    showFilterMenu:{false} matikan kolom search tapi harus di gantikan dengan filterElemen 
filterElement:
    showFilterMenu:{false} harus di matikan. tapi harus bikin filter element sbg pengganti search
    filterElement:{} callback berisi component: misal dropdown, yang butuh juga: callback itemsTemplate
    itemsTemplate:{} berupa tampilan
*/

  // const proper2 = {
  //   contextmenu: [
  //     {
  //       label: "View",
  //       icon: "pi pi-fw pi-search",
  //       command: () => viewProduct(selectedProduct),
  //     },
  //     {
  //       label: "Delete",
  //       icon: "pi pi-fw pi-times",
  //       command: () => deleteProduct(selectedProduct),
  //     },
  //   ],
  //   filter: {
  //     administrator: "root",
  //     super_admin_id: "superadmin2132",
  //     admin_id: "",
  //     agency_id: "",
  //     seller_id: "",
  //     region: "region",
  //     category: "product",
  //     product: "pulsa",
  //     bulan: "1",
  //     tahun: "2024",
  //   },
  //   field_product: {
  //     satu: "name",
  //     dua: "price",
  //     tiga: "type",
  //     empat: "agency_id",
  //     lima: "seller_id",
  //     enam: "status",
  //     tujuh: "date",
  //   },
  //   field_project: {
  //     id: 899,
  //     super_admin_id: "",
  //     name: "",
  //     location: "",
  //     start: "",
  //     end: "",
  //     estimate: "",
  //     price: "",
  //     assign: "",
  //     a: "",
  //   },
  //   field_subscribe: {
  //     id: "",
  //     name: "",
  //     class: "",
  //     price: "",
  //     to_uid: "",
  //     agency_id: "",
  //     status: "",
  //     agency_name: "",
  //     a: "",
  //   },
  //   field_investor: {
  //     packet: "",
  //     location: "",
  //     super_admin_id: "",
  //     admin_id: "",
  //     price: "",
  //     portion: "",
  //     periode: "",
  //     status: "",
  //     start: "",
  //     end: "",
  //     a: "",
  //     mou: "link",
  //   },
  // };

  /* -------------------------------------------------------------------
  import TableDynamicProductFilter from "@/pages/boxitsPage/i0-componen/TableDynamicProductFilter";
  export default function Send() {
    const proper = {
      category: "product",
      region: "banggai laut",
      super_admin_id: "ace",
      admin_id: "alex",
    };
    return (
      <>
      <div className="cardx">
      <TableDynamicProductFilter proper={proper} />
      </div>
      </>
      );
    }
    -------------------------------------------------------------------- */

  const [customers, setCustomers] = useState(null);
  const [filters, setFilters] = useState({
    category: {
      value: props.proper.category,
      matchMode: FilterMatchMode.EQUALS,
    },
    region: { value: props.proper.region, matchMode: FilterMatchMode.EQUALS },
    super_admin_id: {
      value: props.proper.super_admin_id,
      matchMode: FilterMatchMode.EQUALS,
    },
    admin_id: {
      value: props.proper.admin_id,
      matchMode: FilterMatchMode.EQUALS,
    },
    // -----
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    name: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    product: { value: null, matchMode: FilterMatchMode.EQUALS },
    status: { value: null, matchMode: FilterMatchMode.EQUALS },
    approve: { value: null, matchMode: FilterMatchMode.EQUALS },
    invoice: { value: null, matchMode: FilterMatchMode.EQUALS },
    date: { value: null, matchMode: FilterMatchMode.IN },
    to_uid: { value: null, matchMode: FilterMatchMode.EQUALS },
    seller: { value: null, matchMode: FilterMatchMode.EQUALS },
  });
  const [loading, setLoading] = useState(true);
  const [globalFilterValue, setGlobalFilterValue] = useState("");

  const [product] = useState([
    "capital",
    "saldo",
    "voucher",
    "data",
    "pppoe",
    "promo",
  ]);

  const getClassProduct = (product) => {
    switch (product) {
      case "capital":
        return "bg-red-400 text-white";

      case "saldo":
        return "bg-red-50 text-red-600";

      case "voucher":
        return "bg-green-500 text-green-50";

      case "data":
        return "bg-green-50 text-green-600";

      case "pppoe":
        return "bg-blue-500 text-blue-50";

      case "promo":
        return "bg-blue-50 text-blue-600";
    }
  };

  useEffect(() => {
    TransactionDb.getCustomersMedium().then((data) => {
      setCustomers(getCustomers(data));
      setLoading(false);
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const getCustomers = (data) => {
    return [...(data || [])].map((d) => {
      d.date = new Date(d.date);

      return d;
    });
  };

  const onGlobalFilterChange = (e) => {
    const value = e.target.value;
    let _filters = { ...filters };

    _filters["global"].value = value;

    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  const renderHeader = () => {
    return (
      <div className="flex justify-content-end">
        <span className="p-input-icon-left">
          <i className="pi pi-search" />
          <InputText
            value={globalFilterValue}
            onChange={onGlobalFilterChange}
            placeholder="Keyword Search"
          />
        </span>
      </div>
    );
  };

  const productBodyTemplate = (rowData) => {
    return (
      <Tag
        value={rowData.product}
        className={getClassProduct(rowData.product)}
      />
    );
  };

  const productItemTemplate = (option) => {
    return <Tag value={option} className={getClassProduct(option)} />;
  };

  const approveBodyTemplate = (rowData) => {
    return (
      <i
        className={classNames("pi", {
          "true-icon pi-check-circle text-green-500": rowData.approve,
          "false-icon pi-times-circle text-red-500": !rowData.approve,
        })}
      ></i>
    );
  };

  const productRowFilterTemplate = (options) => {
    return (
      <Dropdown
        value={options.value}
        options={product}
        onChange={(e) => options.filterApplyCallback(e.value)}
        itemTemplate={productItemTemplate}
        placeholder="Select One"
        className="p-column-filter"
        showClear
        style={{ minWidth: "12rem" }}
      />
    );
  };

  const verifiedRowFilterTemplate = (options) => {
    return (
      <TriStateCheckbox
        value={options.value}
        onChange={(e) => options.filterApplyCallback(e.value)}
      />
    );
  };

  const header = renderHeader();

  //  Context menu ---------------------
  const [selectedProduct, setSelectedProduct] = useState(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Verify",
      icon: "pi pi-fw pi-plus",
      command: () => popup(selectedProduct),
    },
    {
      label: "Reject",
      icon: "pi pi-fw pi-minus",
      command: () => popup(selectedProduct),
    },
    {
      label: "freeze",
      icon: "pi pi-fw pi-times",
      command: () => popup(selectedProduct),
    },
    {
      label: "Activate",
      icon: "pi pi-fw pi-check",
      command: () => popup(selectedProduct),
    },
    {
      separator: true,
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => popup(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => popup(selectedProduct),
    },
  ];

  const viewProduct = (product) => {
    alert("halo " + product.name);
  };

  const deleteProduct = (product) => {
    alert("delete " + product.name);
  };

  return (
    <div className="">
      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={customers}
        paginator
        rows={10}
        dataKey="id"
        filters={filters}
        globalFilterFields={[
          "name",
          "country.name",
          "status",
          "invoice",
          "to_uid",
          "seller_id",
        ]}
        // header={header}
        filterDisplay="row"
        loading={loading}
        emptyMessage="No customers found."
        size="small"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
      >
        <Column
          field="name"
          header="Name"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="invoice"
          header="Invoice"
          filter
          filterPlaceholder="Search by invoice"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="to_uid"
          header="To"
          filter
          filterPlaceholder="Search by To user"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="seller_id"
          header="Seller"
          filter
          filterPlaceholder="Search by Seller"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="product"
          header="Product"
          showFilterMenu={false}
          filterMenuStyle={{ width: "14rem" }}
          style={{ minWidth: "12rem" }}
          body={productBodyTemplate}
          filter
          filterElement={productRowFilterTemplate}
        />
        <Column
          field="approve"
          header="Approve"
          dataType="boolean"
          style={{ minWidth: "6rem" }}
          body={approveBodyTemplate}
          filter
          filterElement={verifiedRowFilterTemplate}
        />
      </DataTable>
    </div>
  );
}
