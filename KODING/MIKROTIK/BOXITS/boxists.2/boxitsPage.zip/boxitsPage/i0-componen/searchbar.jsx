import { Button } from "primereact/button";
import { Calendar } from "primereact/calendar";
import { InputText } from "primereact/inputtext";
import { useState, useEffect } from "react";
import { TreeSelect } from "primereact/treeselect";
import { Location } from "./data/Location";

export default function Searchbar() {
  const [date, setDate] = useState(null);
  const [nodes, setNodes] = useState(null);
  const [selectedNodeKey, setSelectedNodeKey] = useState(null);

  useEffect(() => {
    Location.getTreeNodes().then((data) => setNodes(data));
  }, []);

  return (
    <>
      <div className="flex gap-2 surface-100 p-1 border-1 border-300 border-round-xl">
        <span className="ml-auto">
          <TreeSelect
            value={selectedNodeKey}
            onChange={(e) => setSelectedNodeKey(e.value)}
            onSelectionChange={(e) => setSelectedNodeKey(e.value)}
            options={nodes}
            className="md:w-20rem w-full"
            placeholder="Pilih Lokasi"
            showClear
          ></TreeSelect>
        </span>
        <Calendar
          value={date}
          onChange={(e) => setDate(e.value)}
          view="month"
          dateFormat="mm/yy"
          showIcon
        />
        <span className="p-input-icon-left">
          <i className="pi pi-search" />
          <InputText placeholder="Search" className="p-inputtext-normal" />
        </span>
        <Button label="Search" outlined />
      </div>
    </>
  );
}
