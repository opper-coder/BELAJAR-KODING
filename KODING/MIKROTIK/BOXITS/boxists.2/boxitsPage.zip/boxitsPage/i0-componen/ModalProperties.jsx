/*
  // MODAL PROPERTIES -----------------------------
  const [modalProperties, setModalProperties] = useState(false);
  const properModalProperties = {
    modal: modalProperties,
    judul: "Properties",
    tombol: "Add Official",
    modalTutup: (d) => setModalProperties(d),
    // content import dari file dedicated berisi Properties saja
    // jika element ini dan proper mengganggu silahkan disable dulu 
    content: <ModalPropertiesContent proper={selectedProduct}/>,
  };

// ----------------------------------------
<ModalProperties proper={properModalProperties} />

// ini triggernya silahkan pakai callbacknya --- >
onClick={() => setModalProperties(true)}
*/

import { useState, useEffect } from "react";
import { Dialog } from "primereact/dialog";

export default function ModalProperties(props) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(props.proper.modal);
  }, [props.proper.modal]);
  return (
    <>
      <Dialog
        header={props.proper.judul}
        visible={visible}
        onHide={() => props.proper.modalTutup(false)}
        style={{ width: "30vw" }}
        breakpoints={{ "960px": "75vw", "641px": "100vw" }}
      >
        {props.proper.content}
      </Dialog>
    </>
  );
}

/*
HALAMAN KONTEN INI
-------------------------------------------------------
import { useState } from "react";
import { Button } from "primereact/button";
import { Dialog } from "primereact/dialog";

export default function ModalContentProperties2(props) {
  const [visible, setVisible] = useState(false);
  const [visible2, setVisible2] = useState(false);
  const [visible3, setVisible3] = useState(false);

  function ObjectWithNestedAndBooleanComponent() {
    const objectWithData = props.proper;

    const formatDate = (dateString) => {
      const dateObj = new Date(dateString);
      return dateObj.toLocaleDateString("id-ID", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      });
      // Format tanggal disesuaikan dengan local Indonesia, bisa disesuaikan dengan kebutuhan Anda
    };

    const createDivsFromObject = (obj) => {
      return Object.keys(obj).map((key) => {
        if (typeof obj[key] === "object") {
          return null; // Skip entri yang merupakan objek (nested)
        }

        let valueToDisplay = obj[key];
        if (typeof obj[key] === "boolean") {
          valueToDisplay = obj[key].toString(); // Mengonversi nilai boolean menjadi string
        }

        if (key === "tanggal") {
          return (
            <div key={key} className="grid">
              {// <strong>{key}:</strong> {formatDate(obj[key])} }
              <strong className="col-4">{key}</strong>
              <div className="col-8">: {formatDate(obj[key])}</div>
            </div>
          );
        }

        return (
          <div key={key} className="grid">
            <strong className="col-4">{key}</strong>
            <div className="col-8">: {valueToDisplay}</div>
          </div>
        );
      });
    };

    const divElements = createDivsFromObject(objectWithData);

    return <div>{divElements}</div>;
  }

  return (
    <>
      <div>{ObjectWithNestedAndBooleanComponent()}</div>

      <div className="flex gap-3 justify-content-center mt-4">
        <Button label="Pas Foto" onClick={() => setVisible(true)} />
        <Button label="Foto Rumah" onClick={() => setVisible2(true)} />
        <Button
          label="Map"
          icon="pi pi-map-marker"
          onClick={() => setVisible3(true)}
        />
        <Dialog
          header="Pas Foto"
          visible={visible}
          onHide={() => setVisible(false)}
          style={{ width: "50vw" }}
        >
          <p className="m-0">foto rumah</p>
        </Dialog>
        <Dialog
          header="Foto Rumah"
          visible={visible2}
          onHide={() => setVisible2(false)}
          className="w-full mx-3 md:w-8 lg:w-6"
        >
          <p className="m-0">foto rumah</p>
        </Dialog>
        <Dialog
          header="Peta"
          visible={visible3}
          onHide={() => setVisible3(false)}
          className="w-full mx-3 lg:w-10 h-full"
        >
          <p className="m-0">peta google</p>
        </Dialog>
      </div>
    </>
  );
}
--------------------------------------------------
*/
