import { Menubar } from "primereact/menubar";
import { useState } from "react";
import TanggalLive from "./tanggalLive";

export default function MenubarUtama() {
  const [date, setDate] = useState(null);
  const items = [
    {
      label: "Home",
      icon: "pi pi-fw pi-home",
      url: "./router",
    },
    {
      label: "Dashboard",
      icon: "pi pi-fw pi-chart-bar",
      url: "../../",
    },
  ];
  const end = (
    <div className="flex align-items-center gap-2">
      <TanggalLive />
    </div>
  );

  return (
    <>
      <Menubar model={items} className="mb-4" end={end} />
    </>
  );
}
