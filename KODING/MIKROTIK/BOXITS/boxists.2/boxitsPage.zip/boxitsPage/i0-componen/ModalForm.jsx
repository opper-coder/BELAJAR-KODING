/*
// MODAL FORM -----------------------------
const [modalForm, setModalForm] = useState(false);
const properModalForm = {
    modal: modalForm,
    judul: "Add Administrator",
    tombol: "Add Official",
    width: "30vw",
    warna: "success", // primary, success, danger, warning, info
    modalTutup: (d) => setModalForm(d),
    // content import dari file dedicated berisi form saja dari fungsi "rfc" biasa
    // jika props terpilih mengganggu silahkan hapus dulu
    // kayaknya onhide pada contex harus di non aktifkan
    content: <ModalContentCoba terpilih={selectedProduct} />,
};
// ----------------------------------------

<ModalForm proper={properModalForm} />
<Button
    // ini triggernya
    onClick={() => setModalForm(true)}
    label={properModal.tombol}
/>
*/

import { useState, useEffect } from "react";
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";

export default function ModalForm(props) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(props.proper.modal);
  }, [props.proper.modal]);

  const footerContent = (
    <div>
      <Button
        label="No"
        icon="pi pi-times"
        onClick={() => props.proper.modalTutup(false)}
        className="p-button-outlined"
        // className="p-button-text"
      />
      <Button
        label="Yes"
        icon="pi pi-check"
        onClick={() => props.proper.modalTutup(false)}
        severity={props.proper.warna}
        // severity="success"
        // autoFocus
      />
    </div>
  );

  return (
    <>
      <Dialog
        header={props.proper.judul}
        visible={visible}
        onHide={() => props.proper.modalTutup(false)}
        style={{ width: props.proper.width }}
        breakpoints={{ "960px": "75vw", "641px": "100vw" }}
        footer={footerContent}
      >
        {props.proper.content}
      </Dialog>
    </>
  );
}

/*
export default function ModalContentForm(props) {
  return (
    <>
    Apakah anda akan Menghapus Row data <b>{props?.terpilih?.name}</b>
    </>
    );
  }
*/
