import { useState } from "react";
import { ListBox } from "primereact/listbox";

export default function SideMenu(props) {
  const [selectedCountry, setSelectedCountry] = useState("Voucher");
  const [productMenu, setProductMenu] = useState(null);

  // pemanggil:
  // const [menu, setMenu] = useState("Modal");
  // const terimaState = (terima) => setMenu(terima);
  // list={listSidebar} listState={terimaState}        // panggil dg props
  //
  // const listSidebar = [                             // data list
  //   { name: "All", icon: "pi pi-bookmark mr-3" },
  //   { name: "Region Head", icon: "pi pi-bookmark mr-3" },
  //   { name: "Agency", icon: "pi pi-bookmark mr-3" },
  // ];

  // disini:
  // {props.listState(productMenu)}                    // kirim data pada return

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div>{option.name}</div>
      </div>
    );
  };

  return (
    <>
      {props.listState(productMenu)}
      <div>
        <ListBox
          value={selectedCountry}
          onChange={(e) => {
            setSelectedCountry(e.value);
            setProductMenu(e.value.name);
          }}
          options={props.list}
          optionLabel="name"
          itemTemplate={countryTemplate}
          className="w-full md:w-14rem"
          listStyle={{ maxHeight: "400px" }}
        />
      </div>
    </>
  );
}
