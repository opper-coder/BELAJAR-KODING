import React, { useState, useEffect, useRef } from "react";
import { classNames } from "primereact/utils";
import { FilterMatchMode, FilterOperator } from "primereact/api";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { InputNumber } from "primereact/inputnumber";
import { Button } from "primereact/button";
import { ProgressBar } from "primereact/progressbar";
import { Calendar } from "primereact/calendar";
import { Slider } from "primereact/slider";
import { Tag } from "primereact/tag";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
import { DataDb } from "../../i0-componen/data/DataDb";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import ModalForm from "../../i0-componen/ModalForm";
import ModalProperties from "../../i0-componen/ModalProperties";
import ModalContentFormEdit from "./ModalContentFormEdit";
import ModalContentProperties from "./ModalContentProperties";
import ModalContentDelete from "./ModalContentDelete";
import ModalContentAssign from "./ModalContentAssign";
import ModalContentAddInventory from "./ModalContentAddInventory";

export default function InventoryList() {
  const [administrator, setAdministrator] = useState("root");
  const [customers, setCustomers] = useState(null);
  const [filters, setFilters] = useState(null);
  const [loading, setLoading] = useState(false);
  const [globalFilterValue, setGlobalFilterValue] = useState("");
  const [statuses] = useState([
    "Device",
    "Connection",
    "Equipment",
    "Tools",
    "Facility",
  ]);

  const getSeverity = (status) => {
    switch (status) {
      case "Device":
        return "bg-purple-500 text-white";
      case "Connection":
        return "bg-blue-500 text-white";
      case "Equipment":
        return "bg-cyan-500 text-white";
      case "Tools":
        return "bg-red-500 text-white";
      case "Facility":
        return "bg-green-500 text-white";
    }
  };

  useEffect(() => {
    try {
      const data = DataDb.getData()[0].applianceTransaction;
      Promise.resolve(setCustomers(getCustomers(data)));
    } catch (error) {
      console.log("data tidak di temukan" + error);
    }

    initFilters();
  }, []);

  const getCustomers = (data) => {
    return [...(data || [])].map((d) => {
      d.date = new Date(d.date);

      return d;
    });
  };

  const formatDate = (value) => {
    return value.toLocaleDateString("en-US", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  const formatCurrency = (value) => {
    return value.toLocaleString("id-ID", {
      style: "currency",
      currency: "IDR",
    });
  };

  const clearFilter = () => {
    initFilters();
  };

  const onGlobalFilterChange = (e) => {
    const value = e.target.value;
    let _filters = { ...filters };

    _filters["global"].value = value;

    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  const initFilters = () => {
    setFilters({
      global: { value: null, matchMode: FilterMatchMode.CONTAINS },
      name: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
      },
      balance: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      category: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      date: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.DATE_IS }],
      },
      code: {
        operator: FilterOperator.OR,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      price: {
        operator: FilterOperator.OR,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      status: {
        operator: FilterOperator.OR,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      activity: { value: null, matchMode: FilterMatchMode.BETWEEN },
      verified: { value: null, matchMode: FilterMatchMode.EQUALS },
    });
    setGlobalFilterValue("");
  };

  const renderHeader = () => {
    return (
      <div className="flex justify-content-between">
        <Button
          type="button"
          icon="pi pi-filter-slash"
          label="Clear"
          outlined
          onClick={clearFilter}
        />
        <span className="p-input-icon-left">
          <i className="pi pi-search" />
          <InputText
            value={globalFilterValue}
            onChange={onGlobalFilterChange}
            placeholder="Keyword Search"
          />
        </span>
      </div>
    );
  };

  const dateBodyTemplate = (rowData) => {
    return formatDate(rowData.date);
  };

  const dateFilterTemplate = (options) => {
    return (
      <Calendar
        value={options.value}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        dateFormat="mm/dd/yy"
        placeholder="mm/dd/yyyy"
        mask="99/99/9999"
      />
    );
  };

  const balanceBodyTemplate = (rowData) => {
    return formatCurrency(rowData.price);
  };

  const balanceFilterTemplate = (options) => {
    return (
      <InputNumber
        value={options.value}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        mode="currency"
        currency="IDR"
        locale="id-ID"
      />
    );
  };

  const statusBodyTemplate = (rowData) => {
    return (
      <Tag value={rowData.category} className={getSeverity(rowData.category)} />
    );
  };

  const statusFilterTemplate = (options) => {
    return (
      <Dropdown
        value={options.value}
        options={statuses}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        itemTemplate={statusItemTemplate}
        placeholder="Select One"
        className="p-column-filter"
        showClear
      />
    );
  };

  const statusItemTemplate = (option) => {
    return <Tag value={option} className={getSeverity(option)} />;
  };

  const activityBodyTemplate = (rowData) => {
    return (
      <ProgressBar
        value={rowData.activity}
        showValue={false}
        style={{ height: "6px" }}
      ></ProgressBar>
    );
  };

  const activityFilterTemplate = (options) => {
    return (
      <React.Fragment>
        <Slider
          value={options.value}
          onChange={(e) => options.filterCallback(e.value)}
          range
          className="m-3"
        ></Slider>
        <div className="flex align-items-center justify-content-between px-2">
          <span>{options.value ? options.value[0] : 0}</span>
          <span>{options.value ? options.value[1] : 100}</span>
        </div>
      </React.Fragment>
    );
  };

  const verifiedBodyTemplate = (rowData) => {
    return (
      <i
        className={classNames("pi", {
          "text-green-500 pi-check-circle": rowData.verified,
          "text-red-500 pi-times-circle": !rowData.verified,
        })}
      ></i>
    );
  };

  const verifiedFilterTemplate = (options) => {
    return (
      <div className="flex align-items-center gap-2">
        <label htmlFor="verified-filter" className="font-bold">
          Verified
        </label>
        <TriStateCheckbox
          inputId="verified-filter"
          value={options.value}
          onChange={(e) => options.filterCallback(e.value)}
        />
      </div>
    );
  };

  const header = renderHeader();
  // --------------
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Assign",
      icon: "pi pi-fw pi-link",
      command: () => setModalForm1(true),
    },
    {
      label: "Edit",
      icon: "pi pi-fw pi-pencil",
      command: () => setModalEdit(true),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => setModalForm3(true),
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => setModalProperties(true),
    },
  ];

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };

  // ----------------------------------------------------------------
  // MODAL FORM ASSIGN -----------------------------
  const [modalForm1, setModalForm1] = useState(false);
  const properModalForm1 = {
    modal: modalForm1,
    judul: "Assign",
    tombol: "Add Official",
    width: "30vw",
    warna: "success", // success, danger, warning, info
    modalTutup: (d) => setModalForm1(d),
    content: <ModalContentAssign terpilih={selectedProduct} />,
  };
  // MODAL FORM HAPUS -----------------------------
  const [modalForm3, setModalForm3] = useState(false);
  const properModalForm3 = {
    modal: modalForm3,
    judul: "Delete",
    tombol: "Add Official",
    width: "30vw",
    warna: "danger", // success, danger, warning, info
    modalTutup: (d) => setModalForm3(d),
    content: <ModalContentDelete terpilih={selectedProduct} />,
  };
  // MODAL PROPERTIES -----------------------------
  const [modalProperties, setModalProperties] = useState(false);
  const properModalProperties = {
    modal: modalProperties,
    judul: "Properties",
    tombol: "Add Official",
    modalTutup: (d) => setModalProperties(d),
    content: <ModalContentProperties proper={selectedProduct} />,
  };
  // MODAL FORM EDIT -----------------------------
  const [modalEdit, setModalEdit] = useState(false);
  const properModalEdit = {
    modal: modalEdit,
    judul: "Edit Administrator",
    tombol: "Edit Data Official",
    tombol2: "Add Member",
    modalTutup: (d) => setModalEdit(d),
    content: <ModalContentFormEdit data={selectedProduct} />,
  };
  const [modalForm, setModalForm] = useState(false);
  const properModalForm = {
    modal: modalForm,
    judul: "Add Inventory",
    tombol: "Add Inventory",
    width: "40vw",
    warna: "primary",
    modalTutup: (d) => setModalForm(d),
    content: <ModalContentAddInventory />,
  };
  return (
    <div className="card">
      <ModalForm proper={properModalForm} />;
      <ModalForm proper={properModalForm1} />
      <ModalForm proper={properModalForm3} />
      <ModalForm proper={properModalEdit} />
      <ModalProperties proper={properModalProperties} />
      <Button
        label={
          administrator == "root" ? properModalForm.tombol : "Request Project"
        }
        icon={administrator == "root" ? "pi pi-plus" : "pi pi-reply"}
        onClick={() => setModalForm(true)}
        className="mb-2"
        size="small"
      />
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        // onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={customers}
        paginator
        showGridlines
        rows={10}
        loading={loading}
        dataKey="id"
        filters={filters}
        globalFilterFields={["name", "balance", "status"]}
        header={header}
        emptyMessage="No customers found."
        size="small"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        tableStyle={{ minWidth: "50rem" }}
      >
        <Column
          field="category"
          header="Category"
          filterMenuStyle={{ width: "14rem" }}
          style={{ minWidth: "12rem" }}
          body={statusBodyTemplate}
          filter
          filterElement={statusFilterTemplate}
        />
        <Column
          field="name"
          header="Name"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="code"
          header="Server"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          header="Price"
          filterField="price"
          dataType="numeric"
          style={{ minWidth: "10rem" }}
          body={balanceBodyTemplate}
          filter
          filterElement={balanceFilterTemplate}
        />
        <Column
          header="Date"
          filterField="date"
          dataType="date"
          style={{ minWidth: "10rem" }}
          body={dateBodyTemplate}
          filter
          filterElement={dateFilterTemplate}
        />
        <Column
          field="activity"
          header="Age"
          showFilterMatchModes={false}
          style={{ minWidth: "12rem" }}
          body={activityBodyTemplate}
          filter
          filterElement={activityFilterTemplate}
        />
        <Column
          field="verified"
          header="Used"
          dataType="boolean"
          bodyClassName="text-center"
          style={{ minWidth: "8rem" }}
          body={verifiedBodyTemplate}
          filter
          filterElement={verifiedFilterTemplate}
        />
      </DataTable>
    </div>
  );
}
