export default function ModalContentAssign(props) {
  return (
    <>
      Apakah anda Akan menugaskan item ini untuk <b>{props?.terpilih?.name}</b>
    </>
  );
}
