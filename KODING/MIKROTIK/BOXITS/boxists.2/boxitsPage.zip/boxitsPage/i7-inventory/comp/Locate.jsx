import React, { useState, useEffect, useRef } from "react";
import { Tree } from "primereact/tree";
import { Toast } from "primereact/toast";
import { Location } from "@/pages/boxitsPage/i0-componen/data/Location";
import { ContextMenu } from "primereact/contextmenu";

export default function Locate() {
  const [nodes, setNodes] = useState([]);
  const [expandedKeys, setExpandedKeys] = useState({});
  const [selectedNodeKey, setSelectedNodeKey] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);

  const menu = [
    {
      label: "Toggle",
      icon: "pi pi-sort",
      command: () => {
        let _expandedKeys = { ...expandedKeys };

        if (_expandedKeys[selectedNodeKey])
          delete _expandedKeys[selectedNodeKey];
        else _expandedKeys[selectedNodeKey] = true;

        setExpandedKeys(_expandedKeys);
      },
    },
    {
      label: "Add Server",
      icon: "pi pi-server",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Edit",
      icon: "pi pi-pencil",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Delete",
      icon: "pi pi-trash",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Properties",
      icon: "pi pi-info-circle",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
  ];

  useEffect(() => {
    Location.getTreeNodes().then((data) => setNodes(data));
  }, []);

  return (
    <>
      <Toast ref={toast} />
      <ContextMenu model={menu} ref={cm} />
      <div className="flex justify-content-center">
        <Tree
          value={nodes}
          expandedKeys={expandedKeys}
          onToggle={(e) => setExpandedKeys(e.value)}
          contextMenuSelectionKey={selectedNodeKey}
          onContextMenuSelectionChange={(e) => setSelectedNodeKey(e.value)}
          onContextMenu={(e) => cm.current.show(e.originalEvent)}
          className="w-full md:w-22rem"
          filter
          filterMode="lenient"
          filterPlaceholder="Cari Lokasi"
        />
      </div>
    </>
  );
}
