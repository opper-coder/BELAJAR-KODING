export default function ModalContentAddInventory() {
  return <>INI ADALAH PENAMBAHAN INVENTORY</>;
}
