import { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { DataDb } from "../../i0-componen/data/DataDb";
import { Message } from "primereact/message";
import { Button } from "primereact/button";
import ModalForm from "../../i0-componen/ModalForm";
import ModalProperties from "../../i0-componen/ModalProperties";
import ModalContentProperties from "./ModalContentProperties";
import ModalContentFormEdit from "./ModalContentFormEdit";
import ModalContentDelete from "./ModalContentDelete";
import ModalContentAddHotspot from "./ModalContentAddHotspot";

export default function TableServers(props) {
  const [administrator, setAdministrator] = useState("root");
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);

  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Edit",
      icon: "pi pi-fw pi-pencil",
      command: () => setModalEdit(true),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => setModalForm3(true),
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => setModalProperties(true),
    },
  ];

  const tampilkanData = (d) => {
    if (d.length === 4) {
      try {
        Promise.resolve(
          setProducts(
            DataDb.getData()[0].location[d[0]].children[d[1]].children[d[2]]
              .children[d[3]].hotspot
          )
        );
      } catch (error) {
        return console.log("data tidak ditemukan" + error);
      }
    } else {
      setProducts(null);
    }
  };

  useEffect(() => {
    let stringData = props.hotspot.satu;
    let stringData2 = props.hotspot.dua;
    try {
      let arrayData = stringData.split("-").map(Number);
      console.log(arrayData);
      arrayData.length === 4 && stringData2 === "child"
        ? tampilkanData(arrayData)
        : tampilkanData(null);
    } catch (error) {
      setProducts(null);
      console.log("Belum ada Data!");
    }
    // NO. 1 DASAR
    // try {
    //   Promise.resolve(
    //     setProducts(
    //       DataDb.getData()[0].location[1].children[0].children[0].children[1]
    //         .hotspot
    //     )
    //   );
    // } catch (error) {
    //   return console.log("data tidak ditemukan" + error);
    // }
  }, [props.hotspot]); // eslint-disable-line react-hooks/exhaustive-deps

  // ----------------------------------------------------------------
  // MODAL FORM HAPUS -----------------------------
  const [modalForm3, setModalForm3] = useState(false);
  const properModalForm3 = {
    modal: modalForm3,
    judul: "Delete",
    tombol: "Add Official",
    width: "30vw",
    warna: "danger", // success, danger, warning, info
    modalTutup: (d) => setModalForm3(d),
    content: <ModalContentDelete terpilih={selectedProduct} />,
  };
  // MODAL PROPERTIES -----------------------------
  const [modalProperties, setModalProperties] = useState(false);
  const properModalProperties = {
    modal: modalProperties,
    judul: "Properties",
    tombol: "Add Official",
    modalTutup: (d) => setModalProperties(d),
    content: <ModalContentProperties proper={selectedProduct} />,
  };
  // MODAL FORM EDIT -----------------------------
  const [modalEdit, setModalEdit] = useState(false);
  const properModalEdit = {
    modal: modalEdit,
    judul: "Edit Administrator",
    tombol: "Edit Data Official",
    tombol2: "Add Member",
    modalTutup: (d) => setModalEdit(d),
    content: <ModalContentFormEdit data={selectedProduct} />,
  };
  const [modalForm2, setModalForm2] = useState(false);
  const properModalForm2 = {
    modal: modalForm2,
    judul: "Add Hotspot",
    tombol: "Add Hotspot",
    width: "40vw",
    warna: "primary",
    modalTutup: (d) => setModalForm2(d),
    content: <ModalContentAddHotspot />,
  };
  return (
    <div className="card w-full">
      <ModalForm proper={properModalForm3} />
      <ModalForm proper={properModalForm2} />
      <ModalForm proper={properModalEdit} />
      <ModalProperties proper={properModalProperties} />

      <Toast ref={toast} />

      <ContextMenu
        model={menuModel}
        ref={cm}
        // onHide={() => setSelectedProduct(null)}
      />
      <Button
        label={
          administrator == "root" ? properModalForm2.tombol : "Request Product"
        }
        icon={administrator == "root" ? "pi pi-plus" : "pi pi-reply"}
        onClick={() => setModalForm2(true)}
        className="mb-2"
        size="small"
      />
      <Message
        text={"udah lumayan tapi coba lebih akuratkan lagi"}
        className="mb-2"
      />
      <DataTable
        value={products}
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        tableStyle={{ minWidth: "30rem" }}
        size="small"
        paginator
        rows={20}
        stripedRows
      >
        <Column field="label" header="Name"></Column>
        <Column field="code" header="Code"></Column>
        <Column field="ip" header="IP Remote"></Column>
        <Column field="rumah" header="Home"></Column>
      </DataTable>
    </div>
  );
}
