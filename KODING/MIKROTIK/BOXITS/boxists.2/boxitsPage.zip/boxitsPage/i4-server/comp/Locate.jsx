/* eslint-disable react-hooks/exhaustive-deps */
/*

import React, { useState, useEffect, useRef } from "react";
import { Tree } from "primereact/tree";
import { Toast } from "primereact/toast";
import { DataDb } from "./data/DataDb";
import { ContextMenu } from "primereact/contextmenu";

export default function Locate() {
  const [nodes, setNodes] = useState([]);
  const [expandedKeys, setExpandedKeys] = useState({});
  const [selectedNodeKey, setSelectedNodeKey] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);

  const menu = [
    {
      label: "Toggle",
      icon: "pi pi-sort",
      command: () => {
        let _expandedKeys = { ...expandedKeys };

        if (_expandedKeys[selectedNodeKey])
          delete _expandedKeys[selectedNodeKey];
        else _expandedKeys[selectedNodeKey] = true;

        setExpandedKeys(_expandedKeys);
      },
    },
    {
      label: "Add Server",
      icon: "pi pi-server",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Edit",
      icon: "pi pi-pencil",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Delete",
      icon: "pi pi-trash",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Properties",
      icon: "pi pi-info-circle",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
  ];

  useEffect(() => {
    DataDb.getLocation().then((data) => setNodes(data));
  }, []);

  // ------------------------------------------------

  // const onSelect = (event) => {
  //   toast.current.show({
  //     severity: "info",
  //     summary: "Node Selected",
  //     detail: event.node.label,
  //   });
  //   alert("halo " + event.node.label);
  // };

  const [selectedLoc, setSelectedLoc] = useState();
  console.log("ini buatanku " + selectedLoc);
  console.log("ini asli " + selectedNodeKey);

  const onSelect = (event) => {
    setSelectedLoc(event.node.key);
  };

  console.log(selectedLoc);

  const onUnselect = (event) => {
    toast.current.show({
      severity: "info",
      summary: "Node Unselected",
      detail: event.node.label,
    });
  };

  return (
    <>
      <Toast ref={toast} />
      <ContextMenu model={menu} ref={cm} />
      <div className="flex justify-content-center">
        <Tree
          value={nodes}
          expandedKeys={expandedKeys}
          onToggle={(e) => setExpandedKeys(e.value)}
          contextMenuSelectionKey={selectedNodeKey}
          onContextMenuSelectionChange={(e) => setSelectedNodeKey(e.value)}
          onContextMenu={(e) => cm.current.show(e.originalEvent)}
          className="w-full md:w-22rem"
          filter
          filterMode="lenient"
          filterPlaceholder="Cari Lokasi"
          // ---
          selectionMode="single"
          selectionKeys={selectedNodeKey}
          onSelectionChange={(e) => setSelectedNodeKey(e.value)}
          // onSelect={onSelect}
          onNodeDoubleClick={onSelect}
          onUnselect={onUnselect}
        />
      </div>
    </>
  );
}

*/

import React, { useState, useEffect, useRef } from "react";
import { Tree } from "primereact/tree";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { DataDb } from "../../i0-componen/data/DataDb";

export default function Locate(props) {
  const [nodes, setNodes] = useState([]);
  const [expandedKeys, setExpandedKeys] = useState({});
  const [selectedNodeKey, setSelectedNodeKey] = useState(null);
  const [rghClk, setRghClk] = useState();

  const toast = useRef(null);
  const cm = useRef(null);
  const menu = [
    {
      label: "Toggle",
      icon: "pi pi-sort",
      command: () => {
        let _expandedKeys = { ...expandedKeys };

        if (_expandedKeys[selectedNodeKey])
          delete _expandedKeys[selectedNodeKey];
        else _expandedKeys[selectedNodeKey] = true;

        setExpandedKeys(_expandedKeys);
      },
    },
    {
      label: "Add Server",
      icon: "pi pi-server",
      command: () => {
        setRghClk("add");
        alert("tampilkan " + selectedNodeKey + " dan " + rghClk);
      },
    },
    {
      label: "Edit",
      icon: "pi pi-pencil",
      command: () => {
        setRghClk("edit");
        alert("tampilkan " + selectedNodeKey + " dan " + rghClk);
      },
    },
    {
      label: "Delete",
      icon: "pi pi-trash",
      command: () => {
        setRghClk("delete");
        alert("tampilkan " + selectedNodeKey + " dan " + rghClk);
      },
    },
    {
      label: "child",
      icon: "pi pi-sitemap",
      command: () => {
        setRghClk("child");
      },
    },
    {
      label: "Properties",
      icon: "pi pi-info-circle",
      command: () => {
        setRghClk("props");
        alert("tampilkan " + selectedNodeKey + " dan " + rghClk);
      },
    },
  ];

  useEffect(() => {
    DataDb.getLocation().then((data) => setNodes(data));
  }, []);

  useEffect(() => {
    props.stateKey({ satu: selectedNodeKey, dua: rghClk });
  }, [selectedNodeKey, rghClk]);

  return (
    <>
      <Toast ref={toast} />
      <ContextMenu model={menu} ref={cm} />
      <div className="">
        <Tree
          value={nodes}
          expandedKeys={expandedKeys}
          onToggle={(e) => setExpandedKeys(e.value)}
          contextMenuSelectionKey={selectedNodeKey}
          onContextMenuSelectionChange={(e) => setSelectedNodeKey(e.value)}
          onContextMenu={(e) => cm.current.show(e.originalEvent)}
          className="w-full md:w-24rem"
        />
      </div>
    </>
  );
}
