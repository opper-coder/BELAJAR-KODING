export default function ModalContentAddHotspot() {
  return <>Tanbahkan HOTSPOT</>;
}
