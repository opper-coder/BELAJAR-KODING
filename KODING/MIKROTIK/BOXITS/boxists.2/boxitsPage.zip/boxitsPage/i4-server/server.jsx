import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import Locate from "./comp/Locate";
import TableServers from "./comp/TableServers";
import { useState } from "react";

export default function Server() {
  const [statusKey, setStatusKey] = useState("aqil");
  const propsJumbo = {
    title: "Server",
    subtitle: "Halo ",
    column1: ["satu", "dua", "tiga"],
    column2: ["empat", "lima", "enam"],
    column3: [],
  };

  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      <div className="flex gap-2">
        <Locate
          stateKey={(d) => {
            setStatusKey(d);
          }}
        />
        <TableServers hotspot={statusKey} />
      </div>

      <div className="card bg-primary">
        PR:
        <ul>
          <li>
            fungsi utama
            <ol>
              <li>membuat server</li>
              <li>memberi identitas properties</li>
              <li>assign di pohon lokasi </li>
              <li>sorting aktifitas</li>
              <li>cari</li>
              <li>assign</li>
              <li>remote</li>
              <li></li>
              <li></li>
              <li></li>
              <li></li>
            </ol>
          </li>
          <li>layout</li>
          <li>database</li>
          <li>action</li>
          <li>pengabungan</li>
        </ul>
      </div>
    </>
  );
}
