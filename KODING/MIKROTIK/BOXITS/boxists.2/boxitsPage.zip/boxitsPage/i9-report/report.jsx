import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import SideMenu from "./comp/sideMenu";
import TabelReport from "./comp/tabelReport";

export default function Report() {
  const propsJumbo = {
    title: "Report",
    subtitle: "Halo ",
    column1: ["satu", "dua", "tiga"],
    column2: ["empat", "lima", "enam"],
    column3: [],
  };

  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      <div className="flex gap-2 ">
        <SideMenu />
        <TabelReport />
      </div>

      <div className="card bg-primary mt-5">
        {" "}
        <ul>
          <li>bulanan</li>
          <li>semua position</li>
          <li>lokasi</li>
          <li>pendapatan</li>
          <li>pengeluaran</li>
          <li>coba cari lagi ???</li>
        </ul>
      </div>
    </>
  );
}
