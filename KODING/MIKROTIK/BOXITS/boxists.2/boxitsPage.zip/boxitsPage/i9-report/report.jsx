import { TabPanel, TabView } from "primereact/tabview";
import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";

export default function Report() {
  const propsJumbo = {
    title: "Report",
    subtitle: "Halo ",
    column1: ["satu", "dua", "tiga"],
    column2: ["empat", "lima", "enam"],
    column3: [],
  };

  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />

      <div>
        <TabView>
          <TabPanel header="Product">
            {/* ----- <> ----- <> ----- <> ----- <> ----- <> ----- <> */}
            <div className="card bg-primary">Report</div>
            {/* ----- <> ----- <> ----- <> ----- <> ----- <> ----- <> */}
          </TabPanel>
          <TabPanel header="Coba"></TabPanel>
        </TabView>
      </div>
    </>
  );
}
