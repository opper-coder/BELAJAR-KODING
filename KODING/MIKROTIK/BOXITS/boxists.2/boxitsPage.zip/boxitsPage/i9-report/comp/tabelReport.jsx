import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { BoxitsDb } from "@/pages/boxitsPage/i0-componen/data/BoxitsDb";

import { useState, useEffect, useRef } from "react";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { Button } from "primereact/button";

import { ColumnGroup } from "primereact/columngroup";
import { Row } from "primereact/row";

export default function TabelReport() {
  const [products, setProducts] = useState([]);
  const columns = [
    // { field: "code", header: "productId" },
    { field: "name", header: "Nama" },
    // { field: "price", header: "Harga" },
    { field: "date", header: "Tanggal" },
    { field: "time", header: "Jam" },
    { field: "to", header: "Kepada" },
    { field: "authorize", header: "Auth" },
    // { field: "type", header: "Type" },
    { field: "status", header: "Status" },
  ];

  useEffect(() => {
    BoxitsDb.getProducts().then((data) =>
      setProducts(data[1]["items"][0]["transaction"])
    );
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const statusRequest = (product) => {
    return product.type === "req" && product.status === "wait" ? (
      <>
        <b className="text-red-400">{product.status}</b>
      </>
    ) : (
      <b className="text-green-400">{product.status}</b>
    );
  };

  const statusRequest2 = (product) => {
    return product.type === "req" && product.status === "wait" ? (
      <>
        <b className="text-blue-400">{product.status}</b>
      </>
    ) : (
      <b className="text-cyan-400">{product.status}</b>
    );
  };

  // context
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    // {
    //   label: "View",
    //   icon: "pi pi-fw pi-search",
    //   command: () => viewProduct(selectedProduct),
    // },
    // {
    //   label: "Delete",
    //   icon: "pi pi-fw pi-times",
    //   command: () => deleteProduct(selectedProduct),
    // },
    {
      label: "freeze",
      icon: "pi pi-fw pi-times",
      command: () => popup(selectedProduct),
    },
    {
      label: "Activate",
      icon: "pi pi-fw pi-check",
      command: () => popup(selectedProduct),
    },
    {
      separator: true,
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => popup(selectedProduct),
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => popup(selectedProduct),
    },
  ];

  const popup = (d) => {
    // cari dulu
    alert(d.to);
  };

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };

  // --------------------------------------------------

  const [sales] = useState([
    {
      product: "Bamboo Watch",
      lastYearSale: 51,
      thisYearSale: 40,
      lastYearProfit: 54406,
      thisYearProfit: 43342,
    },
    {
      product: "Black Watch",
      lastYearSale: 83,
      thisYearSale: 9,
      lastYearProfit: 423132,
      thisYearProfit: 312122,
    },
    {
      product: "Blue Band",
      lastYearSale: 38,
      thisYearSale: 5,
      lastYearProfit: 12321,
      thisYearProfit: 8500,
    },
    {
      product: "Blue T-Shirt",
      lastYearSale: 49,
      thisYearSale: 22,
      lastYearProfit: 745232,
      thisYearProfit: 65323,
    },
    {
      product: "Brown Purse",
      lastYearSale: 17,
      thisYearSale: 79,
      lastYearProfit: 643242,
      thisYearProfit: 500332,
    },
    {
      product: "Chakra Bracelet",
      lastYearSale: 52,
      thisYearSale: 65,
      lastYearProfit: 421132,
      thisYearProfit: 150005,
    },
    {
      product: "Galaxy Earrings",
      lastYearSale: 82,
      thisYearSale: 12,
      lastYearProfit: 131211,
      thisYearProfit: 100214,
    },
    {
      product: "Game Controller",
      lastYearSale: 44,
      thisYearSale: 45,
      lastYearProfit: 66442,
      thisYearProfit: 53322,
    },
    {
      product: "Gaming Set",
      lastYearSale: 90,
      thisYearSale: 56,
      lastYearProfit: 765442,
      thisYearProfit: 296232,
    },
    {
      product: "Gold Phone Case",
      lastYearSale: 75,
      thisYearSale: 54,
      lastYearProfit: 21212,
      thisYearProfit: 12533,
    },
  ]);

  const lastYearSaleBodyTemplate = (rowData) => {
    return `${rowData.lastYearSale}%`;
  };

  const thisYearSaleBodyTemplate = (rowData) => {
    return `${rowData.thisYearSale}%`;
  };

  const lastYearProfitBodyTemplate = (rowData) => {
    return `${formatCurrency(rowData.lastYearProfit)}`;
  };

  const thisYearProfitBodyTemplate = (rowData) => {
    return `${formatCurrency(rowData.thisYearProfit)}`;
  };

  const formatCurrency = (value) => {
    return value.toLocaleString("en-US", {
      style: "currency",
      currency: "USD",
    });
  };

  const lastYearTotal = () => {
    let total = 0;

    for (let sale of sales) {
      total += sale.lastYearProfit;
    }

    return formatCurrency(total);
  };

  const thisYearTotal = () => {
    let total = 0;

    for (let sale of sales) {
      total += sale.thisYearProfit;
    }

    return formatCurrency(total);
  };

  const footerGroup = (
    <ColumnGroup>
      <Row>
        <Column
          footer="Totals:"
          colSpan={3}
          footerStyle={{ textAlign: "right" }}
        />
        <Column footer={lastYearTotal} />
        <Column footer={thisYearTotal} />
      </Row>
    </ColumnGroup>
  );

  return (
    <div className="card w-full">
      <Button
        label="Add Transfer Withdraw"
        size="small"
        outlined
        className="mb-2"
        icon="pi pi-plus"
      />
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        footerColumnGroup={footerGroup}
        value={products}
        tableStyle={{ minWidth: "30rem" }}
        size="small"
        paginator
        rows={8}
        removableSort
        resizableColumns
        columnResizeMode="expand"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
      >
        <Column field="name" header="Product" sortable></Column>
        <Column field="to" header="Kepada"></Column>
        <Column field="type" header="Type"></Column>
        <Column
          field="status"
          header="Status"
          body={statusRequest}
          sortable
        ></Column>
        <Column
          field="status"
          header="Status"
          body={statusRequest2}
          sortable
        ></Column>
      </DataTable>
    </div>
  );
}
