import { useState } from "react";
import { ListBox } from "primereact/listbox";

export default function SideMenu() {
  const [selectedCity, setSelectedCity] = useState(null);
  const cities = [
    { name: "users", icon: "pi pi-users" },
    { name: "product", icon: "pi pi-box" },
    { name: "server", icon: "pi pi-server" },
    { name: "transaction", icon: "pi pi-arrow-right-arrow-left" },
    { name: "project", icon: "pi pi-align-left" },
    { name: "inventory", icon: "pi pi-briefcase" },
    { name: "investor", icon: "pi pi-bitcoin" },
  ];

  const countryTemplate = (option) => {
    return (
      <div className="flex align-items-center">
        <i className={option.icon}></i>
        <div className="ml-3">{option.name}</div>
      </div>
    );
  };

  return (
    <ListBox
      value={selectedCity}
      onChange={(e) => setSelectedCity(e.value)}
      itemTemplate={countryTemplate}
      options={cities}
      optionLabel="name"
      className="w-full md:w-14rem"
    />
  );
}
