export default function Subscriber() {
  return <>Subscriber</>;
}
