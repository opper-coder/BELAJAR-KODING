/* eslint-disable react-hooks/exhaustive-deps */
import TableDynamic from "@/pages/boxitsPage/i0-componen/tableDynamic";
import { useState, useEffect } from "react";
import { BoxitsDb } from "../../../i0-componen/data/BoxitsDb";
import Location from "./Location";
import TablePosition from "./TablePosition";

export default function Position2() {
  const [sumberData, setSumberData] = useState([]);
  const [listContex, setListContex] = useState([]);

  useEffect(() => {
    BoxitsDb.getProducts().then((data) =>
      setSumberData(data[0]["items"][0]["transaction"])
    );
  }, []);

  const propsTable = {
    db: sumberData,
    baris: 9,
    satu: (data) => setListContex(data),
    columns: [
      { field: "id", header: "Id" },
      { field: "code", header: "Code" },
      { field: "name", header: "Nama" },
      { field: "location", header: "Lokasi" },
      { field: "price", header: "Nilai" },
      { field: "adjustment", header: "Penyesuaian" },
      { field: "registerDate", header: "Tgl Regist" },
      { field: "status", header: "Status" },
    ],
    contex: [
      {
        label: "Banned",
        icon: "pi pi-fw pi-times",
        command: () => popup(),
      },
      {
        label: "Activate",
        icon: "pi pi-fw pi-check",
        command: () => popup(),
      },
      {
        label: "Edit",
        icon: "pi pi-fw pi-pencil",
        command: () => popup(),
      },
      {
        label: "Delete",
        icon: "pi pi-fw pi-trash",
        command: () => popup(),
      },
      {
        label: "Properties",
        icon: "pi pi-fw pi-info-circle",
        command: () => popup(),
      },
    ],
  };

  const popup = () => {
    // ambil data dari db mis: "listContex.id" ngambil ID untuk proses selanjutnya
    alert(listContex.name);
  };
  return (
    <>
      <div className="flex gap-2">
        <Location />
        <div className="card w-full">
          {/* <TableDynamic tabel={propsTable} /> */}
          <TablePosition />
        </div>
      </div>
    </>
  );
}
