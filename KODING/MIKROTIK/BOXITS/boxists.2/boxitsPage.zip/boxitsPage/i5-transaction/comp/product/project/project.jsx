import { TabPanel, TabView } from "primereact/tabview";
import { useEffect, useState } from "react";
import TableDynamic from "@/pages/boxitsPage/i0-componen/tableDynamic";
import { BoxitsDb } from "@/pages/boxitsPage/i0-componen/data/BoxitsDb";

export default function Project() {
  const [dataDynamic, setDataDynamic] = useState([]);
  const [dataContex, setDataContex] = useState([]);

  useEffect(() => {
    BoxitsDb.getProducts().then((data) =>
      setDataDynamic(data[3]["transaction"])
    );
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const propsTable = {
    db: dataDynamic,
    baris: 9,
    satu: (data) => setDataContex(data),
    columns: [
      { field: "name", header: "Nama" },
      { field: "price", header: "Harga" },
      { field: "code", header: "Kode" },
      { field: "assign", header: "Petugas" },
      { field: "start", header: "Mulai" },
      { field: "end", header: "Selesai" },
      { field: "location", header: "Lokasi" },
      { field: "contract", header: "No Kontrak" },
      { field: "status", header: "Status" },
      { field: "progress", header: "Progress" },
    ],
    contex: [
      {
        label: "satu",
        icon: "pi pi-fw pi-box",
        command: () => popup(),
      },
      {
        label: "dua",
        icon: "pi pi-fw pi-question",
        command: () => popup(),
      },
    ],
  };

  const popup = () => {
    // key data yang di ambil(kayaknya id)
    alert(dataContex.name);
  };

  return (
    <>
      <div>
        <TabView>
          <TabPanel header="Berlangsung">
            <TableDynamic tabel={propsTable} />
          </TabPanel>
          <TabPanel header="Selesai">
            <TableDynamic tabel={propsTable} />
          </TabPanel>
        </TabView>
      </div>

      {/* --------------------------------------- */}
      <div className="card bg-red-500 text-white">
        <b>root</b>
        <ul>
          <li>tab berlangsung, selesai</li>
          <li>daftar project</li>
          <li>context, tolak, verify, hapus, selesai</li>
          <li>filter lokasi</li>
        </ul>
        <b>admin</b>
        <ul>
          <li>add project</li>
          <li>tab berlangsung selesai</li>
          <li>context, hapus, selesai, </li>
          <li>assign project</li>
          <li>assign personalia</li>
          <li>selesai teruskan gaji</li>
        </ul>
      </div>
    </>
  );
}
