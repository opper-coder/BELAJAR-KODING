import MenuProduct from "./MenuProduct";
import Send from "./SendX";
import Sending from "./Sending";

export default function Sell() {
  return (
    <>
      <div className="mb-2">
        <MenuProduct />
      </div>
      <div>
        {/* <Send /> */}
        <Sending />
      </div>
    </>
  );
}
