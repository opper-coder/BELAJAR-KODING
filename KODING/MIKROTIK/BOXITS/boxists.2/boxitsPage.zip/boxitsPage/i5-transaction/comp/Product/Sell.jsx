import MenuProduct from "./MenuProduct";
import Send from "./Send";

export default function Sell() {
  return (
    <>
      <div className="mb-2">
        <MenuProduct />
      </div>
      <div>
        <Send />
      </div>
    </>
  );
}
