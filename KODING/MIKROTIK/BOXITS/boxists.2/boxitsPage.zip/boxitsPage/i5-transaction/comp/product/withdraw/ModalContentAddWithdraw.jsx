export default function ModalContentAddWithdraw() {
  return <>INI ADALAH PENAMBAHAN WITHDRAW</>;
}
