export default function ModalContentAddCapital() {
  return <>INI ADALAH PENAMBAHAN CAPITAL</>;
}
