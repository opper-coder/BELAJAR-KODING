import { InputNumber } from "primereact/inputnumber";
import { InputText } from "primereact/inputtext";

export default function ModalContentForm(props) {
  return (
    <>
      Apakah anda akan Menugaskan Row data <b>{props?.terpilih?.name}</b>
      inpu
      <div className="flex flex-column md:flex-row gap-3">
        <div className="p-inputgroup flex-1">
          <span className="p-inputgroup-addon">
            <i className="pi pi-user"></i>
          </span>
          <InputText placeholder="Username" />
        </div>

        <div className="p-inputgroup flex-1">
          <span className="p-inputgroup-addon">$</span>
          <InputNumber placeholder="Price" />
          <span className="p-inputgroup-addon">.00</span>
        </div>
      </div>
    </>
  );
}
