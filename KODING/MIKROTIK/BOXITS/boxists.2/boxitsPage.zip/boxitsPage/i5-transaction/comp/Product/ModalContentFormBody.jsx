export default function ModalContentFormBody(props) {
  return (
    <>
      {props.bodi} <b>{props?.terpilih?.price} </b>
      Kepada id
      <b> {props?.terpilih.to_uid}</b>
    </>
  );
}
