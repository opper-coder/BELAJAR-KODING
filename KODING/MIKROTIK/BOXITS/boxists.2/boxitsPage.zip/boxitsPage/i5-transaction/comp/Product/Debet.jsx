/* eslint-disable react-hooks/exhaustive-deps */
import TableDynamic from "@/pages/boxitsPage/i0-componen/tableDynamic";
import { useState, useEffect } from "react";
import { TransactionDb } from "@/pages/boxitsPage/i0-componen/data/TransactionDb";
import { Button } from "primereact/button";

export default function Debet() {
  const [administrator, setAdministrator] = useState("root");
  const [sumberData, setSumberData] = useState([]);
  const [listContex, setListContex] = useState([]);

  useEffect(() => {
    TransactionDb.getCustomersMedium().then((data) => {
      // setSumberData(data[0]["items"][0]["items"]);
      const dataswitch = () => {
        switch ("b") {
          case "a":
            return data;
          case "b":
            return data;
          default:
            break;
        }
      };
      setSumberData(dataswitch);
    });
  }, []);

  const propsTable = {
    db: sumberData,
    baris: 9,
    satu: (data) => setListContex(data),
    columns: [
      { field: "name", header: "Nama" },
      { field: "price", header: "Price" },
      { field: "invoice", header: "invoce" },
      { field: "date", header: "Date" },
    ],
    contex: [
      {
        label: "Edit",
        icon: "pi pi-fw pi-pencil",
        command: () => popup(),
      },
      {
        label: "Delete",
        icon: "pi pi-fw pi-trash",
        command: () => popup(),
      },
    ],
  };

  const popup = () => {
    // ambil data dari db mis: "listContex.id" ngambil ID untuk proses selanjutnya
    alert(listContex.name);
  };

  return (
    <>
      <Button
        label={administrator == "root" ? "Generate Capital" : "Request Capital"}
        icon={administrator == "root" ? "pi pi-plus" : "pi pi-reply"}
        size="small"
        className="mb-2"
      />
      <TableDynamic tabel={propsTable} />
    </>
  );
}
