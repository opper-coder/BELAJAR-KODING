export default function ModalContentDelete(props) {
  return (
    <>
      Apakah anda akan Menghapus Row data <b>{props?.terpilih?.label}</b>
    </>
  );
}
