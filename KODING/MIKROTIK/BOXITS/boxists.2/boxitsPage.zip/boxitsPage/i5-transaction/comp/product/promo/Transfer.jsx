import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { BoxitsDb } from "@/pages/boxitsPage/i0-componen/data/BoxitsDb";

import { useState, useEffect, useRef } from "react";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { Button } from "primereact/button";

export default function Transfer() {
  const [products, setProducts] = useState([]);
  const columns = [
    // { field: "code", header: "productId" },
    { field: "name", header: "Nama" },
    // { field: "price", header: "Harga" },
    { field: "date", header: "Tanggal" },
    { field: "time", header: "Jam" },
    { field: "to", header: "Kepada" },
    { field: "authorize", header: "Auth" },
    // { field: "type", header: "Type" },
    { field: "status", header: "Status" },
  ];

  useEffect(() => {
    BoxitsDb.getProducts().then((data) =>
      setProducts(data[1]["items"][0]["transaction"])
    );
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const statusRequest = (product) => {
    return product.type === "req" && product.status === "wait" ? (
      <>
        <b className="text-red-400">{product.status}</b>
      </>
    ) : (
      <b className="text-green-400">{product.status}</b>
    );
  };

  // context
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    // {
    //   label: "View",
    //   icon: "pi pi-fw pi-search",
    //   command: () => viewProduct(selectedProduct),
    // },
    // {
    //   label: "Delete",
    //   icon: "pi pi-fw pi-times",
    //   command: () => deleteProduct(selectedProduct),
    // },
    {
      label: "freeze",
      icon: "pi pi-fw pi-times",
      command: () => popup(selectedProduct),
    },
    {
      label: "Activate",
      icon: "pi pi-fw pi-check",
      command: () => popup(selectedProduct),
    },
    {
      separator: true,
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => popup(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => popup(selectedProduct),
    },
  ];

  const popup = (d) => {
    // cari dulu
    alert(d.to);
  };

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };

  return (
    <div className="">
      <Button
        label="Add Transfer Promo"
        size="small"
        outlined
        className="mb-2"
        icon="pi pi-plus"
      />
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={products}
        tableStyle={{ minWidth: "30rem" }}
        size="small"
        paginator
        rows={8}
        removableSort
        resizableColumns
        columnResizeMode="expand"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
      >
        <Column field="name" header="Product" sortable></Column>
        <Column field="to" header="Kepada"></Column>
        <Column field="date" header="Tanggal"></Column>
        <Column field="time" header="Pukul"></Column>
        <Column field="authorize" header="Auth"></Column>
        <Column
          field="status"
          header="Status"
          body={statusRequest}
          sortable
        ></Column>
        <Column field="type" header="Type"></Column>
      </DataTable>
    </div>
  );
}
