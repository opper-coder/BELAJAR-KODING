// import { DataTable } from "primereact/datatable";
// import { Column } from "primereact/column";
// import { BoxitsDb } from "@/pages/boxitsPage/i0-componen/data/BoxitsDb";
// import { useState, useEffect, useRef } from "react";
// import { ContextMenu } from "primereact/contextmenu";
// import { Toast } from "primereact/toast";

// export default function Response() {
//   const [administrator, setAdministrator] = useState("root");
//   const [products, setProducts] = useState([]);
//   const columns = [
//     // { field: "code", header: "productId" },
//     { field: "name", header: "Nama" },
//     // { field: "price", header: "Harga" },
//     { field: "date", header: "Tanggal" },
//     { field: "time", header: "Jam" },
//     { field: "to", header: "Kepada" },
//     { field: "authorize", header: "Auth" },
//     // { field: "type", header: "Type" },
//     { field: "status", header: "Status" },
//   ];

//   useEffect(() => {
//     BoxitsDb.getProducts().then((data) =>
//       setProducts(data[1]["items"][0]["transaction"])
//     );
//   }, []); // eslint-disable-line react-hooks/exhaustive-deps

//   const statusRequest = (product) => {
//     return product.type === "req" && product.status === "wait" ? (
//       <>
//         <b className="text-red-400">{product.status}</b>
//       </>
//     ) : (
//       <b className="text-green-400">{product.status}</b>
//     );
//   };

//   // context
//   const [selectedProduct, setSelectedProduct] = useState(null);
//   const toast = useRef(null);
//   const cm = useRef(null);
//   const menuModel = [
//     {
//       label: "Verify",
//       icon: "pi pi-fw pi-plus",
//       command: () => popup(selectedProduct),
//     },
//     {
//       label: "Reject",
//       icon: "pi pi-fw pi-minus",
//       command: () => popup(selectedProduct),
//     },
//     {
//       label: "Resi Transfer",
//       icon: "pi pi-fw pi-file",
//       command: () => popup(selectedProduct),
//     },
//     {
//       label: "Balance",
//       icon: "pi pi-fw pi-dollar",
//       command: () => popup(selectedProduct),
//     },
//     {
//       separator: true,
//     },
//     {
//       label: "Delete",
//       icon: "pi pi-fw pi-trash",
//       command: () => popup(selectedProduct),
//     },
//     {
//       label: "Properties",
//       icon: "pi pi-fw pi-info-circle",
//       command: () => popup(selectedProduct),
//     },
//   ];

//   const popup = (d) => {
//     // cari dulu
//     alert(d.to);
//   };

//   const viewProduct = (product) => {
//     toast.current.show({
//       severity: "info",
//       summary: "Product Selected",
//       detail: product.name,
//     });
//   };

//   const deleteProduct = (product) => {
//     let _products = [...products];

//     _products = _products.filter((p) => p.id !== product.id);

//     toast.current.show({
//       severity: "error",
//       summary: "Product Deleted",
//       detail: product.name,
//     });
//     setProducts(_products);
//   };

//   return (
//     <div className="">
//       <Toast ref={toast} />
//       <ContextMenu
//         model={menuModel}
//         ref={cm}
//         onHide={() => setSelectedProduct(null)}
//       />
//       <DataTable
//         value={products}
//         tableStyle={{ minWidth: "30rem" }}
//         size="small"
//         paginator
//         rows={9}
//         removableSort
//         resizableColumns
//         columnResizeMode="expand"
//         onContextMenu={(e) => cm.current.show(e.originalEvent)}
//         contextMenuSelection={selectedProduct}
//         onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
//       >
//         <Column field="name" header="Product" sortable></Column>
//         <Column field="to" header="Kepada"></Column>
//         <Column field="date" header="Tanggal"></Column>
//         <Column field="time" header="Pukul"></Column>
//         <Column field="authorize" header="Auth"></Column>
//         <Column
//           field="status"
//           header="Status"
//           body={statusRequest}
//           sortable
//         ></Column>
//         <Column field="type" header="Type"></Column>
//       </DataTable>
//     </div>
//   );
// }

import React, { useState, useEffect, useRef } from "react";
import { classNames } from "primereact/utils";
import { FilterMatchMode, FilterOperator } from "primereact/api";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dropdown } from "primereact/dropdown";
import { InputNumber } from "primereact/inputnumber";
import { Tag } from "primereact/tag";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
import { DataDb } from "@/pages/boxitsPage/i0-componen/data/DataDb";

import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import ModalContentFormBody from "../../Product/ModalContentFormBody";
import ModalContentDelete from "../../Product/ModalContentDelete";
import ModalContentProperties from "../../Product/ModalContentProperties";
import ModalFormBody from "@/pages/boxitsPage/i0-componen/ModalFormBody";
import ModalForm from "@/pages/boxitsPage/i0-componen/ModalForm";
import ModalProperties from "@/pages/boxitsPage/i0-componen/ModalProperties";

export default function Response() {
  const [customers, setCustomers] = useState(null);
  const [filters, setFilters] = useState(null);
  const [loading, setLoading] = useState(false);
  const [globalFilterValue, setGlobalFilterValue] = useState("");

  const [statuses] = useState([
    "capital",
    "saldo",
    "voucher",
    "data",
    "pppoe",
    "subscribe",
    "promo",
    "prive",
  ]);

  const getSeverity = (status) => {
    switch (status) {
      case "capital":
        return "bg-red-700 text-white";
      case "saldo":
        return "bg-red-500 text-white";
      case "voucher":
        return "bg-green-700 text-white";
      case "data":
        return "bg-green-500 text-white";
      case "pppoe":
        return "bg-green-50 text-green-700";
      case "subscribe":
        return "bg-blue-700 text-white";
      case "promo":
        return "bg-blue-500 text-white";
      case "prive":
        return "bg-blue-50 text-blue-700";

      case "renewal":
        return null;
    }
  };

  useEffect(() => {
    try {
      Promise.resolve(
        setCustomers(DataDb.getData()[0].administrator[0].transaction.withdraw)
      );
    } catch (error) {
      console.log("data tidak di temukan" + error);
    }

    initFilters();
  }, []);

  const getCustomers = (data) => {
    return [...(data || [])].map((d) => {
      d.date = new Date(d.date);

      return d;
    });
  };

  const formatCurrency = (value) => {
    return value.toLocaleString("id-ID", {
      style: "currency",
      currency: "IDR",
    });
  };

  const initFilters = () => {
    setFilters({
      // global: { value: null, matchMode: FilterMatchMode.CONTAINS },
      name: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
      },
      type: {
        operator: FilterOperator.AND,
        constraints: [{ value: "req", matchMode: FilterMatchMode.EQUALS }],
      },
      invoice: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      date: {
        operator: FilterOperator.AND,
        constraints: [
          {
            value: null,
            // value: new Date(),
            // value: new Date("02/19/2018"),
            matchMode: FilterMatchMode.DATE_IS,
          },
        ],
      },
      product: {
        operator: FilterOperator.OR,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      to_uid: {
        operator: FilterOperator.OR,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      verified: { value: null, matchMode: FilterMatchMode.EQUALS },
    });
    setGlobalFilterValue("");
  };

  const balanceBodyTemplate = (rowData) => {
    return formatCurrency(rowData.balance);
  };

  const balanceFilterTemplate = (options) => {
    return (
      <InputNumber
        value={options.value}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        mode="currency"
        currency="IDR"
        locale="id-ID"
      />
    );
  };

  const verifiedBodyTemplate = (rowData) => {
    return (
      <i
        className={classNames("pi", {
          "text-green-500 pi-check-circle": rowData.verified,
          "text-red-500 pi-times-circle": !rowData.verified,
        })}
      ></i>
    );
  };

  const verifiedFilterTemplate = (options) => {
    return (
      <div className="flex align-items-center gap-2">
        <label htmlFor="verified-filter" className="font-bold">
          Verified
        </label>
        <TriStateCheckbox
          inputId="verified-filter"
          value={options.value}
          onChange={(e) => options.filterCallback(e.value)}
        />
      </div>
    );
  };
  // -------------------
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Verify",
      icon: "pi pi-fw pi-plus",
      command: () => setModalFormBody(true),
    },
    {
      label: "Reject",
      icon: "pi pi-fw pi-minus",
      command: () => setModalFormBody2(true),
    },
    { separator: true },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => setModalForm3(true),
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => setModalProperties(true),
    },
  ];

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };

  // ----------------------------------------------------------------
  // MODAL FORM BODY VERIFY -----------------------------
  const [modalFormBody, setModalFormBody] = useState(false);
  const properModalFormBody = {
    modal: modalFormBody,
    judul: "Verify",
    tombol: "Add Official",
    width: "30vw",
    warna: "success", // primary, success, danger, warning, info
    modalTutup: (d) => setModalFormBody(d),
    content: (
      <ModalContentFormBody
        terpilih={selectedProduct}
        bodi={"Apakah anda akan Menyetujui Transaksi ini senilai"}
      />
    ),
  };
  // MODAL FORM BODY REJECT -----------------------------
  const [modalFormBody2, setModalFormBody2] = useState(false);
  const properModalFormBody2 = {
    modal: modalFormBody2,
    judul: "Reject",
    tombol: "Add Official",
    width: "30vw",
    warna: "danger", // primary, success, danger, warning, info
    modalTutup: (d) => setModalFormBody2(d),
    content: (
      <ModalContentFormBody
        terpilih={selectedProduct}
        bodi={"Apakah anda akan menolak transaksi ini sebesar"}
      />
    ),
  };

  // MODAL FORM HAPUS -----------------------------
  const [modalForm3, setModalForm3] = useState(false);
  const properModalForm3 = {
    modal: modalForm3,
    judul: "Delete",
    tombol: "Add Official",
    width: "30vw",
    warna: "danger", // success, danger, warning, info
    modalTutup: (d) => setModalForm3(d),
    content: <ModalContentDelete terpilih={selectedProduct} />,
  };
  // MODAL PROPERTIES -----------------------------
  const [modalProperties, setModalProperties] = useState(false);
  const properModalProperties = {
    modal: modalProperties,
    judul: "Properties",
    tombol: "Add Official",
    modalTutup: (d) => setModalProperties(d),
    content: <ModalContentProperties proper={selectedProduct} />,
  };

  return (
    <>
      <ModalFormBody proper={properModalFormBody} />
      <ModalFormBody proper={properModalFormBody2} />
      <ModalForm proper={properModalForm3} />
      <ModalProperties proper={properModalProperties} />
      <Toast ref={toast} />

      <ContextMenu
        model={menuModel}
        ref={cm}
        // onHide={() => setSelectedProduct(null)}
      />

      <DataTable
        value={customers}
        paginator
        showGridlines
        rows={7}
        loading={loading}
        dataKey="id"
        filters={filters}
        globalFilterFields={[
          "name",
          "country.name",
          "representative.name",
          "balance",
          "status",
        ]}
        emptyMessage="No customers found."
        size="small"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        tableStyle={{ minWidth: "30rem" }}
      >
        <Column
          field="invoice"
          header="Invoice"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="name"
          header="Name"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="from_uid"
          header="Admin"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="resi"
          header="No. Resi"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="verified"
          header="Delivered"
          dataType="boolean"
          bodyClassName="text-center"
          style={{ minWidth: "8rem" }}
          body={verifiedBodyTemplate}
          filter
          filterElement={verifiedFilterTemplate}
        />
      </DataTable>
    </>
  );
}
