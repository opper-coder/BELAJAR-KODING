/* eslint-disable react-hooks/exhaustive-deps */
import { TabPanel, TabView } from "primereact/tabview";
import Response from "./Response";
import Transfer from "./Transfer";

export default function Withdraw() {
  return (
    <>
      <div className="w-full">
        <div className="flex gap-2 w-full">
          <div className="text-center bg-blue-50 p-3 mb-2 border-round-lg text-blue-500 w-full">
            Debet <b>20.000.000,-</b>
          </div>
          <div className="text-center bg-green-50 p-3 mb-2 border-round-lg text-green-500 w-full">
            Kredit <b>18.000.000,-</b>
          </div>
        </div>
        <div className="card">
          <TabView>
            <TabPanel header="Approve">
              <Response />
            </TabPanel>
            <TabPanel header="Monthly">
              <Transfer />
            </TabPanel>
          </TabView>
        </div>
      </div>
      {/* ----------------- >>>>>>>> */}
      <div className="card bg-yellow-100">
        <b>yang di perlukan saat akan ada pencairan</b>
        <ul>
          <li>neraca laporan tutup buku tiap account</li>
          <li>menghitung jumlah pemasukan bulan ini </li>
          <li>menghitung jumlah penjualan bulan ini</li>
          <li>menghitung jumlah porsi penjualan bulan ini</li>
          <li>pencairan</li>
          <li>approve</li>
          <li>neraca berubah</li>
        </ul>
        <b>create</b>
        <ul>
          <li>Db balance</li>
          <li>transaksi register: field code balance</li>
          <li>
            field type:{` "close month", "close year", "close", "withdraw", `}
          </li>
        </ul>
        <b>field</b>
        <ul>
          <li>id</li>
          <li>uid</li>
          <li>name</li>
          <li>uid</li>
          <li>jabatan</li>
          <li>type</li>
          <li>price</li>
          <li>date</li>
          <li>flow</li>
          <li>invoice</li>
          <li>category</li>
          <li>super_admin_id</li>
          <li></li>
          region:{" "}
          {`"banggai", admin_id: null, agency_id: null, seller_id: "asas
          adda", to_uid: "uid7679", locate: "Banggai - Timbong", invoice:
          "inv122", product: "voucher", date: "2024-01-10", name: "30jt", price:
          20000000, type: "send", status: "delivered", approve: false, flow:
          "out"`}
        </ul>
        <b>kemampuan</b>
        <ul>
          <li>memiliki saldo</li>
          <li>menarik saldo</li>
          <li>banyak akun</li>
          <li>banyak jabatan</li>
          <li>tutup bulan</li>
          <li>tutup tahun</li>
          <li>history</li>
          <li>invoice</li>
          <li>gaji yang dimana</li>
          <li>gaji yang jabatan apa</li>
          <li>saldo/bonus</li>
          <li></li>
        </ul>
      </div>

      <ol>
        <li>root: semua transaksi</li>
        <li>admin: lokal</li>
        <li>tab </li>
        <li>tabel</li>
        <li>action</li>
        <li>field</li>
        <li>field nomor resi transaksi</li>
        <li>balance, detail ke report notif</li>
        <li>{`value: new Date("2018-02-16")`}</li>
      </ol>
      <b>Pihak:</b>
      <ol>
        <li>Region head</li>
        <li>Admin</li>
        <li>Agency:</li>
        <li>Reseller:</li>
        <li>Freelancer:</li>
        <li>Investor:</li>
      </ol>
      <ol>
        <li>sidemenu</li>
        <li>list siapa</li>
        <li>jumlah</li>
        <li>status</li>
        <li>cairkan</li>
        <li>request</li>
        <li>transfer</li>
        <li>context properties</li>
        <li>context balance</li>
      </ol>
    </>
  );
}
