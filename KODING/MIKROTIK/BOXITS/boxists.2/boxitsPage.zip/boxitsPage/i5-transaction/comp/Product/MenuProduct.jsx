import React, { useRef } from "react";
//import { useRouter } from 'next/router';
import { Button } from "primereact/button";
import { Menu } from "primereact/menu";
import { Toast } from "primereact/toast";

export default function MenuProduct() {
  const menuLeft = useRef(null);
  //const router = useRouter();
  const toast = useRef(null);
  const items = [
    {
      label: "Product",
      items: [
        {
          label: "Capital",
          icon: "pi pi-box",
          command: () => {
            alert("halo");
          },
        },
        {
          label: "Saldo",
          icon: "pi pi-box",
          command: () => {
            alert("halo");
          },
        },
        {
          label: "Voucher",
          icon: "pi pi-box",
          command: () => {
            alert("halo");
          },
        },
        {
          label: "Data",
          icon: "pi pi-box",
          command: () => {
            alert("halo");
          },
        },
        {
          label: "PPPoE",
          icon: "pi pi-box",
          command: () => {
            alert("halo");
          },
        },
      ],
    },
    {
      label: "Program",
      items: [
        {
          label: "Subscriber",
          icon: "pi pi-bookmark",
          command: () => {
            alert("halo");
          },
        },
        {
          label: "Promo",
          icon: "pi pi-gift",
          command: () => {
            alert("dua");
          },
        },
        // {
        //   label: "React Website",
        //   icon: "pi pi-external-link",
        //   url: "https://reactjs.org/",
        // },
        // {
        //   label: "Router",
        //   icon: "pi pi-upload",
        //   command: (e) => {
        //     //router.push('/fileupload');
        //   },
        // },
      ],
    },
  ];

  return (
    <div className="flex">
      <Toast ref={toast}></Toast>
      <Menu model={items} popup ref={menuLeft} id="popup_menu_left" />
      <Button
        label="Sell Product"
        icon="pi pi-align-left"
        className="mr-2"
        onClick={(event) => menuLeft.current.toggle(event)}
        aria-controls="popup_menu_left"
        aria-haspopup
        size="small"
        // outlined
      />
    </div>
  );
}
