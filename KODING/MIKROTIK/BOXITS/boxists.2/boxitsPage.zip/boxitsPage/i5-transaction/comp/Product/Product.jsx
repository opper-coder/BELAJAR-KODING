import { TabPanel, TabView } from "primereact/tabview";
import { useEffect } from "react";
import Debet from "./Debet";
import Approve from "./Approve";
import Sell from "./Sell";

export default function Product() {
  return (
    <>
      <div className="flex gap-2">
        <div className="flex-1 ">
          <div className="flex gap-2 w-full">
            <div className="flex-1 text-center bg-blue-50 p-3 mb-2 border-round-lg text-blue-500">
              Saldo <b>20.000.000,-</b>
            </div>
            <div className="flex-1 text-center bg-green-50 p-3 mb-2 border-round-lg text-green-500">
              Sold <b>18.000.000,-</b>
            </div>
          </div>
          <div className="card flex-1">
            <TabView>
              <TabPanel header="Sell">
                <Sell />
              </TabPanel>
              <TabPanel header="Request">
                <Approve />
              </TabPanel>
              <TabPanel header="Capital">
                <Debet />
              </TabPanel>
            </TabView>
          </div>
        </div>
      </div>
    </>
  );
}
