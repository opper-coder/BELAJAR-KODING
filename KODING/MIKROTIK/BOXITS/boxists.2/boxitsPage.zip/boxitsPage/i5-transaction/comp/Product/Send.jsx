import TableDynamicProductFilter from "@/pages/boxitsPage/i0-componen/TableDynamicProductFilter";

export default function Send() {
  const proper = {
    category: "product",
    region: "banggai laut",
    super_admin_id: "ace",
    admin_id: "alex",
  };
  return (
    <>
      <div className="cardx">
        <TableDynamicProductFilter proper={proper} />
      </div>
    </>
  );
}
