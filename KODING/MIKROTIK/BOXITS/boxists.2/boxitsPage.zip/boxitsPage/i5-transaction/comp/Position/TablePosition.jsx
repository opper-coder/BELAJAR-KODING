import React, { useState, useEffect, useRef } from "react";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { ProductService } from "@/pages/boxitsPage/i0-componen/data/ProductService";

export default function TablePosition() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "View",
      icon: "pi pi-fw pi-search",
      command: () => viewProduct(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-times",
      command: () => deleteProduct(selectedProduct),
    },
  ];

  useEffect(() => {
    ProductService.getProducts().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };

  const formatCurrency = (value) => {
    return value.toLocaleString("en-US", {
      style: "currency",
      currency: "USD",
    });
  };

  const priceBodyTemplate = (rowData) => {
    return formatCurrency(rowData.price);
  };

  return (
    <div className="">
      <Toast ref={toast} />

      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={products}
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        tableStyle={{ minWidth: "50rem" }}
        size="small"
        stripedRows
        paginator
        rows={12}
      >
        <Column field="code" header="Code"></Column>
        <Column field="name" header="Name"></Column>
        <Column field="category" header="Category"></Column>
        <Column field="price" header="Price" body={priceBodyTemplate} />
      </DataTable>
    </div>
  );
}
