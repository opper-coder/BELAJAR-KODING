import React, { useState, useEffect, useRef } from "react";
import { TreeTable } from "primereact/treetable";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { Column } from "primereact/column";
// import { NodeService } from "@/boxitsComp/Server/service/NodeService";
import { DataDb } from "@/pages/boxitsPage/i0-componen/data/DataDb";
import ModalForm from "@/pages/boxitsPage/i0-componen/ModalForm";
import ModalContentForm from "./ModalContentForm";

export default function Position() {
  const [nodes, setNodes] = useState([]);
  const [expandedKeys, setExpandedKeys] = useState(null);
  const [selectedNodeKey, setSelectedNodeKey] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menu = [
    {
      label: "Assign",
      icon: "pi pi-link",
      command: () => setModalForm(true),
    },
    {
      label: "View Key",
      icon: "pi pi-search",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Toggle",
      icon: "pi pi-sort",
      command: () => {
        let _expandedKeys = { ...expandedKeys };

        if (_expandedKeys[selectedNodeKey])
          delete _expandedKeys[selectedNodeKey];
        else _expandedKeys[selectedNodeKey] = true;

        setExpandedKeys(_expandedKeys);
      },
    },
  ];

  useEffect(() => {
    // NodeService.getTreeTableNodes().then((data) => setNodes(data));
    DataDb.getLocation().then((data) => setNodes(data));
  }, []);

  const officialBodyTemplate = (product) => {
    return <span className="text-blue-700">{product.data.official}</span>;
  };

  // MODAL FORM -----------------------------
  const [modalForm, setModalForm] = useState(false);
  const properModalForm = {
    modal: modalForm,
    judul: "Assign",
    tombol: "Add Official",
    width: "30vw",
    warna: "primary", // success, danger, warning, info
    modalTutup: (d) => setModalForm(d),
    content: <ModalContentForm terpilih={selectedNodeKey} />,
  };
  // ----------------------------------------

  return (
    <div className="card">
      <ModalForm proper={properModalForm} />
      <Toast ref={toast} />

      <ContextMenu
        model={menu}
        ref={cm}
        // onHide={() => setSelectedNodeKey(null)}
      />
      <TreeTable
        value={nodes}
        expandedKeys={expandedKeys}
        onToggle={(e) => setExpandedKeys(e.value)}
        contextMenuSelectionKey={selectedNodeKey}
        onContextMenuSelectionChange={(event) =>
          setSelectedNodeKey(event.value)
        }
        onContextMenu={(event) => cm.current.show(event.originalEvent)}
        tableStyle={{ minWidth: "50rem" }}
      >
        <Column field="name" header="Name" expander></Column>
        <Column
          field="official"
          header="Official"
          body={officialBodyTemplate}
        ></Column>
        <Column field="type" header="Type"></Column>
      </TreeTable>
    </div>
  );
}
