import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { TransactionDb } from "@/pages/boxitsPage/i0-componen/data/TransactionDb";
import { useState, useEffect, useRef } from "react";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";

export default function Approve() {
  const [administrator, setAdministrator] = useState("root");
  const [products, setProducts] = useState([]);
  const columns = [
    // { field: "code", header: "productId" },
    // { field: "price", header: "Harga" },
    // { field: "type", header: "Type" },
    { field: "name", header: "Nama" },
    { field: "date", header: "Tanggal" },
    { field: "time", header: "Jam" },
    { field: "to", header: "Kepada" },
    { field: "authorize", header: "Auth" },
    { field: "status", header: "Status" },
  ];

  useEffect(() => {
    TransactionDb.getCustomersMedium().then((data) => setProducts(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const statusRequest = (product) => {
    return product.type === "req" && product.status === "wait" ? (
      <>
        <b className="text-red-400">{product.status}</b>
      </>
    ) : (
      <b className="text-green-400">{product.status}</b>
    );
  };

  // context
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Verify",
      icon: "pi pi-fw pi-plus",
      command: () => popup(selectedProduct),
    },
    {
      label: "Reject",
      icon: "pi pi-fw pi-minus",
      command: () => popup(selectedProduct),
    },
    {
      label: "freeze",
      icon: "pi pi-fw pi-times",
      command: () => popup(selectedProduct),
    },
    {
      label: "Activate",
      icon: "pi pi-fw pi-check",
      command: () => popup(selectedProduct),
    },
    {
      separator: true,
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => popup(selectedProduct),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => popup(selectedProduct),
    },
  ];

  const popup = (d) => {
    // cari dulu
    alert(d.to);
  };

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };

  return (
    <div className="">
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={products}
        tableStyle={{ minWidth: "30rem" }}
        size="small"
        paginator
        rows={9}
        removableSort
        resizableColumns
        columnResizeMode="expand"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
      >
        <Column field="name" header="Name" sortable></Column>
        <Column field="invoice" header="Invoice" sortable></Column>
        <Column field="to_uid" header="To"></Column>
        <Column field="seller_id" header="Seller"></Column>
        <Column field="product" header="Product"></Column>
        <Column field="approve" header="Approve" body={statusRequest}></Column>
      </DataTable>
    </div>
  );
}
