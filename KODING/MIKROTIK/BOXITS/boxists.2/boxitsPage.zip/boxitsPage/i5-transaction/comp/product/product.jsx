/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useState } from "react";
import SideMenuDynamic from "@/pages/boxitsPage/i0-componen/sideMenuDynamic";
import Project from "./project/project";
import Saldo from "./saldo/saldo";
import Voucher from "./voucher/voucher";
import Data from "./data/data";
import Pppoe from "./pppoe/pppoe";
import Promo from "./promo/promo";
import Capital from "./capital/Capital";
import Subscriber from "./subscriber/Subscriber";

export default function Product() {
  const [administrator, setAdministrator] = useState("root");
  const [stateSideMenu, setStateSideMenu] = useState();
  const [adminMenu, setAdminMenu] = useState();

  useEffect(() => {
    if (administrator == "root") {
      setAdminMenu([
        { name: "Capital", icon: "pi pi-bookmark mr-3" },
        { name: "Saldo", icon: "pi pi-bookmark mr-3" },
        { name: "Voucher", icon: "pi pi-bookmark mr-3" },
        { name: "Data", icon: "pi pi-bookmark mr-3" },
        { name: "PPPoE", icon: "pi pi-bookmark mr-3" },
        { name: "Promo", icon: "pi pi-bookmark mr-3" },
        { name: "Subscriber", icon: "pi pi-bookmark mr-3" },
        { name: "Project", icon: "pi pi-bookmark mr-3" },
      ]);
    } else {
      setAdminMenu([
        { name: "Saldo", icon: "pi pi-bookmark mr-3" },
        { name: "Voucher", icon: "pi pi-bookmark mr-3" },
        { name: "Data", icon: "pi pi-bookmark mr-3" },
        { name: "PPPoE", icon: "pi pi-bookmark mr-3" },
        { name: "Promo", icon: "pi pi-bookmark mr-3" },
        { name: "Subscriber", icon: "pi pi-bookmark mr-3" },
        { name: "Project", icon: "pi pi-bookmark mr-3" },
      ]);
    }
  }, []);

  const propSideMenu = {
    default: null,
    operStateSideMenu: (data) => setStateSideMenu(data),
    list: adminMenu,
  };

  const halaman = (d) => {
    switch (d) {
      case "Capital":
        return (
          <div className="w-full">
            <Capital />
          </div>
        );
      case "Project":
        return (
          <div className="w-full">
            <Project />
          </div>
        );
      case "Saldo":
        return (
          <div className="w-full">
            <Saldo />
          </div>
        );
      case "Voucher":
        return (
          <div className="w-full">
            <Voucher />
          </div>
        );
      case "Data":
        return (
          <div className="w-full">
            <Data />
          </div>
        );
      case "PPPoE":
        return (
          <div className="w-full">
            <Pppoe />
          </div>
        );
      case "Promo":
        return (
          <div className="w-full">
            <Promo />
          </div>
        );
      case "Subscriber":
        return (
          <div className="w-full">
            <Subscriber />
          </div>
        );
      default:
        return (
          <div className="card py-8 bg-yellow-100">
            Tampilkan data dengan klik <b>Sidemenu</b> di samping
          </div>
        );
    }
  };

  const tampilHalaman = (d) => {
    if (d !== undefined) {
      return <div className="card w-full">{halaman(stateSideMenu)}</div>;
    } else {
      return (
        <div className="card w-full bg-yellow-100">
          Tampilkan data dengan klik <b>Sidemenu</b> di samping
        </div>
      );
    }
  };

  return (
    <>
      <div className="flex gap-2">
        <SideMenuDynamic proper={propSideMenu} />
        {tampilHalaman(stateSideMenu)}
      </div>
    </>
  );
}
