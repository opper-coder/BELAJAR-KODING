import { TabPanel, TabView } from "primereact/tabview";
import Response from "./Response";
import Transfer from "./Transfer";
import TableDynamic from "@/pages/boxitsPage/i0-componen/tableDynamic";
import { Button } from "primereact/button";
import { useState, useEffect } from "react";
import { BoxitsDb } from "@/pages/boxitsPage/i0-componen/data/BoxitsDb";

export default function Promo() {
  const [sumberData, setSumberData] = useState([]);
  const [listContex, setListContex] = useState([]);

  useEffect(() => {
    BoxitsDb.getProducts().then((data) =>
      setSumberData(data[1]["items"][0]["transaction"])
    );
  }, []);
  const propsTable = {
    db: sumberData,
    baris: 10,
    satu: (data) => setListContex(data),
    columns: [
      // { field: "code", header: "productId" },
      { field: "name", header: "Nama" },
      { field: "to", header: "Kepada" },
      // { field: "price", header: "Harga" },
      { field: "date", header: "Tanggal" },
      // { field: "time", header: "Jam" },
      // { field: "authorize", header: "Auth" },
      // { field: "type", header: "Type" },
      { field: "status", header: "Status" },
    ],
    contex: [
      {
        label: "Properties",
        icon: "pi pi-fw pi-info-circle",
        command: () => popup(),
      },
      {
        label: "Delete",
        icon: "pi pi-fw pi-trash",
        command: () => popup(),
      },
    ],
  };
  return (
    <>
      <div className="flex gap-2">
        <div className="flex-2">
          <div className="text-center bg-blue-50 p-3 mb-2 border-round-lg text-blue-500">
            Debet <b>20.000.000,-</b>
          </div>
          <div className="card">
            <div>
              <Button
                label="Generate Promo"
                className="w-fullx mb-2"
                // outlined
                size="small"
                icon="pi pi-plus"
              />
              <TableDynamic tabel={propsTable} />
            </div>
          </div>
        </div>
        <div className="flex-1">
          <div className="text-center bg-green-50 p-3 mb-2 border-round-lg text-green-500">
            Kredit <b>18.000.000,-</b>
          </div>
          <div className="card flex-1">
            <TabView>
              <TabPanel header="Approve">
                <Response />
              </TabPanel>
              <TabPanel header="Transfer">
                <Transfer />
              </TabPanel>
            </TabView>
          </div>
        </div>
      </div>
    </>
  );
}
