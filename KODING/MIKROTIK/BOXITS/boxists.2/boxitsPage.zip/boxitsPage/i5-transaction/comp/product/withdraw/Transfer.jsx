// import { DataTable } from "primereact/datatable";
// import { Column } from "primereact/column";
// import { BoxitsDb } from "@/pages/boxitsPage/i0-componen/data/BoxitsDb";

// import { useState, useEffect, useRef } from "react";
// import { ContextMenu } from "primereact/contextmenu";
// import { Toast } from "primereact/toast";
// import { Button } from "primereact/button";

// export default function Transfer() {
//   const [products, setProducts] = useState([]);
//   const columns = [
//     // { field: "code", header: "productId" },
//     { field: "name", header: "Nama" },
//     // { field: "price", header: "Harga" },
//     { field: "date", header: "Tanggal" },
//     { field: "time", header: "Jam" },
//     { field: "to", header: "Kepada" },
//     { field: "authorize", header: "Auth" },
//     // { field: "type", header: "Type" },
//     { field: "status", header: "Status" },
//   ];

//   useEffect(() => {
//     BoxitsDb.getProducts().then((data) =>
//       setProducts(data[1]["items"][0]["transaction"])
//     );
//   }, []); // eslint-disable-line react-hooks/exhaustive-deps

//   const statusRequest = (product) => {
//     return product.type === "req" && product.status === "wait" ? (
//       <>
//         <b className="text-red-400">{product.status}</b>
//       </>
//     ) : (
//       <b className="text-green-400">{product.status}</b>
//     );
//   };

//   // context
//   const [selectedProduct, setSelectedProduct] = useState(null);
//   const toast = useRef(null);
//   const cm = useRef(null);
//   const menuModel = [
//     // {
//     //   label: "View",
//     //   icon: "pi pi-fw pi-search",
//     //   command: () => viewProduct(selectedProduct),
//     // },
//     // {
//     //   label: "Delete",
//     //   icon: "pi pi-fw pi-times",
//     //   command: () => deleteProduct(selectedProduct),
//     // },
//     {
//       label: "freeze",
//       icon: "pi pi-fw pi-times",
//       command: () => popup(selectedProduct),
//     },
//     {
//       label: "Activate",
//       icon: "pi pi-fw pi-check",
//       command: () => popup(selectedProduct),
//     },
//     {
//       separator: true,
//     },
//     {
//       label: "Delete",
//       icon: "pi pi-fw pi-trash",
//       command: () => popup(selectedProduct),
//     },
//     {
//       label: "Properties",
//       icon: "pi pi-fw pi-info-circle",
//       command: () => popup(selectedProduct),
//     },
//   ];

//   const popup = (d) => {
//     // cari dulu
//     alert(d.to);
//   };

//   const viewProduct = (product) => {
//     toast.current.show({
//       severity: "info",
//       summary: "Product Selected",
//       detail: product.name,
//     });
//   };

//   const deleteProduct = (product) => {
//     let _products = [...products];

//     _products = _products.filter((p) => p.id !== product.id);

//     toast.current.show({
//       severity: "error",
//       summary: "Product Deleted",
//       detail: product.name,
//     });
//     setProducts(_products);
//   };

//   return (
//     <div className="">
//       <Button
//         label="Add Transfer Withdraw"
//         size="small"
//         outlined
//         className="mb-2"
//         icon="pi pi-plus"
//       />
//       <Toast ref={toast} />
//       <ContextMenu
//         model={menuModel}
//         ref={cm}
//         onHide={() => setSelectedProduct(null)}
//       />
//       <DataTable
//         value={products}
//         tableStyle={{ minWidth: "30rem" }}
//         size="small"
//         paginator
//         rows={8}
//         removableSort
//         resizableColumns
//         columnResizeMode="expand"
//         onContextMenu={(e) => cm.current.show(e.originalEvent)}
//         contextMenuSelection={selectedProduct}
//         onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
//       >
//         <Column field="name" header="Product" sortable></Column>
//         <Column field="to" header="Kepada"></Column>
//         <Column field="date" header="Tanggal"></Column>
//         <Column field="time" header="Pukul"></Column>
//         <Column field="authorize" header="Auth"></Column>
//         <Column
//           field="status"
//           header="Status"
//           body={statusRequest}
//           sortable
//         ></Column>
//         <Column field="type" header="Type"></Column>
//       </DataTable>
//     </div>
//   );
// }

import React, { useState, useEffect, useRef } from "react";
import { classNames } from "primereact/utils";
import { FilterMatchMode, FilterOperator } from "primereact/api";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dropdown } from "primereact/dropdown";
import { InputNumber } from "primereact/inputnumber";
import { Tag } from "primereact/tag";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
import { DataDb } from "@/pages/boxitsPage/i0-componen/data/DataDb";

import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { Button } from "primereact/button";
import ModalForm from "@/pages/boxitsPage/i0-componen/ModalForm";
import ModalProperties from "@/pages/boxitsPage/i0-componen/ModalProperties";
import ModalContentProperties from "../../Product/ModalContentProperties";
import ModalContentDelete from "../../Product/ModalContentDelete";
import ModalContentAddWithdraw from "./ModalContentAddWithdraw";

export default function Transfer() {
  const [administrator, setAdministrator] = useState("root");
  const [customers, setCustomers] = useState(null);
  const [filters, setFilters] = useState(null);
  const [loading, setLoading] = useState(false);
  const [globalFilterValue, setGlobalFilterValue] = useState("");

  const [statuses] = useState([
    "capital",
    "saldo",
    "voucher",
    "data",
    "pppoe",
    "subscribe",
    "promo",
    "prive",
  ]);

  const getSeverity = (status) => {
    switch (status) {
      case "capital":
        return "bg-red-700 text-white";
      case "saldo":
        return "bg-red-500 text-white";
      case "voucher":
        return "bg-green-700 text-white";
      case "data":
        return "bg-green-500 text-white";
      case "pppoe":
        return "bg-green-50 text-green-700";
      case "subscribe":
        return "bg-blue-700 text-white";
      case "promo":
        return "bg-blue-500 text-white";
      case "prive":
        return "bg-blue-50 text-blue-700";

      case "renewal":
        return null;
    }
  };

  useEffect(() => {
    try {
      Promise.resolve(
        setCustomers(DataDb.getData()[0].administrator[0].transaction.withdraw)
      );
    } catch (error) {
      console.log("data tidak di temukan" + error);
    }

    initFilters();
  }, []);

  const initFilters = () => {
    setFilters({
      // global: { value: null, matchMode: FilterMatchMode.CONTAINS },
      name: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.STARTS_WITH }],
      },
      type: {
        operator: FilterOperator.AND,
        constraints: [{ value: "send", matchMode: FilterMatchMode.EQUALS }],
      },
      invoice: {
        operator: FilterOperator.AND,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      date: {
        operator: FilterOperator.AND,
        constraints: [
          {
            value: null,
            // value: new Date(),
            // value: new Date("02/19/2018"),
            matchMode: FilterMatchMode.DATE_IS,
          },
        ],
      },
      product: {
        operator: FilterOperator.OR,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      to_uid: {
        operator: FilterOperator.OR,
        constraints: [{ value: null, matchMode: FilterMatchMode.EQUALS }],
      },
      verified: { value: null, matchMode: FilterMatchMode.EQUALS },
    });
    setGlobalFilterValue("");
  };

  const balanceBodyTemplate = (rowData) => {
    return formatCurrency(rowData.balance);
  };

  const balanceFilterTemplate = (options) => {
    return (
      <InputNumber
        value={options.value}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        mode="currency"
        currency="IDR"
        locale="id-ID"
      />
    );
  };

  const statusBodyTemplate = (rowData) => {
    return (
      <Tag value={rowData.product} className={getSeverity(rowData.product)} />
    );
  };

  const statusFilterTemplate = (options) => {
    return (
      <Dropdown
        value={options.value}
        options={statuses}
        onChange={(e) => options.filterCallback(e.value, options.index)}
        itemTemplate={statusItemTemplate}
        placeholder="Select One"
        className="p-column-filter"
        showClear
      />
    );
  };

  const statusItemTemplate = (option) => {
    return <Tag value={option} className={getSeverity(option)} />;
  };

  const verifiedBodyTemplate = (rowData) => {
    return (
      <i
        className={classNames("pi", {
          "text-green-500 pi-check-circle": rowData.verified,
          "text-red-500 pi-times-circle": !rowData.verified,
        })}
      ></i>
    );
  };

  const verifiedFilterTemplate = (options) => {
    return (
      <div className="flex align-items-center gap-2">
        <label htmlFor="verified-filter" className="font-bold">
          Verified
        </label>
        <TriStateCheckbox
          inputId="verified-filter"
          value={options.value}
          onChange={(e) => options.filterCallback(e.value)}
        />
      </div>
    );
  };
  // -------------------
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => setModalForm3(true),
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => setModalProperties(true),
    },
  ];

  const viewProduct = (product) => {
    toast.current.show({
      severity: "info",
      summary: "Product Selected",
      detail: product.name,
    });
  };

  const deleteProduct = (product) => {
    let _products = [...products];

    _products = _products.filter((p) => p.id !== product.id);

    toast.current.show({
      severity: "error",
      summary: "Product Deleted",
      detail: product.name,
    });
    setProducts(_products);
  };
  // MODAL FORM HAPUS -----------------------------
  const [modalForm3, setModalForm3] = useState(false);
  const properModalForm3 = {
    modal: modalForm3,
    judul: "Delete",
    tombol: "Add Official",
    width: "30vw",
    warna: "danger", // success, danger, warning, info
    modalTutup: (d) => setModalForm3(d),
    content: <ModalContentDelete terpilih={selectedProduct} />,
  };
  // MODAL PROPERTIES -----------------------------
  const [modalProperties, setModalProperties] = useState(false);
  const properModalProperties = {
    modal: modalProperties,
    judul: "Properties",
    tombol: "Add Official",
    modalTutup: (d) => setModalProperties(d),
    content: <ModalContentProperties proper={selectedProduct} />,
  };

  const [modalForm, setModalForm] = useState(false);
  const properModalForm = {
    modal: modalForm,
    judul: "Add Withdraw",
    tombol: "Add Withdraw",
    width: "40vw",
    warna: "primary",
    modalTutup: (d) => setModalForm(d),
    content: <ModalContentAddWithdraw />,
  };
  return (
    <>
      <ModalForm proper={properModalForm} />;
      <ModalForm proper={properModalForm3} />
      <ModalProperties proper={properModalProperties} />
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        // onHide={() => setSelectedProduct(null)}
      />
      <Button
        label={
          administrator == "root" ? properModalForm.tombol : "Request Withdraw"
        }
        icon={administrator == "root" ? "pi pi-plus" : "pi pi-reply"}
        onClick={() => setModalForm(true)}
        className="mb-2"
        size="small"
      />
      <DataTable
        value={customers}
        paginator
        showGridlines
        rows={7}
        loading={loading}
        dataKey="id"
        filters={filters}
        globalFilterFields={[
          "name",
          "country.name",
          "representative.name",
          "balance",
          "status",
        ]}
        emptyMessage="No customers found."
        size="small"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        tableStyle={{ minWidth: "30rem" }}
      >
        <Column
          field="invoice"
          header="Invoice"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="name"
          header="Name"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="from_uid"
          header="Admin"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="resi"
          header="No. Resi"
          filter
          filterPlaceholder="Search by name"
          style={{ minWidth: "12rem" }}
        />
        <Column
          field="verified"
          header="Delivered"
          dataType="boolean"
          bodyClassName="text-center"
          style={{ minWidth: "8rem" }}
          body={verifiedBodyTemplate}
          filter
          filterElement={verifiedFilterTemplate}
        />
      </DataTable>
    </>
  );
}
