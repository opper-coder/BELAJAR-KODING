import { TabView, TabPanel } from "primereact/tabview";
import { useState } from "react";
import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import Position from "./comp/position/Position";
import Withdraw from "./comp/product/withdraw/Withdraw";
import Product from "./comp/Product/Product";
import Accounting from "../i0-componen/Accounting";

export default function Transaction() {
  const [administrator, setAdministrator] = useState("root");

  const propsJumbo = {
    title: "Product",
    subtitle: "Managemen Product, Position, Project, Equipmen, tool, Locate, ",
    column1: ["Generate Entity", "Generate Price", "Generate Property"],
    column2: ["Assign Entity", "Assign Price", "Edit Data"],
    column3: [],
  };

  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      <Accounting />
      <div>
        <TabView>
          {administrator == "root" ? (
            <TabPanel header="Withdraw">
              <Withdraw />
            </TabPanel>
          ) : (
            ""
          )}
          <TabPanel header="Product">
            <Product />
          </TabPanel>
          <TabPanel header="Position">
            <Position />
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
