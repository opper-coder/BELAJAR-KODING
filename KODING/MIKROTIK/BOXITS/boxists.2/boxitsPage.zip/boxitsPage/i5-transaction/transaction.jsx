/* eslint-disable react-hooks/exhaustive-deps */
import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import Position from "./comp/Position/Position";
import Withdraw from "./comp/product/withdraw/Withdraw";
import Product from "./comp/Product/Product";
import { TabView, TabPanel } from "primereact/tabview";
import { useState, useEffect } from "react";
import { Accounting } from "../i0-componen/data/Accounting";
import Evaluate from "./comp/Product/Evaluate";
// import { TransactionDb } from "../i0-componen/data/TransactionDb";

export default function Transaction() {
  const [administrator, setAdministrator] = useState("root");
  const [kondisiKapital, setKondisiKapital] = useState({
    category: "product",
    product: "voucher",
    position: "admin",
    uid: "uid7679",
    region: "banggai laut",
    locate: "Banggai - Timbong",
    status: "delivered",
    flow: "in",
    // month_of: true,
  });

  const propsJumbo = {
    title: "Product",
    subtitle: "Managemen Product, Position, Project, Equipmen, tool, Locate, ",
    column1: ["Generate Entity", "Generate Price", "Generate Property"],
    column2: ["Assign Entity", "Assign Price", "Edit Data"],
    column3: [],
  };

  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      {/* ------------------------------------ */}
      {Accounting.haloAccounting()}
      {/* ------------------------------------ */}
      <div>
        <TabView>
          <TabPanel header="Product">
            <Product />
          </TabPanel>
          <TabPanel header="Position">
            <Position />
          </TabPanel>
          {administrator == "root" ? (
            <TabPanel header="Withdraw">
              <Withdraw />
            </TabPanel>
          ) : (
            ""
          )}
          <TabPanel header="Evaluate">
            <Evaluate />
          </TabPanel>
        </TabView>
      </div>
    </>
  );
}
