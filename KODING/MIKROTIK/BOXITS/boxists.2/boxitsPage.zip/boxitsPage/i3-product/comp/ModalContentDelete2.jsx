export default function ModalContentDelete2(props) {
  return (
    <>
      Apakah anda akan Menghapus Row data <b>{props?.terpilih?.name}</b>
    </>
  );
}
