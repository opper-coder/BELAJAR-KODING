export default function ModalContentDelete(props) {
  console.log(props);
  return (
    <>
      Apakah anda akan Menghapus Row data <b>{props?.terpilih?.label}</b>
    </>
  );
}
