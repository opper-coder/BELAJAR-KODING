import React from "react";

export default function PageDevice() {
  return <div>pageDevice</div>;
}
