/* eslint-disable react-hooks/exhaustive-deps */
import TableDynamic from "../../i0-componen/tableDynamic";
import { useEffect } from "react";

export default function PageCapital(props) {
  const columns = [
    { field: "code", header: "Id Product" },
    { field: "name", header: "Nama" },
    { field: "date", header: "Tanggal" },
    { field: "price", header: "Nilai" },
    { field: "pricing", header: "Penyesuaian" },
    { field: "locate", header: "Lokasi" },
  ];
  useEffect(() => {
    props.kolom(columns);
  }, []);

  return (
    <>
      <TableDynamic tabel={props.tabel} />;
    </>
  );
}
