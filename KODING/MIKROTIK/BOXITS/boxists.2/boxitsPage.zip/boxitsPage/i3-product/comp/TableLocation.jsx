import { useState, useEffect, useRef } from "react";
import { Button } from "primereact/button";
import { TreeTable } from "primereact/treetable";
import { Column } from "primereact/column";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import { InputText } from "primereact/inputtext";
import { DataDb } from "../../i0-componen/data/DataDb";

export default function TableLocation() {
  const [nodes, setNodes] = useState([]);
  const [globalFilter, setGlobalFilter] = useState("");
  const [expandedKeys, setExpandedKeys] = useState(null);
  const [selectedNodeKey, setSelectedNodeKey] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);

  useEffect(() => {
    let files = [];

    for (let i = 0; i < 50; i++) {
      let node = {
        key: i,
        data: {
          name: "Item " + i,
          size: Math.floor(Math.random() * 1000) + 1 + "kb",
          type: "Type " + i,
        },
        children: [
          {
            key: i + " - 0",
            data: {
              name: "Item " + i + " - 0",
              size: Math.floor(Math.random() * 1000) + 1 + "kb",
              type: "Type " + i,
            },
          },
        ],
      };

      files.push(node);
    }

    setNodes(files);
  }, []);

  // const paginatorLeft = <Button type="button" icon="pi pi-refresh" text />;
  const paginatorRight = <Button type="button" icon="pi pi-download" text />;
  // ---
  const menu = [
    {
      label: "Toggle",
      icon: "pi pi-sort",
      command: () => {
        let _expandedKeys = { ...expandedKeys };

        if (_expandedKeys[selectedNodeKey])
          delete _expandedKeys[selectedNodeKey];
        else _expandedKeys[selectedNodeKey] = true;

        setExpandedKeys(_expandedKeys);
      },
    },
    {
      label: "Add Location",
      icon: "pi pi-plus",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Edit",
      icon: "pi pi-pencil",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Hapus",
      icon: "pi pi-trash",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
    {
      label: "Properties",
      icon: "pi pi-info-circle",
      command: () => {
        toast.current.show({
          severity: "success",
          summary: "Node Key",
          detail: selectedNodeKey,
        });
      },
    },
  ];

  useEffect(() => {
    DataDb.getLocation().then((data) => setNodes(data));
  }, []);

  // filter
  const getHeader = () => {
    return (
      <div className="flex justify-content-end">
        <div className="p-input-icon-left">
          <i className="pi pi-search"></i>
          <InputText
            type="search"
            onInput={(e) => setGlobalFilter(e.target.value)}
            placeholder="Cari Nama Lokasi"
          />
        </div>
      </div>
    );
  };

  let header = getHeader();

  return (
    <div className="">
      <Toast ref={toast} />
      <ContextMenu
        model={menu}
        ref={cm}
        onHide={() => setSelectedNodeKey(null)}
      />
      <TreeTable
        value={nodes}
        paginator
        rows={5}
        rowsPerPageOptions={[5, 10, 25, 50]}
        paginatorTemplate="RowsPerPageDropdown FirstPageLink PrevPageLink CurrentPageReport NextPageLink LastPageLink"
        currentPageReportTemplate="{first} to {last} of {totalRecords}"
        // paginatorLeft={paginatorLeft}
        paginatorRight={paginatorRight}
        tableStyle={{ minWidth: "50rem" }}
        expandedKeys={expandedKeys}
        onToggle={(e) => setExpandedKeys(e.value)}
        contextMenuSelectionKey={selectedNodeKey}
        onContextMenuSelectionChange={(event) =>
          setSelectedNodeKey(event.value)
        }
        onContextMenu={(event) => cm.current.show(event.originalEvent)}
        globalFilter={globalFilter}
        header={header}
        filterMode="strict"
        stripedRows
      >
        <Column field="name" header="Name" expander></Column>
        <Column field="official" header="Official"></Column>
        <Column field="type" header="Type"></Column>
      </TreeTable>
    </div>
  );
}
