import React, { useState, useEffect, useRef } from "react";
import { FilterMatchMode, FilterOperator } from "primereact/api";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { DataDb } from "../../i0-componen/data/DataDb";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import ModalContentFormEdit3 from "./ModalContentFormEdit3";
import ModalContentProperties3 from "./ModalContentProperties3";
import ModalContentDelete3 from "./ModalContentDelete3";
import ModalForm from "../../i0-componen/ModalForm";
import ModalProperties from "../../i0-componen/ModalProperties";

export default function TableProject() {
  const [customers, setCustomers] = useState(null);
  const [filters, setFilters] = useState({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    name: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    product_id: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    price: { value: null, matchMode: FilterMatchMode.EQUALS },
  });
  const [loading, setLoading] = useState(true);
  const [globalFilterValue, setGlobalFilterValue] = useState("");

  useEffect(() => {
    DataDb.getProject().then((data) => {
      setCustomers(getCustomers(data));
      setLoading(false);
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const getCustomers = (data) => {
    return [...(data || [])].map((d) => {
      d.date = new Date(d.date);

      return d;
    });
  };

  const onGlobalFilterChange = (e) => {
    const value = e.target.value;
    let _filters = { ...filters };

    _filters["global"].value = value;

    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  const renderHeader = () => {
    return (
      <div className="flex justify-content-end">
        <span className="p-input-icon-left">
          <i className="pi pi-search" />
          <InputText
            value={globalFilterValue}
            onChange={onGlobalFilterChange}
            placeholder="Cari Official"
          />
        </span>
      </div>
    );
  };

  const header = renderHeader();
  // --------------------------------------------------------
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Edit",
      icon: "pi pi-fw pi-pencil",
      command: () => setModalEdit(true),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => setModalForm3(true),
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => setModalProperties(true),
    },
  ];

  const viewProduct = (product) => {
    alert(product.name);
  };

  // ----------------------------------------------------------------
  // MODAL FORM HAPUS -----------------------------
  const [modalForm3, setModalForm3] = useState(false);
  const properModalForm3 = {
    modal: modalForm3,
    judul: "Delete",
    tombol: "Add Official",
    width: "30vw",
    warna: "danger", // success, danger, warning, info
    modalTutup: (d) => setModalForm3(d),
    content: <ModalContentDelete3 terpilih={selectedProduct} />,
  };
  // MODAL PROPERTIES -----------------------------
  const [modalProperties, setModalProperties] = useState(false);
  const properModalProperties = {
    modal: modalProperties,
    judul: "Properties",
    tombol: "Add Official",
    modalTutup: (d) => setModalProperties(d),
    content: <ModalContentProperties3 proper={selectedProduct} />,
  };
  // MODAL FORM EDIT -----------------------------
  const [modalEdit, setModalEdit] = useState(false);
  const properModalEdit = {
    modal: modalEdit,
    judul: "Edit Administrator",
    tombol: "Edit Data Official",
    tombol2: "Add Member",
    modalTutup: (d) => setModalEdit(d),
    content: <ModalContentFormEdit3 data={selectedProduct} />,
  };
  return (
    <div className="">
      <ModalForm proper={properModalForm3} />
      <ModalForm proper={properModalEdit} />
      <ModalProperties proper={properModalProperties} />
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        // onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={customers}
        paginator
        rows={14}
        dataKey="id"
        filters={filters}
        filterDisplay="row"
        loading={loading}
        globalFilterFields={["name", "position"]}
        emptyMessage="No customers found."
        size="small"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        stripedRows
      >
        <Column field="name" header="Name" style={{ minWidth: "10rem" }} />
        <Column field="price" header="Value" style={{ minWidth: "10rem" }} />
        <Column
          field="personnel"
          header="Personel"
          style={{ minWidth: "10rem" }}
        />
        <Column
          field="duration"
          header="Duration"
          style={{ minWidth: "10rem" }}
        />
        <Column
          field="project_id"
          header="Code"
          style={{ minWidth: "10rem" }}
        />
      </DataTable>
    </div>
  );
}
