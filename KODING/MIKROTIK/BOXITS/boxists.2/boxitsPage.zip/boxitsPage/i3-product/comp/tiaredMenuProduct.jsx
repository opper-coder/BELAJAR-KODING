import React, { useRef } from "react";
import { Button } from "primereact/button";
import { TieredMenu } from "primereact/tieredmenu";
import { useState } from "react";

export default function TiaredMenuProduct(props) {
  const menu = useRef(null);
  const [selectedMenu, setSelectedMenu] = useState();
  const items = [
    {
      label: "Product",
      icon: "pi pi-box mr-3",
      items: [
        {
          label: "Capital",
          icon: "pi pi-box mr-3",
          command: () => setSelectedMenu("Capital"),
        },
        {
          label: "Voucher",
          icon: "pi pi-box mr-3",
          command: () => setSelectedMenu("Voucher"),
        },
        {
          label: "Data",
          icon: "pi pi-box mr-3",
          command: () => setSelectedMenu("Data"),
        },
        {
          label: "PPPoE",
          icon: "pi pi-box mr-3",
          command: () => setSelectedMenu("PPPoE"),
        },
        {
          label: "Promo",
          icon: "pi pi-box mr-3",
          command: () => setSelectedMenu("Promo"),
        },
      ],
    },
    {
      label: "Position",
      icon: "pi pi-user mr-3",
      items: [
        {
          label: "Region Head",
          icon: "pi pi-user mr-3",
          command: () => setSelectedMenu("Region Head"),
        },
        {
          label: "Admin",
          icon: "pi pi-user mr-3",
          command: () => setSelectedMenu("Admin"),
        },
        {
          label: "Agency",
          icon: "pi pi-user mr-3",
          command: () => setSelectedMenu("Agency"),
        },
        {
          label: "Reseller",
          icon: "pi pi-user mr-3",
          command: () => setSelectedMenu("Reseller"),
        },
        {
          label: "Technician",
          icon: "pi pi-user mr-3",
          command: () => setSelectedMenu("Technician"),
        },
        {
          label: "Freelancer",
          icon: "pi pi-user mr-3",
          command: () => setSelectedMenu("Freelancer"),
        },
        {
          label: "Investor",
          icon: "pi pi-user mr-3",
          command: () => setSelectedMenu("Investor"),
        },
      ],
    },
    {
      label: "Project",
      icon: "pi pi-align-left mr-3",
      items: [
        {
          label: "Topology",
          icon: "pi pi-align-left mr-3",
          command: () => setSelectedMenu("Topology"),
        },
        {
          label: "Lobby",
          icon: "pi pi-align-left mr-3",
          command: () => setSelectedMenu("Lobby"),
        },
        {
          label: "Mapping",
          icon: "pi pi-align-left mr-3",
          price: 400000,
          command: () => setSelectedMenu("Mapping"),
        },
        {
          label: "Install Router",
          icon: "pi pi-align-left mr-3",
          price: 10000,
          command: () => setSelectedMenu("Install Router"),
          unit: "unit",
        },
        {
          label: "Install Backbone",
          icon: "pi pi-align-left mr-3",
          price: 100000,
          command: () => setSelectedMenu("Install Backbone"),
          unit: "km",
        },
        {
          label: "Branch Wiring",
          icon: "pi pi-align-left mr-3",
          price: 20000,
          command: () => setSelectedMenu("Branch Wiring"),
          unit: "node",
        },
        {
          label: "Spliching",
          icon: "pi pi-align-left mr-3",
          price: 10000,
          command: () => setSelectedMenu("Spliching"),
          unit: "node",
        },
        {
          label: "Tower",
          icon: "pi pi-align-left mr-3",
          price: 50000,
          command: () => setSelectedMenu("Tower"),
          unit: "item",
        },
        {
          label: "Cable Pole",
          icon: "pi pi-align-left mr-3",
          price: 30000,
          command: () => setSelectedMenu("Cable Pole"),
          unit: "items",
        },
        {
          label: "Maintenance",
          icon: "pi pi-align-left mr-3",
          price: 30000,
          command: () => setSelectedMenu("Maintenance"),
          unit: "day",
        },
        {
          label: "Checking",
          icon: "pi pi-align-left mr-3",
          price: 50000,
          command: () => setSelectedMenu("Checking"),
          unit: "day",
        },
        {
          label: "Patroli",
          icon: "pi pi-align-left mr-3",
          price: 50000,
          command: () => setSelectedMenu("Patroli"),
          unit: "day/km",
        },
      ],
    },
    {
      label: "Device",
      icon: "pi pi-apple mr-3",
      command: () => setSelectedMenu("Device"),
      itemsX: [
        {
          label: "Mikrotik",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Mikrotik"),
          merk: [],
        },
        {
          label: "OpenWRT",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("OpenWRT"),
          merk: [],
        },
        {
          label: "Ubiquity",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Ubiquity"),
          merk: [],
        },
        {
          label: "OLT",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("OLT"),
          merk: [],
        },
        {
          label: "SFP",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("SFP"),
          merk: [],
        },
        {
          label: "HTB",
          icon: "pi pi-apple mr-3",
          merk: [],
          command: () => setSelectedMenu("HTB"),
        },
        {
          label: "Sw Hub",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Sw Hub"),
          merk: [],
        },
        {
          label: "Sw Mngable",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Sw Mngable"),
          merk: [],
        },
        {
          label: "Router Epon",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Router Epon"),
          merk: [],
        },
        {
          label: "Router Gpon",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Router Gpon"),
          merk: [],
        },
        {
          label: "Router Outdoor",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Router Outdoor"),
          merk: [],
        },
        {
          label: "Router Indoor",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Router Indoor"),
          merk: [],
        },
        {
          label: "Cover Split Ratio",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Cover Split Ratio"),
          merk: [],
        },
        {
          label: "Cover ODP",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Cover ODP"),
          merk: [],
        },
        {
          label: "Box Server",
          icon: "pi pi-apple mr-3",
          command: () => setSelectedMenu("Box Server"),
          merk: [],
        },
      ],
    },

    {
      label: "Connection",
      icon: "pi pi-window-minimize mr-3",
      command: () => setSelectedMenu("Connection"),
    },
    {
      label: "Equipment",
      icon: "pi pi-briefcase mr-3",
      command: () => setSelectedMenu("Equipment"),
      itemsX: [
        {
          label: "Splicer",
          icon: "pi pi-briefcase mr-3",
          merk: [],
          command: () => setSelectedMenu("Splicer"),
        },
        {
          label: "OPM",
          icon: "pi pi-briefcase mr-3",
          merk: [],
          command: () => setSelectedMenu("OPM"),
        },
        {
          label: "Laser Beam",
          icon: "pi pi-briefcase mr-3",
          merk: [],
          command: () => setSelectedMenu("Laser Beam"),
        },
        {
          label: "OTDR",
          icon: "pi pi-briefcase mr-3",
          merk: [],
          command: () => setSelectedMenu("OTDR"),
        },
        {
          label: "Fiber Toolkit",
          icon: "pi pi-briefcase mr-3",
          merk: [],
          command: () => setSelectedMenu("Fiber Toolkit"),
        },
        {
          label: "Cleaver",
          icon: "pi pi-briefcase mr-3",
          merk: [],
          command: () => setSelectedMenu("Cleaver"),
        },
      ],
    },
    {
      label: "Tools",
      icon: "pi pi-wrench mr-3",
      command: () => setSelectedMenu("Tools"),
    },
    {
      label: "Facility",
      icon: "pi pi-car mr-3",
      command: () => setSelectedMenu("Facility"),
      itemsX: [
        {
          label: "Handphone",
          icon: "pi pi-car mr-3",
          merk: [],
          command: () => setSelectedMenu("Handphone"),
        },
        {
          label: "Tablet",
          icon: "pi pi-car mr-3",
          merk: [],
          command: () => setSelectedMenu("Tablet"),
        },
        {
          label: "Computer",
          icon: "pi pi-car mr-3",
          merk: [],
          command: () => setSelectedMenu("Computer"),
        },
        {
          label: "Desk",
          icon: "pi pi-car mr-3",
          merk: [],
          command: () => setSelectedMenu("Desk"),
        },
        {
          label: "Office",
          icon: "pi pi-car mr-3",
          merk: [],
          command: () => setSelectedMenu("Office"),
        },
        {
          label: "Transportation",
          icon: "pi pi-car mr-3",
          merk: [],
          command: () => setSelectedMenu("Transportation"),
        },
      ],
    },
    {
      label: "Location",
      icon: "pi pi-map-marker mr-3",
      command: () => setSelectedMenu("Location"),
    },
  ];

  props.selectedMenuTiered(selectedMenu);

  return (
    <>
      <TieredMenu model={items} popup ref={menu} breakpoint="767px" />
      <Button
        label="Select Product"
        icon="pi pi-bars"
        onClick={(e) => menu.current.toggle(e)}
        outlined
        // size="small"
      />
    </>
  );
}
