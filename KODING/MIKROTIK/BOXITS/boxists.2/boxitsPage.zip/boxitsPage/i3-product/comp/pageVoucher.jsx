import TableDynamic from "../../i0-componen/tableDynamic";
import { useEffect } from "react";

export default function PageVoucher(props) {
  const columns = [
    { field: "code", header: "Id Product" },
    { field: "name", header: "Nama" },
    { field: "price", header: "Nilai" },
    { field: "pricing", header: "Penyesuaian" },
    { field: "locate", header: "Lokasi" },
    { field: "bandwidth", header: "Bandwidth" },
    { field: "quota", header: "Quota" },
    { field: "durationName", header: "Durasi" },
    { field: "hp", header: "Jumlah Hp" },
  ];

  useEffect(() => {
    props.kolom(columns);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <TableDynamic tabel={props.tabel} />;
    </>
  );
}
