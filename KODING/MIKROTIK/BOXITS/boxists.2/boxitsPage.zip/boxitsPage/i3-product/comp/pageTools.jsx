import TableDynamic from "../../i0-componen/tableDynamic";
import { useEffect } from "react";

export default function PageTools(props) {
  const columns = [
    { field: "name", header: "Id Product" },
    { field: "name", header: "Nama" },
    { field: "name", header: "Harga" },
    { field: "name", header: "Penyesuaian" },
    { field: "name", header: "Tanggal" },
    { field: "name", header: "Lokasi" },
    { field: "name", header: "Lokait" },
  ];

  useEffect(() => {
    props.kolom(columns);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      <TableDynamic tabel={props.tabel} />;
    </>
  );
}
