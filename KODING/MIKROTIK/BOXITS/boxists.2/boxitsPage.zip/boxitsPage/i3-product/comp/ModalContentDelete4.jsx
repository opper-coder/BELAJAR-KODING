export default function ModalContentDelete4(props) {
  return (
    <>
      Apakah anda akan Menghapus Row data <b>{props?.terpilih?.name}</b>
    </>
  );
}
