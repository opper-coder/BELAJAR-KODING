export default function ModalContentDelete3(props) {
  return (
    <>
      Apakah anda akan Menghapus Row data <b>{props?.terpilih?.name}</b>
    </>
  );
}
