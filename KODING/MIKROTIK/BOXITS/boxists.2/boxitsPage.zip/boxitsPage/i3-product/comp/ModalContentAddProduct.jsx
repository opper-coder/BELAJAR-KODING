export default function ModalContentForm() {
  return (
    <>
      Product
      <>
        name: "VC-2000" <br />
        price: 2000, <br />
        bandwidth: "1mb/s" <br />
        quota: "Unlimited", <br />
        duration: "2 jam",
        <br />
        user: 1,
        <br />
        category: "Voucher",
      </>
      <>
        id: 1,
        <br />
        product_id: "PRD1",
        <br />
        date: "2015-09-13",
        <br />
        adjusment: [],
      </>
    </>
  );
}
