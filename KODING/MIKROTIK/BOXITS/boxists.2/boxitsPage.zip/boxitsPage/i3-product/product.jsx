import { TabPanel, TabView } from "primereact/tabview";
import { useState } from "react";
import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import TableProduct from "./comp/TableProduct";
import { Button } from "primereact/button";
import TablePosition from "./comp/TablePosition";
import TableLocation from "./comp/TableLocation";
import TableProject from "./comp/TableProject";
import TableAppliance from "./comp/TableAppliance";
import ModalContentAddProduct from "./comp/ModalContentAddProduct";
import ModalForm from "../i0-componen/ModalForm";

export default function Product() {
  // persiapan session login ----->
  const [administrator, setAdministrator] = useState("root");
  // jumbotron ----->
  const propsJumbo = {
    title: "Product",
    subtitle: "Managemen Product, Position, Project, Equipmen, tool, Locate, ",
    column1: ["Generate Entity", "Generate Price", "Generate Property"],
    column2: ["Assign Entity", "Assign Price", "Edit Data"],
    column3: [],
  };

  // MODAL FORM -----------------------------
  const [modalForm, setModalForm] = useState(false);
  const [modalForm2, setModalForm2] = useState(false);
  const [modalForm3, setModalForm3] = useState(false);
  const [modalForm4, setModalForm4] = useState(false);
  const properModalForm = {
    modal: modalForm,
    judul: "Generate Product",
    tombol: "Generate Product",
    width: "40vw",
    warna: "primary",
    modalTutup: (d) => setModalForm(d),
    content: <ModalContentAddProduct />,
  };
  const properModalForm2 = {
    modal: modalForm2,
    judul: "Generate Position",
    tombol: "Generate Position",
    width: "40vw",
    warna: "primary",
    modalTutup: (d) => setModalForm2(d),
    content: <ModalContentAddProduct />,
  };
  const properModalForm3 = {
    modal: modalForm3,
    judul: "Generate Project",
    tombol: "Generate Project",
    width: "40vw",
    warna: "primary",
    modalTutup: (d) => setModalForm3(d),
    content: <ModalContentAddProduct />,
  };
  const properModalForm4 = {
    modal: modalForm4,
    judul: "Generate Appliance",
    tombol: "Generate Appliance",
    width: "40vw",
    warna: "primary",
    modalTutup: (d) => setModalForm4(d),
    content: <ModalContentAddProduct />,
  };
  // ----------------------------------------

  return (
    <>
      <ModalForm proper={properModalForm} />;
      <ModalForm proper={properModalForm2} />;
      <ModalForm proper={properModalForm3} />;
      <ModalForm proper={properModalForm4} />;
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      <TabView>
        <TabPanel header="Product">
          <Button
            label={
              administrator == "root"
                ? properModalForm.tombol
                : "Request Product"
            }
            icon={administrator == "root" ? "pi pi-plus" : "pi pi-reply"}
            onClick={() => setModalForm(true)}
            className="mb-3"
            size="small"
          />
          <TableProduct />
        </TabPanel>
        <TabPanel header="Position">
          <Button
            label={
              administrator == "root"
                ? properModalForm2.tombol
                : "Request Product"
            }
            icon={administrator == "root" ? "pi pi-plus" : "pi pi-reply"}
            onClick={() => setModalForm2(true)}
            className="mb-3"
            size="small"
          />
          <TablePosition />
        </TabPanel>
        <TabPanel header="Project">
          <Button
            label={
              administrator == "root"
                ? properModalForm3.tombol
                : "Request Product"
            }
            icon={administrator == "root" ? "pi pi-plus" : "pi pi-reply"}
            onClick={() => setModalForm3(true)}
            className="mb-3"
            size="small"
          />
          <TableProject />
        </TabPanel>
        <TabPanel header="Appliance">
          <Button
            label={
              administrator == "root"
                ? properModalForm4.tombol
                : "Request Product"
            }
            icon={administrator == "root" ? "pi pi-plus" : "pi pi-reply"}
            onClick={() => setModalForm4(true)}
            className="mb-3"
            size="small"
          />
          <TableAppliance />
        </TabPanel>
        <TabPanel header="Location">
          <TableLocation />
        </TabPanel>
      </TabView>
    </>
  );
}
