/* eslint-disable react-hooks/exhaustive-deps */
import { useState, useEffect } from "react";
import { Button } from "primereact/button";
import { BoxitsDb } from "../i0-componen/data/BoxitsDb";
import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import TiaredMenuProduct from "./comp/tiaredMenuProduct";
import PageCapital from "./comp/pageCapital";
import PageVoucher from "./comp/pageVoucher";
import PageData from "./comp/pageData";
import PagePppoe from "./comp/pagePppoe";
import PagePromo from "./comp/pagePromo";
import PageRegion from "./comp/pageRegion";
import PageAdmin from "./comp/pageAdmin";
import PageAgency from "./comp/pageAgency";
import PageReseller from "./comp/pageReseller";
import PageTechnician from "./comp/pageTechnician";
import PageFreelancer from "./comp/pageFreelancer";
import PageInvestor from "./comp/pageInvestor";
import PageTopology from "./comp/pageTopology";
import PageLobby from "./comp/pageLobby";
import PageMapping from "./comp/pageMapping";
import PageInstallRouter from "./comp/pageInstallRouter";
import PageInstallBackbone from "./comp/pageInstallBackbone";
import PageBranchWiring from "./comp/pageBranchWiring";
import PageSpliching from "./comp/pageSpliching";
import PageTower from "./comp/pageTower";
import PageCablePole from "./comp/pageCablePole";
import PageMaintenance from "./comp/pageMaintenance";
import PageChecking from "./comp/pageChecking";
import PagePatroli from "./comp/pagePatroli";
import PageAppliance from "./comp/pageDevice";
import PageEquipment from "./comp/pageEquipment";
import PageTools from "./comp/pageTools";
import PageFacility from "./comp/pageFacility";
import PageLocation from "./comp/pageLocation";
import PageConnection from "./comp/pageConnection";

export default function Products(props) {
  // persiapan session login ----->
  const [administrator, setAdministrator] = useState("root");
  // jumbotron ----->
  const propsJumbo = {
    title: "Product",
    subtitle: "Managemen Product, Position, Project, Equipmen, tool, Locate, ",
    column1: ["Generate Entity", "Generate Price", "Generate Property"],
    column2: ["Assign Entity", "Assign Price", "Edit Data"],
    column3: [],
  };
  // tabel ----->
  const [boxits, setBoxits] = useState([]);
  const [boxitsPage, setBoxitsPage] = useState([]);
  const [listContex, setListContex] = useState([]);
  const [menuSelected, setMenuSelected] = useState();
  const [columns, setColumns] = useState([]);

  useEffect(() => {
    BoxitsDb.getProducts().then((data) => setBoxits(data));
  }, []);

  useEffect(() => {
    switch (menuSelected) {
      case "Capital":
        setBoxitsPage(boxits[1]["items"][0]["items"]);
        break;
      case "Voucher":
        setBoxitsPage(boxits[1]["items"][1]["items"]);
        break;
      case "Data":
        setBoxitsPage(boxits[2]["items"]);
        break;
      case "PPPoE":
        setBoxitsPage(boxits[3]["items"]);
        break;
      case "Promo":
        setBoxitsPage(boxits[4]["items"]);
        break;
      case "Region Head":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Admin":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Agency":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Reseller":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Technician":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Freelancer":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Investor":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Topology":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Lobby":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Mapping":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Install Router":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Install Backbone":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Branch Wiring":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Spliching":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Tower":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Cable Pole":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Maintenance":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Checking":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Patroli":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Device":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Connection":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Equipment":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Tools":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Facility":
        setBoxitsPage(boxits[0]["items"]);
        break;
      case "Location":
        setBoxitsPage(boxits[0]["items"]);
        break;
      default:
        break;
    }
  });

  const propsTableRoot = {
    db: boxitsPage,
    baris: 9,
    satu: (data) => setListContex(data),
    columns: columns,
    contex: [
      {
        label: "Edit",
        icon: "pi pi-fw pi-pencil",
        command: () => popup(),
      },
      {
        label: "Verify",
        icon: "pi pi-fw pi-eraser",
        command: () => popup(),
      },
      {
        label: "Delete",
        icon: "pi pi-fw pi-trash",
        command: () => popup(),
      },
      {
        label: "Properties",
        icon: "pi pi-fw pi-info-circle",
        command: () => popup(),
      },
    ],
  };
  const propsTableAdmin = {
    db: boxitsPage,
    baris: 9,
    satu: (data) => setListContex(data),
    columns: columns,
    contex: [
      {
        label: "Adjustment",
        icon: "pi pi-fw pi-pencil",
        command: () => popup(),
      },
      {
        label: "Remove Adjust",
        icon: "pi pi-fw pi-eraser",
        command: () => popup(),
      },
      {
        label: "Properties",
        icon: "pi pi-fw pi-info-circle",
        command: () => popup(),
      },
    ],
  };

  const popup = () => {
    // key data yang di ambil(kayaknya id)
    alert(listContex.name);
  };

  const pilihHalaman = (d, p) => {
    switch (d) {
      case "Capital":
        return <PageCapital tabel={p} kolom={(d) => setColumns(d)} />;
      case "Voucher":
        return <PageVoucher tabel={p} kolom={(d) => setColumns(d)} />;
      case "Data":
        return <PageData tabel={p} kolom={(d) => setColumns(d)} />;
      case "PPPoE":
        return <PagePppoe tabel={p} kolom={(d) => setColumns(d)} />;
      case "Promo":
        return <PagePromo tabel={p} kolom={(d) => setColumns(d)} />;
      case "Region Head":
        return <PageRegion tabel={p} kolom={(d) => setColumns(d)} />;
      case "Admin":
        return <PageAdmin tabel={p} kolom={(d) => setColumns(d)} />;
      case "Agency":
        return <PageAgency tabel={p} kolom={(d) => setColumns(d)} />;
      case "Reseller":
        return <PageReseller tabel={p} kolom={(d) => setColumns(d)} />;
      case "Technician":
        return <PageTechnician tabel={p} kolom={(d) => setColumns(d)} />;
      case "Freelancer":
        return <PageFreelancer tabel={p} kolom={(d) => setColumns(d)} />;
      case "Investor":
        return <PageInvestor tabel={p} kolom={(d) => setColumns(d)} />;
      case "Topology":
        return <PageTopology tabel={p} kolom={(d) => setColumns(d)} />;
      case "Lobby":
        return <PageLobby tabel={p} kolom={(d) => setColumns(d)} />;
      case "Mapping":
        return <PageMapping tabel={p} kolom={(d) => setColumns(d)} />;
      case "Install Router":
        return <PageInstallRouter tabel={p} kolom={(d) => setColumns(d)} />;
      case "Install Backbone":
        return <PageInstallBackbone tabel={p} kolom={(d) => setColumns(d)} />;
      case "Branch Wiring":
        return <PageBranchWiring tabel={p} kolom={(d) => setColumns(d)} />;
      case "Spliching":
        return <PageSpliching tabel={p} kolom={(d) => setColumns(d)} />;
      case "Tower":
        return <PageTower tabel={p} kolom={(d) => setColumns(d)} />;
      case "Cable Pole":
        return <PageCablePole tabel={p} kolom={(d) => setColumns(d)} />;
      case "Maintenance":
        return <PageMaintenance tabel={p} kolom={(d) => setColumns(d)} />;
      case "Checking":
        return <PageChecking tabel={p} kolom={(d) => setColumns(d)} />;
      case "Patroli":
        return <PagePatroli tabel={p} kolom={(d) => setColumns(d)} />;
      case "Device":
        return <PageAppliance tabel={p} kolom={(d) => setColumns(d)} />;
      case "Connection":
        return <PageConnection tabel={p} kolom={(d) => setColumns(d)} />;
      case "Equipment":
        return <PageEquipment tabel={p} kolom={(d) => setColumns(d)} />;
      case "Tools":
        return <PageTools tabel={p} kolom={(d) => setColumns(d)} />;
      case "Facility":
        return <PageFacility tabel={p} kolom={(d) => setColumns(d)} />;
      case "Location":
        return <PageLocation tabel={p} kolom={(d) => setColumns(d)} />;
      // default:
      //   break;
    }
  };
  const adminPage = (admin, props) => {
    if (admin === "root") {
      return (
        <>
          <Button
            label={`Generate Entity ${menuSelected}`}
            className=" mb-3"
            icon="pi pi-plus"
            outlinedx
            size="small"
          />
          {pilihHalaman(menuSelected, propsTableRoot)}
        </>
      );
    } else {
      return <>{pilihHalaman(menuSelected, propsTableAdmin)}</>;
    }
  };
  const pilihProps = (d) => {
    if (d === "root") {
      return propsTableRoot;
    } else {
      return propsTableAdmin;
    }
  };
  // --------------------
  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      <div className="flex w-full gap-2 mb-2">
        <TiaredMenuProduct selectedMenuTiered={(d) => setMenuSelected(d)} />
      </div>
      <div className="w-full">
        {menuSelected === undefined ? (
          <div className="card w-full bg-yellow-100 py-8 mt-2">
            Tampilkan data dengan klik Tombol <b>Select Product</b>
          </div>
        ) : (
          <div className="card">{adminPage(administrator, pilihProps)}</div>
        )}
      </div>

      {/* ---------------------------------------------------------------------- */}
      <div className="card bg-primary">
        PR:
        <ul>
          <li>pada tabel admin ada sort lokasi</li>
          <li>ada tabel perbandingan</li>
          <li>field harus ada lokasi untuk penyesuaian</li>
          <li>Bikin database Lokasi</li>
        </ul>
        {/* 
penyesuaian
- ROOT
    - tabel penyesuaian
    - pilih lokasi
    - lihat daftar request 
    - field response
    - evaluasi:
        - lihat perbedaan harga tiap lokasi
        - sorting lokasi
        - sorting termurah > termahal pada product terpilih
    - ada tombol lihat perbandingan dan evaluasi
- ADMIN
    - lihat tabel product
    - field penyesuaian > Ubah
    - field status
--------------------------------------------
pencarian sort
    - request
    - unit
    - termurah 
    - termahal
    - lokasi region

tombol perbandingan
    - tabel perbandingan
    - field lokasi di tabel perbandingan
refactor
    - apakah looping kolom bisa di per pendek lagi tanpa halaman khusus
    - atau biarkan saja seperti itu sudah bagus
    --------------------------------------------
        */}
      </div>
    </>
  );
}
