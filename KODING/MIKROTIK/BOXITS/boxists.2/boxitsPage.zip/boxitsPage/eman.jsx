import { useState, useEffect } from "react";
import { TabView, TabPanel } from "primereact/tabview";
import { Button } from "primereact/button";
import { DataMenu } from "./i0-componen/data/dataMenuXX";
import Jumbotron from "./i0-componen/jumbotron";
import MenubarUtama from "./i0-componen/menubarUtama";
import SideMenu from "./i0-componen/sideMenu";
import SideMenu2 from "./i0-componen/sideMenu2xx";
import TableDynamic from "./i0-componen/tableDynamic";

import { Entity } from "./i0-componen/data/entityXX";
import SideMenuDynamic from "./i0-componen/sideMenuDynamic";
import { ProductDb } from "./i0-componen/data/BoxitsDb";

export default function Products(props) {
  const [menu, setMenu] = useState("Modal");
  const [menu2, setMenu2] = useState("Modal");
  const terimaState = (terima) => setMenu(terima);
  const terimaState2 = (terima) => setMenu2(terima);

  const propsJumbo = {
    title: "Product",
    subtitle: "Managemen Product, Position, Project, Equipmen, tool, Locate, ",
    column1: ["Generate Entity", "Generate Price", "Generate Property"],
    column2: ["Assign Entity", "Assign Price", "Edit Data"],
  };

  const TampilsideMenu2 = (menu) => {
    switch (menu) {
      case "Product":
        return (
          <>
            <SideMenu2 list={DataMenu.product} listState={terimaState2} />
          </>
        );
        break;
      case "Position":
        return (
          <>
            <SideMenu2 list={DataMenu.position} listState={terimaState2} />
          </>
        );
        break;
      case "Project":
        return (
          <>
            <SideMenu2 list={DataMenu.project} listState={terimaState2} />
          </>
        );
        break;
      case "Equipment":
        return (
          <>
            <SideMenu2 list={DataMenu.equipment} listState={terimaState2} />
          </>
        );
        break;
      case "Tools":
        return (
          <>
            <SideMenu2 list={DataMenu.tools} listState={terimaState2} />
          </>
        );
        break;
      case "Locate":
        return (
          <>
            <SideMenu2 list={DataMenu.locate} listState={terimaState2} />
          </>
        );
        break;
      default:
        return (
          <>
            <SideMenu2 list={DataMenu.product} listState={terimaState2} />
          </>
        );
    }
  };

  let labelTombol = "Add " + menu + " - " + menu2;

  // ------------------------------
  const [dataDynamic, setDataDynamic] = useState([]);
  const [listContex, setListContex] = useState([]);

  useEffect(() => {
    Entity.getProducts().then((data) => setDataDynamic(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const propsTable = {
    db: dataDynamic,
    baris: 9,
    satu: (data) => setListContex(data),
    columns: [
      { field: "name", header: "Nama" },
      { field: "quantity", header: "Jumlah" },
      { field: "code", header: "Kode" },
    ],
    contex: [
      {
        label: "satu",
        icon: "pi pi-fw pi-box",
        command: () => popup(),
      },
      {
        label: "dua",
        icon: "pi pi-fw pi-question",
        command: () => popup(),
      },
    ],
  };

  // fungsi pengguna props yang mgabil ID

  const popup = () => {
    // key data yang di ambil(kayaknya id)
    alert(listContex.name);
  };
  // --------------------------

  // ---

  useEffect(() => {
    // - call db menentukan databasenya
    // - call method menentukan nested data yg di ambil lih db tersedia
    ProductDb.getProductsSideMenuProd().then((data) => setListSideMenu(data));
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const [stateSideMenu, setStateSideMenu] = useState();
  const [listSideMenu, setListSideMenu] = useState();
  const propSideMenu = {
    default: "Servers",
    operStateSideMenu: (data) => setStateSideMenu(data),
    list: listSideMenu,

    // list manual (bukan db):

    // list: [
    //   { name: "Servers", icon: "pi pi-user mr-3" },
    //   { name: "Mapping", icon: "pi pi-map-marker mr-3" },
    //   { name: "Maintenance", icon: "pi pi-wrench mr-3" },
    // ],
  };

  return (
    <>
      <Jumbotron proper={propsJumbo} />
      <MenubarUtama />
      <div>
        <TabView>
          <TabPanel header="Generate">
            <Button
              label={labelTombol}
              outlined
              icon="pi pi-plus"
              className="w-full mb-2 surface-200"
            />
            <div className="flex gap-2">
              <SideMenuDynamic proper={propSideMenu} />
              <SideMenu list={DataMenu.paket} listState={terimaState} />
              {TampilsideMenu2(menu)}
              <div className="card w-full">
                <TableDynamic tabel={propsTable} />
              </div>
            </div>
          </TabPanel>
          {/* ----- <> ----- <> ----- <> ----- <> ----- <> ----- <> ----- <> ----- <>  */}
          {/* ----- <> ----- <> ----- <> ----- <> ----- <> ----- <> ----- <> ----- <>  */}
          <TabPanel header="Adjusments">
            <div className="flex gap-2">
              <TableDynamic tabel={propsTable} />
              <SideMenu list={DataMenu.paket} listState={terimaState} />
              {TampilsideMenu2(menu)}
              <div className="card w-full"></div>
            </div>
          </TabPanel>
        </TabView>
      </div>
      <div className="card bg-primary">
        PR:
        <ul>
          <li>akun root, admin</li>
          <li>akun root ada add product, admin tidak</li>
          <li>admin tidak ada tab generate </li>
          <li>pada tabel admin adjusment ada klik edit pada context</li>
          <li>pada tabel root ada verifi</li>
          <li>pada tabel admin ada sort lokasi</li>
          <li>ada tabel perbandingan</li>
          <li></li>
        </ul>
      </div>
    </>
  );
}
