import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import InvestorList from "./comp/InvestorList";

export default function Investor() {
  const propsJumbo = {
    title: "Investor",
    subtitle: "Halo ",
    column1: ["satu", "dua", "tiga"],
    column2: ["empat", "lima", "enam"],
    column3: [],
  };

  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      <InvestorList />
      <div className="card flex  gap-8 bg-yellow-100">
        <ul>
          <li>
            <b>Entity</b>
            <ol>
              <li>add orang</li>
              <li>modal kontrak</li>
              <li>profit</li>
              <li>durasi</li>
              <li>lokasi</li>
              <li>server</li>
            </ol>
          </li>
          <li>
            <b>Activity</b>
            <ol>
              <li>daftar</li>
              <li>pilih lokasi</li>
              <li>pilih project</li>
              <li>pilih topologi</li>
              <li>
                <b>monitoring</b>
                <ol>
                  <li>project</li>
                  <li>active hotspot</li>
                  <li>saldo</li>
                  <li>guide</li>
                  <li>mobile app</li>
                  <li>MoU</li>
                  <li>Penutupan tahun</li>
                  <li>cairkan</li>
                </ol>
              </li>
              <li>withdraw</li>
            </ol>
          </li>
        </ul>
        <ul>
          <li>
            <b>Dashboard</b>
            <ol>
              <li>add user</li>
              <li>modal kontrak</li>
              <li>profit</li>
              <li>durasi</li>
              <li>lokasi</li>
              <li>server</li>
            </ol>
          </li>
          <li>
            <b>Report</b>
            <ol>
              <li>project progress</li>
              <li>timeline project</li>
              <li>
                monitoring
                <ol>
                  <li>wifi on/off</li>
                  <li>kenaikan keuntungan realtime</li>
                </ol>
              </li>
              <li>activity</li>
            </ol>
          </li>
          <li>
            <b>Mobile</b>
            <ol>
              <li>home</li>
              <li>profile</li>
              <li>profit realtime</li>
              <li>project timeline</li>
              <li>online realtime</li>
              <li>cairkan</li>
              <li>report balance</li>
              <li>history</li>
            </ol>
          </li>
        </ul>
        <ul>
          <li>
            <b>Guide</b>
            <ol>
              <li>daftar</li>
              <li>durasi project</li>
              <li>porsi</li>
              <li>nilai paket</li>
              <li>lokasi</li>
            </ol>
          </li>
        </ul>
      </div>
    </>
  );
}
