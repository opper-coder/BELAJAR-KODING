export default function ModalContentAddInvestor() {
  return <>INI ADALAH PENAMBAHAN INVESTOR</>;
}
