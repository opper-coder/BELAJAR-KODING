/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect, useState } from "react";
import { Button } from "primereact/button";
import { TabPanel, TabView } from "primereact/tabview";
import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import TableAdministrator from "./comp/TableAdministrator";
import TableEnduser from "./comp/TableEnduser";
import ModalForm from "../i0-componen/ModalForm";
import ModalContentAdministrator from "./comp/ModalContentAdministrator";

export default function Users() {
  const [administrator, setAdministrator] = useState("root");

  // jumbotron ----->
  const propsJumbo = {
    title: "User",
    subtitle: "Managemen Users, Hirarki, Autentikasi, Authority",
    column1: [
      "For Root Admin",
      "Generate Main Capital",
      "Generate Main Price Product",
      "Generate Main Price Packet",
    ],
    column2: [
      "Transfer Capital",
      "Response Capital",
      "View All Transfer Type",
      "Connected with report",
    ],
    column3: [],
  };
  const [stateSideMenu, setStateSideMenu] = useState();
  const [pos, setPos] = useState();
  const [itemsMenu, setItemsMenu] = useState();
  const [items] = useState({
    items1: [
      { name: "Region Head", icon: "pi pi-user mr-3", index: 0 },
      { name: "Admin", icon: "pi pi-user mr-3", index: 1 },
      { name: "Agency", icon: "pi pi-user mr-3", index: 2 },
      { name: "Reseller", icon: "pi pi-user mr-3", index: 3 },
      { name: "Technician", icon: "pi pi-user mr-3", index: 4 },
      { name: "Freelancer", icon: "pi pi-user mr-3", index: 5 },
      { name: "Investor", icon: "pi pi-user mr-3", index: 6 },
      { name: "Enduser", icon: "pi pi-user mr-3", index: 7 },
    ],
    items2: [
      { name: "Agency", icon: "pi pi-user mr-3", index: 2 },
      { name: "Reseller", icon: "pi pi-user mr-3", index: 3 },
      { name: "Technician", icon: "pi pi-user mr-3", index: 4 },
      { name: "Freelancer", icon: "pi pi-user mr-3", index: 5 },
      { name: "Investor", icon: "pi pi-user mr-3", index: 6 },
      { name: "Enduser", icon: "pi pi-user mr-3", index: 7 },
    ],
  });

  useEffect(() => {
    if (administrator === "root") {
      setItemsMenu(items.items1);
    } else {
      setItemsMenu(items.items2);
    }
  }, [administrator]);

  const propSideMenu = {
    default: undefined,
    operStateSideMenu: (data) => setStateSideMenu(data),
    index: (data) => setPos(data),
    list: itemsMenu,
  };

  const properBtn2 = {
    label: "Add Member",
    icon: "pi pi-plus",
  };

  // MODAL FORM -----------------------------
  const [modal, setModal] = useState(false);
  const properModal = {
    modal: modal,
    judul: "Add Administrator",
    tombol: "Add Official",
    tombol2: "Add Member",
    modalTutup: (d) => setModal(d),
    content: <ModalContentAdministrator />,
  };

  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      <TabView>
        <TabPanel header="End Users">
          <div>
            <ModalForm proper={properModal} />
            <Button
              onClick={() => setModal(true)}
              label={properModal.tombol2}
              size="small"
              className="mb-2"
              icon="pi pi-plus"
            />
            <TableEnduser />
          </div>
        </TabPanel>
        <TabPanel header="Administrator">
          <div>
            <ModalForm proper={properModal} />
            <Button
              onClick={() => setModal(true)}
              label={properModal.tombol}
              size="small"
              className="mb-2"
              icon="pi pi-plus"
            />
            <TableAdministrator />
          </div>
        </TabPanel>
      </TabView>
    </>
  );
}
