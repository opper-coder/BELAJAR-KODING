/* eslint-disable react-hooks/exhaustive-deps */
import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import Searchbar from "../i0-componen/searchbar";
import SideMenuDynamic from "../i0-componen/sideMenuDynamic";
import { useEffect, useState } from "react";
import PageRegion from "./comp/PageRegion";
import { Button } from "primereact/button";
import PageAdmin from "./comp/PageAdmin";
import PageAgency from "./comp/PageAgency";
import PageReseller from "./comp/PageReseller";
import PageTechnician from "./comp/PageTechnician";
import PageFreelancer from "./comp/PageFreelancer";
import PageInvestor from "./comp/PageInvestor";
import PageEndUser from "./comp/PageEndUser";

export default function Users() {
  const [administrator, setAdministrator] = useState("root");
  // jumbotron ----->
  const propsJumbo = {
    title: "User",
    subtitle: "Managemen Users, Hirarki, Autentikasi, Authority",
    column1: [
      "For Root Admin",
      "Generate Main Capital",
      "Generate Main Price Product",
      "Generate Main Price Packet",
    ],
    column2: [
      "Transfer Capital",
      "Response Capital",
      "View All Transfer Type",
      "Connected with report",
    ],
    column3: [],
  };
  const [stateSideMenu, setStateSideMenu] = useState();
  const [itemsMenu, setItemsMenu] = useState();
  const items = [
    { name: "Region Head", icon: "pi pi-user mr-3" },
    { name: "Admin", icon: "pi pi-user mr-3" },
    { name: "Agency", icon: "pi pi-user mr-3" },
    { name: "Reseller", icon: "pi pi-user mr-3" },
    { name: "Technician", icon: "pi pi-user mr-3" },
    { name: "Freelancer", icon: "pi pi-user mr-3" },
    { name: "Investor", icon: "pi pi-user mr-3" },
    { name: "Enduser", icon: "pi pi-user mr-3" },
  ];
  const items2 = [
    { name: "Agency", icon: "pi pi-user mr-3" },
    { name: "Reseller", icon: "pi pi-user mr-3" },
    { name: "Technician", icon: "pi pi-user mr-3" },
    { name: "Freelancer", icon: "pi pi-user mr-3" },
    { name: "Investor", icon: "pi pi-user mr-3" },
    { name: "Enduser", icon: "pi pi-user mr-3" },
  ];
  useEffect(() => {
    if (administrator === "root") {
      setItemsMenu(items);
    } else {
      setItemsMenu(items2);
    }
  }, []);
  const propSideMenu = {
    default: undefined,
    operStateSideMenu: (data) => setStateSideMenu(data),
    list: itemsMenu,
  };

  // ----------------------------------------------------
  const tampilHalaman = (d) => {
    switch (d) {
      case "Region Head":
        return <PageRegion stateSideMenu={stateSideMenu} />;
      case "Admin":
        return <PageAdmin stateSideMenu={stateSideMenu} />;
      case "Agency":
        return <PageAgency stateSideMenu={stateSideMenu} />;
      case "Reseller":
        return <PageReseller stateSideMenu={stateSideMenu} />;
      case "Technician":
        return <PageTechnician stateSideMenu={stateSideMenu} />;
      case "Freelancer":
        return <PageFreelancer stateSideMenu={stateSideMenu} />;
      case "Investor":
        return <PageInvestor stateSideMenu={stateSideMenu} />;
      case "Enduser":
        return <PageEndUser stateSideMenu={stateSideMenu} />;
      default:
        break;
    }
  };
  const labelAdd = `Add Official ${stateSideMenu}`;
  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      <Searchbar />
      <div className="flex gap-2 mt-2">
        <SideMenuDynamic proper={propSideMenu} />
        {stateSideMenu === undefined ? (
          <div className="card w-full bg-yellow-100">
            Tampilkan data dengan klik <b>Sidemenu</b> di samping
          </div>
        ) : (
          <div className="card w-full">
            <Button
              label={labelAdd}
              className=" mb-2"
              size="small"
              icon="pi pi-plus"
            />
            {tampilHalaman(stateSideMenu)}
          </div>
        )}
      </div>
      <div className="absolute bottom-0 left-0 px-2 py-1 w-full font-bold bg-blue-500 text-white">
        Status
      </div>
    </>
  );
}
