import { Dropdown } from "primereact/dropdown";
import { InputSwitch } from "primereact/inputswitch";
import { InputText } from "primereact/inputtext";
import { useState } from "react";
import { useRef } from "react";
import { Toast } from "primereact/toast";
import { FileUpload } from "primereact/fileupload";

export default function ModalContentFormEdit(props) {
  const [dropdownValue, setDropdownValue] = useState(null);
  const dropdownValues = [
    { name: "Root" },
    { name: "Super Admin" },
    { name: "Admin" },
    { name: "Agency" },
    { name: "Reseller" },
  ];
  const [switchValue, setSwitchValue] = useState(false);
  // upload file
  const toast = useRef(null);

  const onUpload = () => {
    toast.current.show({
      severity: "info",
      summary: "Success",
      detail: "File Uploaded",
    });
  };
  // state edit--------------------------------------
  const [dataForm, setDataForm] = useState(props.data); // State untuk menyimpan nilai data tersimpan

  const handleChange = (event) => {
    setDataForm(event.target.value); // Update state data dengan nilai input
  };

  const handleSubmit = (event) => {
    event.preventDefault(); // Cegah refresh halaman
    console.log(`Data yang diedit: ${dataForm}`); // Simulasikan pengiriman data
  };

  return (
    <>
      <section>
        <h6>User Profile</h6>
        <div className="grid formgrid mb-3">
          <div className="col-12 mb-2 lg:col-4 lg:mb-0">
            <span className="p-input-icon-left">
              <i className="pi pi-user" />
              <InputText
                type="text"
                placeholder="Username"
                value={dataForm.name}
                onChange={handleChange}
              />
            </span>
          </div>
          <div className="col-12 mb-2 lg:col-4 lg:mb-0">
            <span className="p-input-icon-left">
              <i className="pi pi-user" />
              <InputText
                type="text"
                placeholder="Password"
                value={dataForm.password}
                onChange={handleChange}
              />
            </span>
          </div>
          <div className="col-12 mb-2 lg:col-4 lg:mb-0">
            <span className="p-input-icon-left">
              <i className="pi pi-user" />
              <InputText
                type="text"
                placeholder="Password Again"
                value={dataForm.password}
                onChange={handleChange}
              />
            </span>
          </div>
        </div>
      </section>
      <section>
        <div className="grid formgrid mb-3">
          <div className="col-12 mb-2 lg:col-4 lg:mb-0">
            <span className="p-input-icon-left">
              <i className="pi pi-map" />
              <InputText
                type="text"
                placeholder="Street"
                value={dataForm.street}
                onChange={handleChange}
              />
            </span>
          </div>
          <div className="col-12 mb-2 lg:col-4 lg:mb-0">
            <span className="p-input-icon-left">
              <i className="pi pi-map-marker" />
              <InputText
                type="text"
                placeholder="Coordinat"
                value={dataForm.coordinat}
                onChange={handleChange}
              />
            </span>
          </div>
          <div className="col-12 mb-2 lg:col-4 lg:mb-0">
            <span className="p-input-icon-left">
              <i className="pi pi-calculator" />
              <InputText
                type="text"
                placeholder="HP"
                value={dataForm.hp}
                onChange={handleChange}
              />
            </span>
          </div>
        </div>
      </section>
      <section>
        <div className="grid formgrid">
          <div className="col-12 mb-2 lg:col-4 lg:mb-0">
            <span className="p-input-icon-left">
              <i className="pi pi-home" />
              <InputText
                type="text"
                placeholder="Bank"
                value={dataForm.bank}
                onChange={handleChange}
              />
            </span>
          </div>
          <div className="col-12 mb-2 lg:col-4 lg:mb-0">
            <span className="p-input-icon-left">
              <i className="pi pi-qrcode" />
              <InputText
                type="text"
                placeholder="Rekening"
                value={dataForm.rek}
                onChange={handleChange}
              />
            </span>
          </div>
          <div className="col-12 mb-2 lg:col-4 lg:mb-0">
            <span className="p-input-icon-left">
              <i className="pi pi-pencil" />
              <InputText
                type="text"
                placeholder="Edited"
                value={dataForm.edited}
                onChange={handleChange}
                disabled
              />
            </span>
          </div>
        </div>
      </section>
      <hr />
      <section>
        <div>
          <span className="p-input-icon-left mr-3">
            <i className="pi pi-directions" />
            <InputText
              type="text"
              placeholder="Address"
              value={dataForm.address}
              onChange={handleChange}
            />
          </span>
          <Dropdown
            value={dropdownValue}
            onChange={(e) => setDropdownValue(e.value)}
            options={dropdownValues}
            optionLabel="name"
            placeholder="Position"
          />
        </div>
      </section>

      <h6>Verified User</h6>
      <InputSwitch
        checked={switchValue}
        onChange={(e) => setSwitchValue(e.value)}
      />
      {/* ---------- */}
      <Toast ref={toast}></Toast>
      <h6>User Photo Profile</h6>
      <FileUpload
        mode="basic"
        name="demo[]"
        url="/api/upload"
        accept="image/*"
        maxFileSize={1000000}
        onUpload={onUpload}
        className="mt-2"
      />
      <h6>Home Photo</h6>
      <FileUpload
        mode="basic"
        name="demo[]"
        url="/api/upload"
        accept="image/*"
        maxFileSize={1000000}
        onUpload={onUpload}
        className="mt-2"
      />
      <ul>
        <li>homeImage: link,</li>
        <li>profileImage: link,</li>
        <li>address: Banggai laut,</li>
        <li>id: 1001,</li>
        <li>uid: ad1001,</li>
        <li>label: izza,</li>
        <li>date: 2015-09-13,</li>
        <li>mac:11:30:48:as:qw:12,</li>
        <li>admin_id: Banggai,</li>
        <li>agency_id: Gonggong 01,</li>
      </ul>
    </>
  );
}
