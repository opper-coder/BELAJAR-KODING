export default function ModalContentPending2(props) {
  return (
    <>
      Apakah anda akan Memblokir sementara <b> {props.terpilih.name}</b>
    </>
  );
}
