// export const UsersUi = {
//   getUsersUi() {
//     return [{ items: [{}] }];
//   },
//   // -----
//   getUserUiMini() {
//     return Promise.resolve(this.getUsersUi().slice(0, 5));
//   },
//   getUserUiSmall() {
//     return Promise.resolve(this.getUsersUi().slice(0, 10));
//   },
//   getUserUi() {
//     return Promise.resolve(this.getUsersUi());
//   },
// };

export const UsersUi = {
  getUsersUi() {
    return [
      {
        label: "Position",
        icon: "pi pi-user mr-3",
        items: [
          {
            label: "Region Head",
            name: "Region Head",
            icon: "pi pi-user mr-3",
            command: () => setSelectedMenu("Region Head"),
          },
          {
            label: "Admin",
            name: "Admin",
            icon: "pi pi-user mr-3",
            command: () => setSelectedMenu("Admin"),
          },
          {
            label: "Agency",
            name: "Agency",
            icon: "pi pi-user mr-3",
            command: () => setSelectedMenu("Agency"),
          },
          {
            label: "Reseller",
            name: "Reseller",
            icon: "pi pi-user mr-3",
            command: () => setSelectedMenu("Reseller"),
          },
          {
            label: "Technician",
            name: "Technician",
            icon: "pi pi-user mr-3",
            command: () => setSelectedMenu("Technician"),
          },
          {
            label: "Freelancer",
            name: "Freelancer",
            icon: "pi pi-user mr-3",
            command: () => setSelectedMenu("Freelancer"),
          },
          {
            label: "Investor",
            name: "Investor",
            icon: "pi pi-user mr-3",
            command: () => setSelectedMenu("Investor"),
          },
          {
            label: "Enduser",
            name: "Enduser",
            icon: "pi pi-user mr-3",
            command: () => setSelectedMenu("Enduser"),
          },
        ],
      },
    ];
  },
  // -----
  getUserUiMini() {
    return Promise.resolve(this.getUsersUi().slice(0, 5));
  },
  getUserUiSmall() {
    return Promise.resolve(this.getUsersUi().slice(0, 10));
  },
  getUserUi() {
    return Promise.resolve(this.getUsersUi());
  },
  // -----
  getUserUiPosision() {
    return Promise.resolve(this.getUsersUi()[0]["items"]);
  },
};
