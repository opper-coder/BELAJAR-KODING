export default function ModalContentActivate(props) {
  return (
    <>
      Apakah anda akan mengaktifkan <b>{props.terpilih.name}</b>
    </>
  );
}
