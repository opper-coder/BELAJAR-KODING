/* eslint-disable react-hooks/exhaustive-deps */
import TableDynamic from "../../i0-componen/tableDynamic";
import { useState, useEffect } from "react";
import { BoxitsDb } from "../../i0-componen/data/BoxitsDb";

export default function PageFreelancer() {
  const [sumberData, setSumberData] = useState([]);
  const [listContex, setListContex] = useState([]);

  useEffect(() => {
    BoxitsDb.getProducts().then((data) =>
      setSumberData(data[0]["items"][5]["items"])
    );
  }, []);

  const propsTable = {
    db: sumberData,
    baris: 9,
    satu: (data) => setListContex(data),
    columns: [
      { field: "name", header: "Nama" },
      { field: "userId", header: "UserId" },
      { field: "password", header: "Password" },
      { field: "branchId", header: "Cabang" },
      { field: "hp", header: "Handphone" },
      { field: "street", header: "Alamat" },
      { field: "bank", header: "Akun Bank" },
      { field: "rek", header: "Rekening" },
      { field: "registerDate", header: "Tgl Register" },
      { field: "status", header: "Status" },
    ],
    contex: [
      {
        label: "Edit",
        icon: "pi pi-fw pi-pencil",
        command: () => popup(),
      },
      {
        label: "Delete",
        icon: "pi pi-fw pi-trash",
        command: () => popup(),
      },
      {
        label: "Freeze",
        icon: "pi pi-fw pi-times",
        command: () => popup(),
      },
      {
        label: "Activation",
        icon: "pi pi-fw pi-check",
        command: () => popup(),
      },
      {
        label: "Downline",
        icon: "pi pi-fw pi-users",
        command: () => popup(),
      },
      {
        label: "Properties",
        icon: "pi pi-fw pi-info-circle",
        command: () => popup(),
      },
    ],
  };

  const popup = () => {
    // ambil data dari db mis: "listContex.id" ngambil ID untuk proses selanjutnya
    alert(listContex.name);
  };

  return (
    <>
      <TableDynamic tabel={propsTable} />
    </>
  );
}
