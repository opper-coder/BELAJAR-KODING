import React, { useState, useEffect, useRef } from "react";
import { classNames } from "primereact/utils";
import { FilterMatchMode, FilterOperator } from "primereact/api";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { InputText } from "primereact/inputtext";
import { TriStateCheckbox } from "primereact/tristatecheckbox";
import { DataDb } from "../../i0-componen/data/DataDb";
import { ContextMenu } from "primereact/contextmenu";
import { Toast } from "primereact/toast";
import ModalForm from "../../i0-componen/ModalForm";
import ModalContentActivate2 from "./ModaContentlActivate2";
import ModalContentPending2 from "./ModalContentPending2";
import ModalContentDelete2 from "./ModalContentDelete2";
import ModalContentProperties2 from "./ModalContentProperties2";
import ModalProperties from "../../i0-componen/ModalProperties";
import ModalContentFormEdit2 from "./ModalContentFormEdit2";

export default function TableEnduser() {
  const [customers, setCustomers] = useState(null);
  const [loading, setLoading] = useState(true);
  const [globalFilterValue, setGlobalFilterValue] = useState("");
  const [filters, setFilters] = useState({
    global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    name: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    uid: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    agency_id: { value: null, matchMode: FilterMatchMode.STARTS_WITH },
    verified: { value: null, matchMode: FilterMatchMode.EQUALS },
  });

  const [pos] = useState([
    "root",
    "super admin",
    "admin",
    "agency",
    "reseller",
    "technician",
    "freelancer",
    "investor",
  ]);

  useEffect(() => {
    DataDb.getEndUser().then((data) => {
      setCustomers(getCustomers(data));
      setLoading(false);
    });
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const getCustomers = (data) => {
    return [...(data || [])].map((d) => {
      d.date = new Date(d.date);

      return d;
    });
  };

  const onGlobalFilterChange = (e) => {
    const value = e.target.value;
    let _filters = { ...filters };

    _filters["global"].value = value;

    setFilters(_filters);
    setGlobalFilterValue(value);
  };

  const renderHeader = () => {
    return (
      <div className="flex justify-content-end">
        <span className="p-input-icon-left">
          <i className="pi pi-search" />
          <InputText
            value={globalFilterValue}
            onChange={onGlobalFilterChange}
            placeholder="Cari Official"
          />
        </span>
      </div>
    );
  };

  const verifiedBodyTemplate = (rowData) => {
    return (
      <i
        className={classNames("pi", {
          "text-green-500 true-icon pi-check-circle": rowData.verified,
          "text-red-500 false-icon pi-times-circle": !rowData.verified,
        })}
      ></i>
    );
  };

  const verifiedRowFilterTemplate = (options) => {
    return (
      <TriStateCheckbox
        value={options.value}
        onChange={(e) => options.filterApplyCallback(e.value)}
      />
    );
  };

  const header = renderHeader();
  // --------------------------------------------------------
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const toast = useRef(null);
  const cm = useRef(null);
  const menuModel = [
    {
      label: "Activate",
      icon: "pi pi-fw pi-check",
      command: () => setModalForm(true),
    },
    {
      label: "Pending",
      icon: "pi pi-fw pi-times",
      command: () => setModalForm2(true),
    },
    {
      label: "Edit",
      icon: "pi pi-fw pi-pencil",
      command: () => setModalEdit(true),
    },
    {
      label: "Delete",
      icon: "pi pi-fw pi-trash",
      command: () => setModalForm3(true),
    },
    {
      label: "Properties",
      icon: "pi pi-fw pi-info-circle",
      command: () => setModalProperties(true),
    },
  ];

  const viewProduct = (product) => {
    alert(product.name);
  };

  // ----------------------------------------------------------------
  // MODAL FORM ACTIVATE -----------------------------
  const [modalForm, setModalForm] = useState(false);
  const properModalForm = {
    modal: modalForm,
    judul: "Activate",
    tombol: "Add Official",
    width: "30vw",
    warna: "success", // success, danger, warning, info
    modalTutup: (d) => setModalForm(d),
    content: <ModalContentActivate2 terpilih={selectedProduct} />,
  };
  // MODAL FORM PENDING -----------------------------
  const [modalForm2, setModalForm2] = useState(false);
  const properModalForm2 = {
    modal: modalForm2,
    judul: "Pending",
    tombol: "Add Official",
    width: "30vw",
    warna: "warning", // success, danger, warning, info
    modalTutup: (d) => setModalForm2(d),
    content: <ModalContentPending2 terpilih={selectedProduct} />,
  };
  // MODAL FORM HAPUS -----------------------------
  const [modalForm3, setModalForm3] = useState(false);
  const properModalForm3 = {
    modal: modalForm3,
    judul: "Delete",
    tombol: "Add Official",
    width: "30vw",
    warna: "danger", // success, danger, warning, info
    modalTutup: (d) => setModalForm3(d),
    content: <ModalContentDelete2 terpilih={selectedProduct} />,
  };
  // MODAL PROPERTIES -----------------------------
  const [modalProperties, setModalProperties] = useState(false);
  const properModalProperties = {
    modal: modalProperties,
    judul: "Properties",
    tombol: "Add Official",
    modalTutup: (d) => setModalProperties(d),
    content: <ModalContentProperties2 proper={selectedProduct} />,
  };
  // MODAL FORM EDIT -----------------------------
  const [modalEdit, setModalEdit] = useState(false);
  const properModalEdit = {
    modal: modalEdit,
    judul: "Edit Administrator",
    tombol: "Edit Data Official",
    tombol2: "Add Member",
    modalTutup: (d) => setModalEdit(d),
    content: <ModalContentFormEdit2 data={selectedProduct} />,
  };
  return (
    <>
      <ModalForm proper={properModalForm} />
      <ModalForm proper={properModalForm2} />
      <ModalForm proper={properModalForm3} />
      <ModalForm proper={properModalEdit} />
      <ModalProperties proper={properModalProperties} />
      <Toast ref={toast} />
      <ContextMenu
        model={menuModel}
        ref={cm}
        // onHide={() => setSelectedProduct(null)}
      />
      <DataTable
        value={customers}
        paginator
        rows={8}
        dataKey="id"
        filters={filters}
        filterDisplay="row"
        loading={loading}
        globalFilterFields={["name", "position"]}
        // header={header}
        emptyMessage="No customers found."
        size="small"
        onContextMenu={(e) => cm.current.show(e.originalEvent)}
        contextMenuSelection={selectedProduct}
        onContextMenuSelectionChange={(e) => setSelectedProduct(e.value)}
        stripedRows
      >
        <Column
          field="name"
          header="Name"
          style={{ minWidth: "10rem" }}
          filter
          filterPlaceholder="Search by name"
          sortable
        />
        <Column
          field="uid"
          header="Uid"
          style={{ minWidth: "10rem" }}
          filter
          filterPlaceholder="Search by Uid"
        />
        <Column
          field="agency_id"
          header="Agency"
          style={{ minWidth: "10rem" }}
          filter
          filterPlaceholder="Search by Agency"
          sortable
        />
        <Column
          field="verified"
          header="Verified"
          dataType="boolean"
          style={{ minWidth: "6rem" }}
          body={verifiedBodyTemplate}
          filter
          filterElement={verifiedRowFilterTemplate}
        />
      </DataTable>
    </>
  );
}
