export default function ModalContentPending(props) {
  return (
    <>
      Apakah anda akan Memblokir sementara <b>{props.terpilih.name}</b>
    </>
  );
}
