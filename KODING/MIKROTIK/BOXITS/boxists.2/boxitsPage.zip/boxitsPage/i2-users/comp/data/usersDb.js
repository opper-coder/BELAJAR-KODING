export const UsersDb = {
  getUsersDb() {
    return [
      {
        id: "1001",
        userId: "hj78320",
        position: "Region",
        status: "Active",
        username: "Rafa khoirul azam",
        password: "***asia",
        branchId: "Salakan",
        unitId: "Gonggong 01",
        jalan: "Jl. R tadja Gonggong",
        koordinat: "ls87870",
        hp: "081334797979",
        registerDate: "22 jan 2024",
        bank: "BRI",
        rek: "100998098",
        mac: "11:05:87:6s:w:2",
        komisi: "Rp 150.000,-",
        rumahImg: "link",
        profilImg: "link",
        downline: [],
      },
      {
        id: "1002",
        userId: "hj73290",
        position: "Region",
        status: "Active",
        username: "Aluna ",
        password: "***pan",
        branchId: "Banggai Laut",
        unitId: "Gonggong 01",
        jalan: "Jl. R tadja Gonggong",
        koordinat: "ls87870",
        hp: "081334797979",
        registerDate: "22 jan 2024",
        bank: "BNI",
        rek: "100998098",
        mac: "11:05:87:6s:w:2",
        komisi: "Rp 150.000,-",
        rumahImg: "link",
        profilImg: "link",
        downline: [],
      },
      {
        id: "1003",
        userId: "hj68890",
        position: "Region",
        status: "Active",
        username: "Silmi",
        password: "***arika",
        branchId: "Banggai",
        unitId: "Gonggong 01",
        jalan: "Jl. R tadja Gonggong",
        koordinat: "ls87870",
        hp: "081334797979",
        registerDate: "22 jan 2024",
        bank: "Dana",
        rek: "100998098",
        mac: "11:05:87:6s:w:2",
        komisi: "Rp 150.000,-",
        rumahImg: "link",
        profilImg: "link",
        downline: [],
      },
    ];
  },

  getUserDbMini() {
    return Promise.resolve(this.getUsersDb().slice(0, 5));
  },
  getUserDbSmall() {
    return Promise.resolve(this.getUsersDb().slice(0, 10));
  },
  getUserDb() {
    return Promise.resolve(this.getUsersDb());
  },
};
