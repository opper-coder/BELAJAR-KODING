export default function ModalContentActivate2(props) {
  return (
    <>
      Apakah anda akan mengaktifkan <b>{props.terpilih.name}</b>
    </>
  );
}
