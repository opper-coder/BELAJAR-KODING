import { TabPanel, TabView } from "primereact/tabview";
import Jumbotron from "../i0-componen/jumbotron";
import MenubarUtama from "../i0-componen/menubarUtama";
import ProjectList from "./comp/projectList";

export default function Project() {
  const propsJumbo = {
    title: "Project",
    subtitle: "Halo ",
    column1: ["satu", "dua", "tiga"],
    column2: ["empat", "lima", "enam"],
    column3: [],
  };

  return (
    <>
      <MenubarUtama />
      <Jumbotron proper={propsJumbo} />
      <ProjectList />

      <div className="card bg-primary">
        <ul>
          <li>
            fungsi Utama
            <ol>
              <li>Tambah project terkait dengan lokasi</li>
              <li>Tambah alat terkait project</li>
              <li>Tambah waktu estimasi</li>
              <li>Tambah assign</li>
              <li>Tambah nilai project</li>
              <li></li>
              <li></li>
              <li></li>
            </ol>
          </li>
          <li>layout</li>
          <li>database</li>
          <li>data tunggal</li>
          <li>data majemuk</li>
          <li></li>
          <li></li>
          <li></li>
        </ul>
      </div>
    </>
  );
}
