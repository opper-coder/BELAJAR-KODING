export default function ModalContentAddProject() {
  return <>INI ADALAH PENAMBAHAN PROJECT</>;
}
