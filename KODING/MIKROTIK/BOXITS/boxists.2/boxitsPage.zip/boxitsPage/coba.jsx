import React, { useState } from "react";

function EditForm() {
  const [data, setData] = useState("Ini adalah data awal"); // State untuk menyimpan nilai data tersimpan

  const handleChange = (event) => {
    setData(event.target.value); // Update state data dengan nilai input
  };

  const handleSubmit = (event) => {
    event.preventDefault(); // Cegah refresh halaman
    console.log(`Data yang diedit: ${data}`); // Simulasikan pengiriman data
  };

  return (
    <form onSubmit={handleSubmit}>
      <label htmlFor="data">Data:</label>
      <input
        type="text"
        id="data"
        name="data"
        value={data}
        onChange={handleChange}
      />
      <button type="submit">Simpan</button>
    </form>
  );
}

export default EditForm;
